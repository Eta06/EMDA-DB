import collections
import json
import pathlib
import sys

root = pathlib.Path(sys.argv[1])
revision = sys.argv[2]
first_revision = "d10303c992bfe05f31ff82e4404e0a626ffcd74b"
runs = {"45374893103": first_revision, "45374892583": first_revision, "45374892860": first_revision, "45374892534": first_revision, "45376266464": revision, "45376266199": revision}
for run, expected_revision in runs.items():
    state = json.loads((root / run / "jobs.json").read_text())
    assert state["headSha"] == expected_revision, state
    assert state["status"] == "completed" and state["conclusion"] == "success", state
    assert (root / run / "workflow.log").stat().st_size > 0, run
    print(state["workflowName"], run, state["conclusion"])

for label, directory, count in [
    ("standard benchmark smoke", root / "45376266464" / "ci-benchmark-smoke", 45),
    ("cross-engine smoke", root / "45374892534", 5),
    ("four-writer recovery memory workload", root / "45376266464" / "writable-recovery-memory-ceiling", 1),
]:
    attempts = list(directory.rglob("attempt.json"))
    assert len(attempts) == count, (label, len(attempts))
    dispositions = collections.Counter()
    for path in attempts:
        attempt = json.loads(path.read_text())
        expected_revision = first_revision if label == "cross-engine smoke" else revision
        assert attempt["revision"] == expected_revision and attempt["tracked_changes"] == "", path
        assert attempt["status"] == "exited", path
        assert (path.parent / attempt["output"]).is_file(), path
        dispositions[attempt["returncode"], attempt["wrapper_exit_code"]] += 1
    assert dispositions == {(0, 0): count}, dispositions
    print(label, dispositions)

measurements, = (root / "45376266464").rglob("measurements.jsonl")
phases = [json.loads(line) for line in measurements.read_text().splitlines()]
capped = [phase for phase in phases if phase["address_space_limit_bytes"] is not None]
assert len(phases) == 51 and len(capped) == 24, (len(phases), len(capped))
assert all(phase["address_space_limit_bytes"] == 48 * 1024**2 for phase in capped)
print("recovery phases", len(phases), "capped at 48 MiB", len(capped))

linux_log = (root / "45376266464" / "workflow.log").read_text()
for test in ("over_limit_compaction_candidate_is_not_published",
             "checkpoint_limits_reject_handoff_before_sibling_publication",
             "checkpoint_handoff_faults_leave_two_recoverable_logs_and_valid_source_selection"):
    lines = [line for line in linux_log.splitlines() if test + " ... ok" in line]
    assert len(lines) >= 2, (test, lines)
    print(test, len(lines), "passes")

previous = root / "45374419959"
previous_revision = "a5b609bffed88e6427fafc888c3b952b59b1ade3"
state = json.loads((previous / "jobs.json").read_text())
assert state["headSha"] == previous_revision and state["conclusion"] == "success"
for artifact, count in (("ci-benchmark-smoke", 45), ("writable-recovery-memory-ceiling", 1)):
    attempts = list((previous / artifact).rglob("attempt.json"))
    assert len(attempts) == count, (artifact, len(attempts))
    for path in attempts:
        attempt = json.loads(path.read_text())
        assert attempt["revision"] == previous_revision and attempt["tracked_changes"] == ""
        assert attempt["status"] == "exited"
        assert attempt["returncode"] == attempt["wrapper_exit_code"] == 0
        assert (path.parent / attempt["output"]).is_file()
    print("preceding documentation push", artifact, count)

first = root / "45374892622"
state = json.loads((first / "jobs.json").read_text())
assert state["headSha"] == first_revision and state["conclusion"] == "failure"
first_log = (first / "workflow.log").read_text()
assert first_log.count("assertion failed: previous.exists()") == 2
attempt, = list(first.rglob("attempt.json"))
assert attempt.parent.name == "writable-recovery-memory-ceiling"
result = json.loads(attempt.read_text())
assert result["revision"] == first_revision and result["returncode"] == result["wrapper_exit_code"] == 0
print("first source revision", state["conclusion"], "with one completed memory benchmark attempt")
