use database_engine::retained_base_v2::Limits;
use database_engine::retained_candidate::{
    IndexLimits, OverlayLimits, RetainedStoreLimits, SuffixLimits,
};
const LIMITS: RetainedStoreLimits = RetainedStoreLimits {
    base: Limits { file_bytes: 8192, entries: 32, key_bytes: 256, work_bytes: 8193 },
    index: IndexLimits { blocks: 4, anchor_bytes: 64 },
    suffix: SuffixLimits { bytes: 8192, operations: 64, work: 4096 },
    overlay: OverlayLimits { entries: 32, key_bytes: 256 },
};
use database_engine::Store;
use database_engine::retained_candidate::ManagedRetainedStore;
use std::path::PathBuf;
fn main() {
    let root = PathBuf::from(std::env::args_os().nth(1).unwrap());
    let source = root.join("source");
    assert_eq!(Store::open(source).unwrap().get(b"verified").unwrap().unwrap(), b"value");
    let catalog = root.join("authorized");
    assert!(ManagedRetainedStore::open(&catalog, LIMITS).is_err());
    assert!(Store::open(&catalog).is_err());
    assert!(Store::open(catalog.join("generation-a")).is_err());
    println!("previous engine rejected authorized catalog and generation");
}
