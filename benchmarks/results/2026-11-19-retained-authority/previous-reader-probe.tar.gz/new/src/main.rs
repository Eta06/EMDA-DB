use database_engine::retained_base_v2::Limits;
use database_engine::retained_candidate::{
    IndexLimits, OverlayLimits, RetainedStoreLimits, SuffixLimits,
};
const LIMITS: RetainedStoreLimits = RetainedStoreLimits {
    base: Limits { file_bytes: 8192, entries: 32, key_bytes: 256, work_bytes: 8193 },
    index: IndexLimits { blocks: 4, anchor_bytes: 64 },
    suffix: SuffixLimits { bytes: 8192, operations: 64, work: 4096 },
    overlay: OverlayLimits { entries: 32, key_bytes: 256 },
};
use database_engine::{RetainedExportLimits, Store};
use database_engine::retained_candidate::{AuthorityRecord, AuthorizedRetainedStore, RetainedAuthority};
use std::{io, path::PathBuf};

struct UnusedProvider;
impl RetainedAuthority for UnusedProvider {
    fn read(&mut self) -> io::Result<Option<AuthorityRecord>> { unreachable!() }
    fn compare_and_swap(&mut self, _: Option<AuthorityRecord>, _: AuthorityRecord) -> io::Result<bool> { unreachable!() }
}
fn main() {
    let root = PathBuf::from(std::env::args_os().nth(1).unwrap());
    let source = root.join("source");
    let store = Store::open(&source).unwrap();
    store.put(b"verified", b"value").unwrap();
    let prepared = AuthorizedRetainedStore::<UnusedProvider>::prepare_from_store(
        store, &source, root.join("authorized"),
        RetainedExportLimits {
            max_log_bytes: 8192, max_live_keys: 32,
            max_live_key_bytes: 256, max_output_bytes: 8192,
        }, LIMITS,
    ).unwrap();
    println!("prepared revision {}", prepared.revision);
}
