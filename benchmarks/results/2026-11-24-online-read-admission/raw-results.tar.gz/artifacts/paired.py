import json
from pathlib import Path
import sys

from scripts.benchmarks.record_case import record_case

root = Path(sys.argv[1])
before = root / 'baseline-target/release/examples/kv_bench'
after = root / 'candidate-target/release/examples/kv_bench'
cases = [('before-plain', before, 'prototype'), ('after-plain', after, 'prototype'),
         ('before-limited', before, 'prototype-read-limited'), ('after-limited', after, 'prototype-read-limited'),
         ('sqlite', before, 'sqlite')]
report = []
for clients in (1, 4):
    for index in range(10):
        shift = (index * 2 + clients) % len(cases)
        for name, binary, backend in cases[shift:] + cases[:shift]:
            label = f'read-{clients}client-{name}'
            path = root / 'artifacts' / f'{label}-r{index+1:02}'
            command = [str(binary), backend, str(clients), '40000', '16', '0', str(root / 'fixtures'), '64']
            status = record_case(path, label, command)
            lines = (path / 'command.log').read_text().splitlines()
            first = dict(x.split('=', 1) for x in lines[0].split() if '=' in x) if lines else {}
            verified = (status == 0 and lines.count('verified_reopen=true') == 1
                        and first.get('backend') == backend and int(first.get('completed', 0)) == 40000*clients)
            report.append(dict(round=index+1, clients=clients, case=name, path=path.name,
                               exit=status, verified=verified, ops_per_sec=first.get('ops_per_sec')))
            (root / 'artifacts' / 'samples.json').write_text(json.dumps(report, indent=2) + '\n')
if not all(row['verified'] for row in report):
    raise SystemExit('one or more attempts failed verification')
