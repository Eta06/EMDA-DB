import collections
import json
import pathlib
import sys

root = pathlib.Path(sys.argv[1])
revision = sys.argv[2]
runs = ("45378519521", "45378519500", "45378519626", "45378519592", "45378519440")
for run in runs:
    state = json.loads((root / run / "jobs.json").read_text())
    assert state["headSha"] == revision, state
    assert state["status"] == "completed" and state["conclusion"] == "success", state
    assert (root / run / "workflow.log").stat().st_size > 0, run
    print(state["workflowName"], run, state["conclusion"])

for label, directory, count in [
    ("standard benchmark smoke", root / "45378519500" / "ci-benchmark-smoke", 45),
    ("cross-engine smoke", root / "45378519440", 5),
    ("four-writer recovery memory workload", root / "45378519500" / "writable-recovery-memory-ceiling", 1),
]:
    attempts = list(directory.rglob("attempt.json"))
    assert len(attempts) == count, (label, len(attempts))
    dispositions = collections.Counter()
    for path in attempts:
        attempt = json.loads(path.read_text())
        assert attempt["revision"] == revision and attempt["tracked_changes"] == "", path
        assert attempt["status"] == "exited", path
        assert (path.parent / attempt["output"]).is_file(), path
        dispositions[attempt["returncode"], attempt["wrapper_exit_code"]] += 1
    assert dispositions == {(0, 0): count}, dispositions
    print(label, dispositions)

measurements, = root.rglob("measurements.jsonl")
phases = [json.loads(line) for line in measurements.read_text().splitlines()]
capped = [phase for phase in phases if phase["address_space_limit_bytes"] is not None]
assert len(phases) == 51 and len(capped) == 24, (len(phases), len(capped))
assert all(phase["address_space_limit_bytes"] == 48 * 1024**2 for phase in capped)
print("recovery phases", len(phases), "capped at 48 MiB", len(capped))

linux_log = (root / "45378519500" / "workflow.log").read_text()
for test in ("streamed_compaction_preserves_maximum_and_empty_values",
             "streamed_compaction_rejects_corrupt_staged_data_before_publication"):
    lines = [line for line in linux_log.splitlines() if test + " ... ok" in line]
    assert len(lines) >= 2, (test, lines)
    print(test, len(lines), "passes")

bench = root / "native-macos" / "paired-compaction"
rows = [json.loads(line) for line in (bench / "results.jsonl").read_text().splitlines()]
assert len(rows) == 24
assert len({(row["case"], row["round"], row["backend"]) for row in rows}) == 24
for case in ("small", "mixed"):
    group = [row for row in rows if row["case"] == case]
    assert len(group) == 12
    assert len({row["target_record_sha256"] for row in group}) == 1
    assert len({row["target_log_bytes"] for row in group}) == 1
    assert len({json.dumps(row["source"], sort_keys=True) for row in group}) == 1
    assert {row["backend"] for row in group} == {"baseline", "candidate"}
    assert {row["round"] for row in group} == set(range(1, 7))
attempts = [json.loads(line) for line in (bench / "commands.jsonl").read_text().splitlines()]
assert len(attempts) == 50 and all(item["returncode"] == 0 for item in attempts)
for item in attempts:
    assert (bench / (item["name"] + ".stdout")).is_file()
    assert (bench / (item["name"] + ".stderr")).is_file()
assert (bench / "candidate-revision.txt").read_text().strip() == revision
assert (bench / "baseline-Cargo.lock").read_bytes() == (bench / "candidate-Cargo.lock").read_bytes()
assert "AttributeError" in (bench / "first-attempt" / "summary.txt").read_text()
print("native paired benchmark", len(rows), "timed attempts", len(attempts), "total commands")
