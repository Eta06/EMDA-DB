use database_engine::{BatchOperation, COMPACTED_CHECKPOINT_FILE, CheckpointStore, Store};
use std::error::Error;
use std::fs;
use std::path::Path;
use std::time::Instant;

fn len(case: &str, key: usize) -> usize {
    match (case, key) {
        ("mixed", 31) => 5 << 20,
        ("mixed", 96) => 16 << 20,
        _ => 64,
    }
}

fn value(case: &str, key: usize) -> Vec<u8> {
    (0..len(case, key)).map(|i| ((key + i / 4096) % 251) as u8).collect()
}

fn main() -> Result<(), Box<dyn Error>> {
    let args: Vec<_> = std::env::args().skip(1).collect();
    let (action, case, root) = (&args[0], args[1].as_str(), Path::new(&args[2]));
    let count = match case {
        "small" => 4096,
        "mixed" => 128,
        _ => return Err("invalid case".into()),
    };
    let source = root.join("source");
    let checkpoint = root.join("index");
    let trusted = root.join("source.digest");
    match action.as_str() {
        "prepare" => {
            let db = Store::open(&source)?;
            for start in (0..count).step_by(32) {
                let entries: Vec<_> = (start..start + 32)
                    .map(|n| ((n as u64).to_be_bytes(), value(case, n)))
                    .collect();
                let small: Vec<_> = entries.iter()
                    .filter(|(_, value)| value.len() <= 64)
                    .map(|(key, value)| BatchOperation::Put { key, value })
                    .collect();
                db.write_batch(&small)?;
                for (key, value) in entries.iter().filter(|(_, value)| value.len() > 64) {
                    db.put(key, value)?;
                }
            }
            fs::write(trusted, db.checkpoint_to(&checkpoint)?)?;
        }
        "compact" => {
            let db = CheckpointStore::open(&source, &checkpoint, &fs::read(trusted)?.try_into().unwrap())?;
            let out = Path::new(&args[3]);
            let start = Instant::now();
            let digest = db.compact_to(out)?;
            let elapsed = start.elapsed().as_micros();
            fs::write(&args[4], digest)?;
            println!("compaction_us={elapsed}");
        }
        "verify" => {
            let out = Path::new(&args[3]);
            let db = CheckpointStore::open(out, out.join(COMPACTED_CHECKPOINT_FILE),
                &fs::read(&args[4])?.try_into().unwrap())?;
            for key in 0..count {
                let actual = db.get(&(key as u64).to_be_bytes())?;
                if actual.as_deref() != Some(value(case, key).as_slice()) {
                    return Err(format!("value mismatch for key {key}").into());
                }
            }
            let ordinary = Store::open(&source)?;
            let x = ordinary.get(&0_u64.to_be_bytes())?;
            if x.as_deref() != Some(value(case, 0).as_slice()) {
                return Err("source check failed".into());
            }
            println!("verified_keys={count}");
        }
        _ => return Err("invalid action".into()),
    }
    Ok(())
}
