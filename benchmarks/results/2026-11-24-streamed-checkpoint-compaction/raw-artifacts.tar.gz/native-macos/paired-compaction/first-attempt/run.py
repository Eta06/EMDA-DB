import hashlib
import json
import re
import statistics
import subprocess
import sys
from collections import defaultdict
from pathlib import Path

parent, baseline, candidate, evidence  = map(Path, sys.argv[1:5])
binaries = {"baseline": baseline, "candidate": candidate}
rows = []

def run(name, args, timed=False):
    command = ["/usr/bin/time", "-l", *map(str, args)] if timed else list(map(str, args))
    result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=180)
    (evidence / (name + ".stdout")).write_bytes(result.stdout)
    (evidence / (name + ".stderr")).write_bytes(result.stderr)
    with (evidence / "commands.jsonl").open("a") as output:
        print(json.dumps({"name": name, "command": command, "returncode": result.returncode}), file=output)
    result.check_returncode()
    return result.stdout.decode(), result.stderr.decode()

def digest(path, offset=0):
    with path.open("rb") as data:
        data.seek(offset)
        return hashlib.file_digest(data, "sha256").hexdigest()

def state(root):
    owned = ("source/records.log", "source/commit.state", "index", "source.digest")
    return {name: digest(root / name) for name in owned}

for case in ("small", "mixed"):
    root = parent / case
    root.mkdir(parents=True, exist_ok=False)
    run(case + "-prepare", [baseline, "prepare", case, root])
    before = state(root)
    expected = None
    for round_index in range(6):
        order = ["baseline", "candidate"]
        if round_index % 2:
            order.reverse()
        for backend in order:
            name = f"{case}-{round_index + 1}-{backend}"
            out = root / name
            binding = root / (name + ".digest")
            stdout, stderr = run(name,
                [binaries[backend], "compact", case, root, out, binding], timed=True)
            run(name + "-verify", [candidate, "verify", case, root, out, binding])
            checksum = digest(out / "records.log", 28)
            expected = checksum if expected is None else expected
            assert checksum == expected
            current = state(root)
            assert current == before
            rows.append({
                "case": case, "round": round_index + 1, "backend": backend,
                "compaction_us": int(re.search(r"compaction_us=(\d+)", stdout)[1]),
                "peak_rss_bytes": int(re.search(r"(\d+)\s+maximum resident set size", stderr)[1]),
                "target_log_bytes": (out / "records.log").stat().st_size,
                "target_record_sha256": checksum,
                "source": current,
            })
            with (evidence / "results.jsonl").open("a") as log:
                print(json.dumps(rows[-1]), file=log)

samples = defaultdict(list)
for row in rows:
    samples[row["case"], row["backend"]].append(row)
for key, group in samples.items():
    metrics = {metric: {"median": statistics.median(item[metric] for item in group),
                        "min": min(item[metric] for item in group),
                        "max": max(item[metric] for item in group)}
               for metric in ("compaction_us", "peak_rss_bytes")}
    print(*key, json.dumps(metrics))
