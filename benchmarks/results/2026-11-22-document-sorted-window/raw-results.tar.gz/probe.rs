use database_engine::{CheckpointStore, DocumentDatabase, DocumentQuery, DocumentSort, Store};
use std::{error::Error, fs, path::Path, time::Instant};

fn scan(db: &DocumentDatabase<'_>) -> Result<(), Box<dyn Error>> {
    let start = Instant::now();
    let result = db.query(
        "c",
        &DocumentQuery {
            sort: Some(DocumentSort {
                path: vec!["n".into()],
                descending: true,
            }),
            offset: 3,
            limit: 5,
            projection: Some(vec![vec!["n".into()]]),
            max_scanned: 192,
            ..DocumentQuery::default()
        },
    )?;
    let elapsed = start.elapsed().as_nanos();
    assert_eq!(result.plan.scanned, 192);
    assert_eq!(result.plan.matched, 192);
    assert_eq!(result.plan.returned, 5);
    assert!(result.plan.sorted);
    for (row, id) in result.documents.iter().zip((184..=188).rev()) {
        assert_eq!(row.id, format!("{id:03}"));
        assert_eq!(row.document, serde_json::json!({"n":id}));
    }
    println!("query_ns={elapsed} documents=192 returned=5");
    Ok(())
}

fn main() -> Result<(), Box<dyn Error>> {
    let args = std::env::args().collect::<Vec<_>>();
    let [_, mode, directory] = args.as_slice() else {
        return Err("usage: probe ordinary|checkpoint DIRECTORY".into());
    };
    let directory = Path::new(directory);
    let source = directory.join("store");
    let checkpoint = directory.join("checkpoint");
    match mode.as_str() {
        "ordinary" => {
            let store = Store::open(&source)?;
            scan(&DocumentDatabase::new(&store))?;
        }
        "checkpoint" => {
            let digest: [u8; 32] = fs::read(directory.join("digest"))?
                .try_into()
                .map_err(|_| "wrong checkpoint digest length")?;
            let store = CheckpointStore::open(&source, &checkpoint, &digest)?;
            scan(&DocumentDatabase::with_checkpoint_store(&store))?;
        }
        _ => return Err("unknown mode".into()),
    }
    Ok(())
}
