\set id 0
BEGIN ISOLATION LEVEL SERIALIZABLE;
SELECT value AS first FROM kv WHERE key = 'a' || :id \gset
SELECT value AS second FROM kv WHERE key = 'b' || :id \gset
\if :first != :second
SELECT 1 / 0;
\endif
UPDATE kv SET value = :first + 1 WHERE key = 'a' || :id;
UPDATE kv SET value = :second + 1 WHERE key = 'b' || :id;
COMMIT;
