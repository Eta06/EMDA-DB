import json, os, re, subprocess, sys, tempfile, time
binary, pgdir, out = sys.argv[1], sys.argv[2], sys.argv[3]
PG = '/opt/homebrew/opt/postgresql@17/bin'
sock = open(os.path.join(pgdir, 'sockdir')).read().strip()
base = ['-h', sock, '-p', '55432', '-U', 'bench']
def psql(sql):
    return subprocess.run([PG + '/psql', *base, '-d', 'bench', '-v', 'ON_ERROR_STOP=1', '-Atc', sql],
                          check=True, capture_output=True, text=True).stdout
def server_rss_kib():
    pid = open(os.path.join(pgdir, 'data', 'postmaster.pid')).readline().strip()
    children = subprocess.run(['pgrep', '-P', pid], capture_output=True, text=True).stdout.split()
    rss = subprocess.run(['ps', '-o', 'rss=', '-p', ','.join([pid, *children])], capture_output=True, text=True).stdout.split()
    return sum(int(x) for x in rss)
results = []
for trial in range(3):
    for backend in ('readset', 'checkpoint-readset', 'sqlite'):
        with tempfile.TemporaryDirectory(dir=os.path.dirname(out)) as d:
            run = subprocess.run(['/usr/bin/time', '-l', binary, backend, '8', '100', 'disjoint', d],
                                 check=True, capture_output=True, text=True)
        fields = dict(p.split('=', 1) for p in run.stdout.split())
        rss = int(re.search(r'(\d+)\s+maximum resident set size', run.stderr).group(1))
        row = dict(trial=trial, backend=backend, reopen_verify_ms=int(fields['reopen_ns']) / 1e6,
                   peak_rss_bytes=rss, scope='process including workload')
        results.append(row); print(json.dumps(row), flush=True)
    psql('DROP TABLE IF EXISTS kv; CREATE TABLE kv(key text PRIMARY KEY, value bigint NOT NULL);'
         + ''.join(f"INSERT INTO kv VALUES ('a{i}', 0), ('b{i}', 0);" for i in range(8)))
    subprocess.run([PG + '/pgbench', *base, '-n', '-c', '8', '-j', '8', '-t', '100', '-M', 'prepared',
                    '--max-tries=1000000', '-f', os.path.join(pgdir, 'scripts', 'disjoint.sql'), 'bench'],
                   check=True, capture_output=True)
    rss = server_rss_kib() * 1024
    log = os.path.join(pgdir, 'server.log')
    subprocess.run([PG + '/pg_ctl', '-D', os.path.join(pgdir, 'data'), '-m', 'immediate', 'stop'], check=True, capture_output=True)
    mark = os.path.getsize(log)
    started = time.monotonic()
    subprocess.run([PG + '/pg_ctl', '-D', os.path.join(pgdir, 'data'), '-l', log, '-w', 'start'], check=True, capture_output=True)
    values = dict(line.split('|') for line in psql('SELECT key, value FROM kv').split())
    elapsed = (time.monotonic() - started) * 1e3
    with open(log) as f:
        f.seek(mark); recovered = 'automatic recovery in progress' in f.read()
    if not recovered or any(int(v) != 100 for v in values.values()) or len(values) != 16:
        raise SystemExit(f'postgres recovery check failed: recovered={recovered} {values}')
    row = dict(trial=trial, backend='postgres', reopen_verify_ms=round(elapsed, 3), peak_rss_bytes=rss,
               scope='server processes after the workload; restart after immediate shutdown', crash_recovery=recovered)
    results.append(row); print(json.dumps(row), flush=True)
json.dump(results, open(out, 'w'), indent=1)
