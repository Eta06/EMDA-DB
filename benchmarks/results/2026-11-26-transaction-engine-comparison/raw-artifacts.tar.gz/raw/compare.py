import json, os, re, subprocess, sys, tempfile, glob
binary, pgdir, out = sys.argv[1], sys.argv[2], sys.argv[3]
PG = '/opt/homebrew/opt/postgresql@17/bin'
sock = open(os.path.join(pgdir, 'sockdir')).read().strip()
base = ['-h', sock, '-p', '55432', '-U', 'bench']
def psql(sql, db='bench'):
    return subprocess.run([PG + '/psql', *base, '-d', db, '-v', 'ON_ERROR_STOP=1', '-Atc', sql],
                          check=True, capture_output=True, text=True).stdout
subprocess.run([PG + '/psql', *base, '-d', 'postgres', '-c', 'DROP DATABASE IF EXISTS bench'], check=True, capture_output=True)
subprocess.run([PG + '/psql', *base, '-d', 'postgres', '-c', 'CREATE DATABASE bench'], check=True, capture_output=True)
def pct(samples, q):
    s = sorted(samples); return s[min(len(s) - 1, int(len(s) * q))]
def engine(mode, clients, workload, directory):
    line = subprocess.run([binary, mode, str(clients), '100', workload, directory], check=True,
                          capture_output=True, text=True).stdout.strip()
    f = dict(p.split('=', 1) for p in line.split())
    samples = [int(x) / 1e6 for x in f['samples_ns'].split(',')]
    return dict(tps=len(samples) / (int(f['elapsed_ns']) / 1e9), p50_ms=pct(samples, .5),
                p99_ms=pct(samples, .99), conflicts=sum(int(x) for x in f['conflicts'].split(',')),
                transactions=len(samples))
def postgres(clients, workload, directory):
    pairs = clients if workload == 'disjoint' else 1
    psql('DROP TABLE IF EXISTS kv; CREATE TABLE kv(key text PRIMARY KEY, value bigint NOT NULL);'
         + ''.join(f"INSERT INTO kv VALUES ('a{i}', 0), ('b{i}', 0);" for i in range(pairs)))
    psql('CHECKPOINT')
    run = subprocess.run([PG + '/pgbench', *base, '-n', '-c', str(clients), '-j', str(clients), '-t', '100',
                          '-M', 'prepared', '--max-tries=1000000', '-l', '--log-prefix=' + directory + '/log',
                          '-f', os.path.join(pgdir, 'scripts', workload + '.sql'), 'bench'],
                         check=True, capture_output=True, text=True).stdout
    samples = []
    for path in glob.glob(directory + '/log*'):
        for line in open(path):
            samples.append(int(line.split()[2]) / 1e3)
    tps = float(re.search(r'tps = ([0-9.]+) \(without initial connection time\)', run).group(1))
    retries = int(re.search(r'total number of retries: (\d+)', run).group(1)) if 'total number of retries' in run else 0
    failed = int(re.search(r'number of failed transactions: (\d+)', run).group(1))
    rows = dict(line.split('|') for line in psql('SELECT key, value FROM kv').split())
    expected = 100 * (clients if workload == 'shared' else 1)
    if failed or any(int(v) != expected for v in rows.values()):
        raise SystemExit(f'postgres verification failed: {rows} failed={failed}')
    return dict(tps=tps, p50_ms=pct(samples, .5), p99_ms=pct(samples, .99), conflicts=retries,
                transactions=len(samples))
backends = ['readset', 'conservative', 'checkpoint-readset', 'sqlite', 'postgres']
results = []
for trial in range(3):
    order = backends[trial % len(backends):] + backends[:trial % len(backends)]
    for clients in (1, 8):
        for workload in ('disjoint', 'shared'):
            for backend in order:
                with tempfile.TemporaryDirectory(dir=os.path.dirname(out)) as d:
                    row = postgres(clients, workload, d) if backend == 'postgres' else engine(backend, clients, workload, d)
                row.update(trial=trial, clients=clients, workload=workload, backend=backend)
                row = {k: (round(v, 3) if isinstance(v, float) else v) for k, v in row.items()}
                results.append(row)
                print(json.dumps(row), flush=True)
json.dump(results, open(out, 'w'), indent=1)
