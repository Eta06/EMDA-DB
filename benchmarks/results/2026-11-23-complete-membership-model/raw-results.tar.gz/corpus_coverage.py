"""Count retained corpus inputs reaching each complete-membership model mode."""
import sys
from pathlib import Path

cases = [[0] * 5 for _ in range(4)]
for path in Path(sys.argv[1]).iterdir():
    data = path.read_bytes()
    if not data or not data[0] & 4:
        continue
    modes = {data[offset] % 5 for offset in range(1, len(data) - 3, 4)}
    for mode in modes:
        cases[data[0] & 3][mode] += 1

print("| Backend and index | Exact 256 | Grouped 256 | Grouped 258 | Sparse over cap | Four grouped probes |")
print("| --- | ---: | ---: | ---: | ---: | ---: |")
for name, row in zip(("Ordinary", "Checkpoint", "Ordinary partial", "Checkpoint partial"), cases):
    assert all(row), (name, row)
    print("| " + " | ".join([name, *map(str, row)]) + " |")
