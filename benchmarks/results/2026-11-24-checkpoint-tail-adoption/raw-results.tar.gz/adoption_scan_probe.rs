use database_engine::{BatchOperation, CheckpointStore, Store};
use std::{env, fs, io, path::Path};

fn witness(path: &Path) -> io::Result<Vec<u8>> {
    let log = fs::File::open(path.join("live/records.log"))?;
    let mut bytes = [0; 64];
    let size = rustix::fs::fgetxattr(&log, "user.db.commit.v3", &mut bytes)?;
    Ok(bytes[..size].to_vec())
}

fn run() -> io::Result<()> {
    let args: Vec<_> = env::args().skip(1).collect();
    let path = Path::new(&args[1]);
    match args[0].as_str() {
        "setup" => {
            let size: u64 = args[2].parse().unwrap();
            fs::create_dir(path)?;
            let store = Store::open(path.join("live"))?;
            let value = vec![39; 1024 * 1024];
            for _ in 0..size { store.put(b"key", &value)?; }
            let digest = store.checkpoint_to(path.join("index"))?;
            fs::write(path.join("digest"), digest)?;
            fs::write(path.join("pending"), witness(path)?)?;
            store.write_batch(&[BatchOperation::Delete { key: b"key" },
                BatchOperation::Put { key: b"key", value: b"current" }])?;
            fs::write(path.join("acknowledged"), witness(path)?)?;
        }
        "reset" => {
            let log = fs::File::open(path.join("live/records.log"))?;
            let bytes = fs::read(path.join(&args[2]))?;
            rustix::fs::fsetxattr(&log, "user.db.commit.v3", &bytes, rustix::fs::XattrFlags::REPLACE)?;
        }
        "open" => {
            let digest: [u8; 32] = fs::read(path.join("digest"))?.try_into().unwrap();
            let store = CheckpointStore::open(path.join("live"), path.join("index"), &digest)?;
            assert_eq!(store.get(b"key")?.as_deref(), Some(b"current".as_slice()));
            println!("verified");
        }
        "check" => assert_eq!(witness(path)?, fs::read(path.join("acknowledged"))?),
        _ => panic!("unknown mode"),
    }
    Ok(())
}

fn main() -> io::Result<()> { run() }
