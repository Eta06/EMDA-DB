set -e
cd "$1"
mkdir evidence-repeat
sha256sum fixture-*/digest fixture-*/index fixture-*/pending fixture-*/acknowledged fixture-*/live/* | sort >evidence-repeat/source-before.sha256
for size in 1 8 32; do
    for mode in pending acknowledged; do
        for round in 1 2 3; do
            order="candidate baseline"
            if [ "$round" = 2 ]; then order="baseline candidate"; fi
            for variant in $order; do
                name="evidence-repeat/$size-$mode-$round-$variant"
                "./$variant" reset "$1/fixture-$size" "$mode"
                strace -s 0 -y -qq -e trace=read,pread64,preadv,fsetxattr,write,pwrite64,fdatasync,fsync -o "$name.trace" "$1/$variant" open "$1/fixture-$size" >"$name.log" 2>&1
                "./$variant" check "$1/fixture-$size"
            done
        done
    done
done
sha256sum fixture-*/digest fixture-*/index fixture-*/pending fixture-*/acknowledged fixture-*/live/* | sort >evidence-repeat/source-after.sha256
cmp evidence-repeat/source-before.sha256 evidence-repeat/source-after.sha256
