from collections import defaultdict
from pathlib import Path
import csv
import re
import sys

root = Path(sys.argv[1])
totals = defaultdict(list)
read_call = re.compile(r"^(?:read|pread64|preadv)\(\d+<[^>]+/records\.log>.*\)\s+= (\d+)$")
for trace in sorted(root.glob("*.trace")):
    size, mode, round_number, variant = trace.stem.split("-")
    assert trace.with_suffix(".log").read_text().strip() == "verified", trace
    lines = trace.read_text().splitlines()
    writes = [line for line in lines if line.startswith(("write(", "pwrite64("))]
    assert all(not any(name in line for name in ("/records.log>", "/commit.state>", "/index>"))
               for line in writes), trace
    updates = [line for line in lines if line.startswith("fsetxattr(")]
    assert len(updates) == (mode == "pending") and all(line.endswith("= 0") for line in updates), trace
    if mode == "pending":
        fd = updates[0].split("(", 1)[1].split(">", 1)[0] + ">"
        assert any(line.startswith(f"fsync({fd})") and line.endswith("= 0")
                   for line in lines[lines.index(updates[0]) + 1:]), trace
    count = sum(int(match[1]) for line in lines if (match := read_call.match(line)))
    totals[size, mode, variant].append(count)
assert len(totals) == 12 and all(len(values) == 3 and len(set(values)) == 1 for values in totals.values())
writer = csv.writer(sys.stdout)
writer.writerow(("history_mib", "mode", "baseline_log_bytes", "candidate_log_bytes", "saved_bytes"))
for size in ("1", "8", "32"):
    for mode in ("pending", "acknowledged"):
        before = totals[size, mode, "baseline"][0]
        after = totals[size, mode, "candidate"][0]
        assert before > after if mode == "pending" else before == after
        writer.writerow((size, mode, before, after, before - after))
