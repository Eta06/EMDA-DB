use database_engine::{BatchOperation, CheckpointStore, Store};
use std::alloc::{GlobalAlloc, Layout, System};
use std::fs;
use std::io;
use std::path::Path;
use std::sync::atomic::{AtomicUsize, Ordering};
use std::time::Instant;

static ALLOCATION_CALLS: AtomicUsize = AtomicUsize::new(0);

struct CountingAllocator;

#[global_allocator]
static GLOBAL: CountingAllocator = CountingAllocator;

// Counting does not change the allocation contract. System performs allocation,
// deallocation and reallocation with the caller's original pointer and layout.
unsafe impl GlobalAlloc for CountingAllocator {
    unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
        ALLOCATION_CALLS.fetch_add(1, Ordering::Relaxed);
        unsafe { System.alloc(layout) }
    }

    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        ALLOCATION_CALLS.fetch_add(1, Ordering::Relaxed);
        unsafe { System.alloc_zeroed(layout) }
    }

    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, size: usize) -> *mut u8 {
        ALLOCATION_CALLS.fetch_add(1, Ordering::Relaxed);
        unsafe { System.realloc(ptr, layout, size) }
    }

    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout) {
        unsafe { System.dealloc(ptr, layout) }
    }
}

fn key(id: u64) -> Vec<u8> {
    let mut key = id.to_be_bytes().to_vec();
    key.resize([8, 32, 128, 256][id as usize % 4], id as u8);
    key
}

fn prepare(path: &Path, keys: u64) -> io::Result<()> {
    fs::create_dir(path)?;
    let store = Store::open(path.join("store"))?;
    write_rows(&store, 0, 256)?;
    let digest = store.checkpoint_to(path.join("index"))?;
    fs::write(path.join("digest"), digest)?;
    write_rows(&store, 256, 256 + keys)
}

fn write_rows(store: &Store, start: u64, end: u64) -> io::Result<()> {
    for batch_start in (start..end).step_by(256) {
        let rows: Vec<_> = (batch_start..(batch_start + 256).min(end))
            .map(|id| (key(id), id.to_le_bytes()))
            .collect();
        let batch: Vec<_> = rows
            .iter()
            .map(|(key, value)| BatchOperation::Put { key, value })
            .collect();
        store.write_batch(&batch)?;
    }
    Ok(())
}

fn measure(path: &Path, keys: u64) -> io::Result<()> {
    let digest = fs::read(path.join("digest"))?
        .try_into()
        .map_err(|_| io::Error::other("invalid fixture digest"))?;
    let store = path.join("store");
    let checkpoint = path.join("index");
    let store = CheckpointStore::open(store, checkpoint, &digest)?;
    let mut views = Vec::with_capacity(16);
    let start = Instant::now();
    let before = ALLOCATION_CALLS.load(Ordering::Relaxed);
    for _ in 0..16 {
        views.push(store.snapshot()?);
    }
    let captures = ALLOCATION_CALLS.load(Ordering::Relaxed) - before;
    let capture_ns = start.elapsed().as_nanos();
    let budget = store.snapshot_budget_status()?;
    assert_eq!(budget.active, 16);
    assert_eq!(budget.keys, keys as usize * 16);
    let touched = key(256);
    let mut writes = [(0, 0); 2];
    for (value, work) in [b"first", b"later"].into_iter().zip(&mut writes) {
        let start = Instant::now();
        let before = ALLOCATION_CALLS.load(Ordering::Relaxed);
        store.put(&touched, value)?;
        *work = (
            ALLOCATION_CALLS.load(Ordering::Relaxed) - before,
            start.elapsed().as_nanos(),
        );
    }
    assert_eq!(store.get(&touched)?.as_deref(), Some(b"later".as_slice()));
    for view in &views {
        for id in [0, 256, 255 + keys] {
            assert_eq!(
                view.get(&key(id))?.as_deref(),
                Some(id.to_le_bytes().as_slice())
            );
        }
    }
    drop(views);
    let released = store.snapshot_budget_status()?;
    assert_eq!((released.active, released.blocks, released.keys), (0, 0, 0));
    println!(
        "keys={keys} counts={captures} capture_ns={capture_ns} first_allocs={} first_ns={} next_allocs={} next_ns={}",
        writes[0].0, writes[0].1, writes[1].0, writes[1].1,
    );
    Ok(())
}

fn main() -> io::Result<()> {
    let args: Vec<_> = std::env::args().collect();
    let [_, mode, directory, keys] = args.as_slice() else {
        return Err(io::Error::other(
            "expected mode, fixture directory, and key count",
        ));
    };
    let keys = keys.parse::<u64>().map_err(io::Error::other)?;
    if !(1..=4096).contains(&keys) {
        return Err(io::Error::other("key count must be between 1 and 4096"));
    }
    let directory = Path::new(directory);
    match mode.as_str() {
        "prepare" => prepare(directory, keys),
        "measure" => measure(directory, keys),
        _ => Err(io::Error::other("expected prepare or measure")),
    }
}
