"""Measure snapshots and two writes over paired checkpoint fixtures."""
import argparse
import json
from pathlib import Path
import shutil
import subprocess
import tempfile


def run(args):
    return subprocess.run(args, check=True, capture_output=True, text=True, timeout=60).stdout


def paired(workspace):
    rows = []
    for keys in (64, 4096):
        with tempfile.TemporaryDirectory(prefix=f"keys-{keys}-", dir=workspace) as owned:
            seed = Path(owned) / "fixture"
            run([str(workspace / "baseline"), "prepare", str(seed), str(keys)])
            for pair in range(5):
                order = ("baseline", "candidate") if pair % 2 == 0 else ("candidate", "baseline")
                samples = {}
                for build in order:
                    fixture = Path(owned) / f"{pair}-{build}"
                    # copy2 preserves the fixture's log xattr on Linux.
                    shutil.copytree(seed, fixture)
                    output = run([str(workspace / build), "measure", str(fixture), str(keys)])
                    sample = {key: int(value) for key, value in (entry.split("=") for entry in output.split())}
                    assert sample["keys"] == keys
                    rows.append({"build": build, "pair": pair, **sample})
                    samples[build] = sample
                old, new = samples["baseline"], samples["candidate"]
                assert old["counts"] - new["counts"] >= keys * 16
                assert new["first_allocs"] - new["next_allocs"] >= keys
                assert old["first_allocs"] == old["next_allocs"] == new["next_allocs"]
    return rows


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("workspace", type=Path)
    args = parser.parse_args()
    print(json.dumps(paired(args.workspace.resolve()), indent=2))
