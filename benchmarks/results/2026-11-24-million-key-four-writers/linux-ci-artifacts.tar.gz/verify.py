import json
import pathlib
import sys

root = pathlib.Path(sys.argv[1])
revision = sys.argv[2]
state = json.loads((root / "jobs.json").read_text())
assert state["headSha"] == revision
assert state["status"] == "completed" and state["conclusion"] == "success"
assert all(job["conclusion"] == "success" for job in state["jobs"])
attempts = list((root / "ci-benchmark-smoke").rglob("attempt.json"))
assert len(attempts) == 45, len(attempts)
assert (root / "workflow.log").stat().st_size > 0
for path in attempts:
    attempt = json.loads(path.read_text())
    assert attempt["revision"] == revision and attempt["tracked_changes"] == ""
    assert attempt["status"] == "exited"
    assert attempt["returncode"] == attempt["wrapper_exit_code"] == 0
    assert (path.parent / attempt["output"]).is_file()
print(f"{revision[:7]} verified {len(attempts)} standard Linux smoke attempts")
