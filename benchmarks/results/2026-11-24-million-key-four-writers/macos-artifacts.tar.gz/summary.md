| Engine | Ready wall ms | Ready CPU ms | Reopen peak RSS MiB | Mutation peak RSS MiB | Write epoch ms | Verified scan ms | Sampled allocation peak MiB | Rotations | Rollovers |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| ordinary | 252.97 | 247.45 | 128.06 | 128.61 | 1351.99 | 301.50 | 144.24 | 0 | 0 |
| checkpoint | 109.66 | 102.55 | 5.20 | 7.31 | 2073.76 | 321.01 | 222.22 | 0 | 4 |
| retained | 100.89 | 89.53 | 7.03 | 7.56 | 5213.31 | 169.24 | 358.94 | 1 | 0 |
| sqlite | 1.54 | 0.62 | 3.23 | 5.75 | 51.64 | 159.83 | 154.66 | 0 | 0 |
