import argparse
import json
import statistics
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument("measurements", type=Path)
parser.add_argument("--linux-ceiling", action="store_true")
args = parser.parse_args()
backends = ("ordinary", "checkpoint", "retained", "sqlite")
keys, writers, operations, limit = 1_048_576, 4, 32_768, 48 * 1024**2
rows = [json.loads(line) for line in args.measurements.read_text().splitlines()]
expected = {(backend, epoch, phase) for backend in backends for epoch in range(1, 5)
            for phase in ("mutate", "reopen", "verify")}
expected |= {("all", 0, "setup"), ("checkpoint", 0, "checkpoint-setup"),
             ("retained", 0, "cutover")}
assert len(rows) == len(expected), len(rows)
assert {(row["backend"], row["epoch"], row["phase"]) for row in rows} == expected
for row in rows:
    assert row["keys"] == keys and row["exit"] == 0 and row["peak_rss_bytes"] > 0, row
    capped = args.linux_ceiling and row["epoch"] and row["backend"] in {"checkpoint", "retained"}
    assert row["address_space_limit_bytes"] == (limit if capped else None), row
    assert not capped or row["peak_rss_bytes"] <= limit, row
    if row["phase"] == "mutate":
        assert row["writers"] == writers and row["operations"] == operations, row
    if row["phase"] == "verify":
        deleted = sum((key + row["epoch"]) % 11 == 0 for key in range(operations))
        assert row["verified_entries"] == keys - deleted, row

print("| Engine | Ready wall ms | Ready CPU ms | Reopen peak RSS MiB | Mutation peak RSS MiB | "
      "Write epoch ms | Verified scan ms | Sampled allocation peak MiB | Rotations | Rollovers |")
print("| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |")
for engine in backends:
    group = [row for row in rows if row["backend"] == engine and row["epoch"]]
    reopen = [row for row in group if row["phase"] == "reopen"]
    mutate = [row for row in group if row["phase"] == "mutate"]
    verify = [row for row in group if row["phase"] == "verify"]
    def median_ms(phases, field):
        return statistics.median(row[field] for row in phases) / 1e6
    def peak_mib(phases, field):
        return max(row[field] for row in phases) / 2**20
    rotations = sum(row.get("rotations", 0) for row in mutate)
    rollovers = sum(row.get("checkpoint_advanced", 0) for row in mutate)
    if engine == "retained":
        assert rotations > 0
    if engine == "checkpoint":
        assert rollovers > 0
    print(f"| {engine} | {median_ms(reopen, 'ready_ns'):.2f} | "
          f"{median_ms(reopen, 'ready_cpu_ns'):.2f} | {peak_mib(reopen, 'peak_rss_bytes'):.2f} | "
          f"{peak_mib(mutate, 'peak_rss_bytes'):.2f} | {median_ms(mutate, 'mutate_ns'):.2f} | "
          f"{median_ms(verify, 'verify_ns'):.2f} | {peak_mib(group, 'allocated_peak_sample_bytes'):.2f} | "
          f"{rotations} | {rollovers} |")
