| Engine | Ready wall ms | Ready CPU ms | Reopen peak RSS MiB | Mutation peak RSS MiB | Write epoch ms | Verified scan ms | Sampled allocation peak MiB | Rotations | Rollovers |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| ordinary | 414.98 | 414.69 | 131.30 | 131.53 | 57.58 | 361.74 | 139.78 | 0 | 0 |
| checkpoint | 157.54 | 157.41 | 6.10 | 7.36 | 1059.63 | 373.92 | 217.67 | 0 | 4 |
| retained | 186.44 | 186.25 | 7.31 | 7.43 | 230.02 | 268.74 | 358.95 | 1 | 0 |
| sqlite | 0.80 | 0.80 | 4.96 | 6.82 | 68.44 | 280.20 | 137.73 | 0 | 0 |
