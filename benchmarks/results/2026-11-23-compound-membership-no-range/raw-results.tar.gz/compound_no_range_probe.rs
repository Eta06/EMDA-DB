//! Paired index probe workloads for EMDA-DB and bundled SQLite.
use database_engine::{
    CollectionSchema, DocumentDatabase, DocumentFilter, DocumentQuery, DocumentQueryAccess,
    IndexDefinition, Store,
};
use rusqlite::{Connection, params, params_from_iter};
use serde_json::{Value, json};
use std::{error::Error, path::Path, time::Instant};

type Result<T> = std::result::Result<T, Box<dyn Error>>;
type Row = (String, Value);
const ROWS: i64 = 768;
const INDEX: &str = "tenant_score";
const WARMUPS: usize = 15;
const SAMPLES: usize = 100;

fn documents() -> impl Iterator<Item = (i64, Row)> {
    (0..ROWS).rev().map(|score| {
        (
            score,
            (
                format!("id-{:04}", ROWS - 1 - score),
                json!({
                    "tenant": if score % 4 == 0 { "other" } else { "target" },
                    "score": score,
                    "payload": "small indexed document",
                }),
            ),
        )
    })
}

fn configure(sqlite: &Connection) -> Result<()> {
    let mode: String = sqlite.query_row("PRAGMA journal_mode=WAL", [], |row| row.get(0))?;
    sqlite.pragma_update(None, "synchronous", "FULL")?;
    let sync: i64 = sqlite.pragma_query_value(None, "synchronous", |row| row.get(0))?;
    assert_eq!(mode, "wal");
    assert_eq!(sync, 2);
    Ok(())
}

fn seed(root: &Path) -> Result<()> {
    let store = Store::open(root.join("store"))?;
    let db = DocumentDatabase::new(&store);
    db.create_collection("docs", CollectionSchema::default())?;
    db.create_index(
        "docs",
        IndexDefinition {
            name: INDEX.into(),
            fields: vec![vec!["tenant".into()], vec!["score".into()]],
            unique: false,
            partial: None,
        },
    )?;
    let mut sqlite = Connection::open(root.join("sqlite.db"))?;
    configure(&sqlite)?;
    sqlite.execute_batch(
        "CREATE TABLE docs(id TEXT PRIMARY KEY, body TEXT NOT NULL CHECK(json_valid(body))) WITHOUT ROWID;
         CREATE INDEX docs_tenant_score ON docs(json_extract(body,'$.tenant'),json_extract(body,'$.score'));",
    )?;
    let data: Vec<_> = documents().map(|(_, row)| row).collect();
    for chunk in data.chunks(32) {
        db.transaction(|tx| {
            for (id, doc) in chunk {
                tx.insert("docs", id, doc)?;
            }
            Ok(())
        })?;
        let transaction = sqlite.transaction()?;
        for (id, doc) in chunk {
            transaction.execute(
                "INSERT INTO docs(id,body) VALUES(?1,?2)",
                params![id, serde_json::to_string(doc)?],
            )?;
        }
        transaction.commit()?;
    }
    Ok(())
}

struct Case {
    name: &'static str,
    query: DocumentQuery,
    sql: String,
    parameters: Vec<i64>,
    expected: Vec<Row>,
}

impl Case {
    fn new(name: &'static str, list: Vec<i64>) -> Self {
        let filters = vec![
            DocumentFilter::In {
                path: vec!["tenant".into()],
                values: vec![json!("target"), json!("other")],
            },
            DocumentFilter::In {
                path: vec!["score".into()],
                values: list.iter().map(|score| json!(score)).collect(),
            },
        ];
        let sql = format!(
            "SELECT id, body FROM docs INDEXED BY docs_tenant_score
             WHERE json_extract(body,'$.tenant') IN ('target','other')
             AND json_extract(body,'$.score') IN ({}) ORDER BY id",
            vec!["?"; list.len()].join(","),
        );
        let expected = documents()
            .filter(|(score, _)| list.contains(score))
            .map(|(_, row)| row)
            .collect();
        Self {
            name,
            expected,
            sql,
            parameters: list,
            query: DocumentQuery {
                filter: DocumentFilter::And(filters),
                max_scanned: ROWS as usize,
                limit: 256,
                ..Default::default()
            },
        }
    }

    fn sqlite_rows(&self, sqlite: &Connection) -> Result<Vec<Row>> {
        let mut statement = sqlite.prepare_cached(&self.sql)?;
        let rows = statement.query_map(params_from_iter(&self.parameters), |row| {
            Ok((row.get::<_, String>(0)?, row.get::<_, String>(1)?))
        })?;
        rows.map(|row| {
            let (id, body) = row?;
            Ok((id, serde_json::from_str(&body)?))
        })
        .collect()
    }

    fn explain(&self, sqlite: &Connection) -> Result<Vec<String>> {
        let mut statement = sqlite.prepare(&format!("EXPLAIN QUERY PLAN {}", self.sql))?;
        let rows = statement.query_map(params_from_iter(&self.parameters), |row| row.get(3))?;
        let plan = rows.collect::<std::result::Result<Vec<String>, _>>()?;
        assert!(
            plan.iter()
                .any(|line| line.contains("SEARCH docs USING INDEX docs_tenant_score"))
        );
        Ok(plan)
    }

    fn verify_emda_plan(
        &self,
        db: &DocumentDatabase<'_>,
        variant: &str,
    ) -> Result<(DocumentQueryAccess, usize)> {
        let result = db.query_planned("docs", &self.query)?;
        let (access, candidates) = match (variant, self.name) {
            (_, "within-cap") => (
                DocumentQueryAccess::CompoundMembershipIndex {
                    index: INDEX.into(),
                    fields: 2,
                    probes: 32,
                },
                16,
            ),
            ("after", "over-cap-grouped") => (
                DocumentQueryAccess::CompoundMembershipRangeIndex {
                    index: INDEX.into(),
                    prefix_fields: 1,
                    probes: 4,
                },
                self.expected.len(),
            ),
            ("before", "over-cap-grouped") | (_, "over-cap-sparse") => {
                (DocumentQueryAccess::CollectionScan, ROWS as usize)
            }
            _ => return Err("invalid benchmark case or variant".into()),
        };
        assert_eq!(result.access, access);
        assert_eq!(result.result.plan.scanned, candidates);
        let full = db.query("docs", &self.query)?;
        let rows = full
            .documents
            .into_iter()
            .map(|row| (row.id, row.document))
            .collect::<Vec<_>>();
        assert_eq!(rows, self.expected);
        Ok((result.access, result.result.plan.scanned))
    }
}

fn run(root: &Path, variant: &str, offset: usize) -> Result<()> {
    let store = Store::open(root.join("store"))?;
    let db = DocumentDatabase::new(&store);
    let sqlite = Connection::open(root.join("sqlite.db"))?;
    configure(&sqlite)?;
    let sqlite_version: String =
        sqlite.query_row("SELECT sqlite_version()", [], |row| row.get(0))?;
    let cases = [
        Case::new("within-cap", (32..64).step_by(2).collect()),
        Case::new("over-cap-grouped", (128..196).chain(316..384).collect()),
        Case::new("over-cap-sparse", (0..272).step_by(2).collect()),
    ];
    for index in 0..cases.len() {
        let case = &cases[(index + offset) % cases.len()];
        let (access, candidates) = case.verify_emda_plan(&db, variant)?;
        let explain = case.explain(&sqlite)?;
        let mut emda_times = Vec::with_capacity(SAMPLES);
        let mut sqlite_times = Vec::with_capacity(SAMPLES);
        for cycle in 0..(WARMUPS + SAMPLES) {
            for position in 0..2 {
                let sqlite_first = (cycle + position + offset) % 2 == 0;
                let start = Instant::now();
                let rows = if sqlite_first {
                    case.sqlite_rows(&sqlite)?
                } else {
                    db.query_planned("docs", &case.query)?
                        .result
                        .documents
                        .into_iter()
                        .map(|row| (row.id, row.document))
                        .collect()
                };
                let ns = start.elapsed().as_nanos() as u64;
                assert_eq!(rows, case.expected, "{} results", case.name);
                if cycle >= WARMUPS {
                    if sqlite_first {
                        sqlite_times.push(ns);
                    } else {
                        emda_times.push(ns);
                    }
                }
            }
        }
        println!(
            "{}",
            json!({
                "case": case.name, "variant": variant, "sqlite_version": sqlite_version,
                "sqlite_plan": explain, "emda_access": format!("{access:?}"), "candidates": candidates,
                "matches": case.expected.len(), "emda_ns": emda_times, "sqlite_ns": sqlite_times,
            })
        );
    }
    Ok(())
}

fn main() -> Result<()> {
    let args = std::env::args().collect::<Vec<_>>();
    match args.as_slice() {
        [_, phase, root] if phase == "seed" => seed(Path::new(root)),
        [_, phase, root, variant, offset] if phase == "run" => {
            run(Path::new(root), variant, offset.parse()?)
        }
        _ => Err("usage: compound_no_range_probe seed FIXTURE | run FIXTURE VARIANT OFFSET".into()),
    }
}
