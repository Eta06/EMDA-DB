use database_engine::retained_base_v2::Limits;
use database_engine::retained_candidate::{
    Expected, IndexLimits, ManagedRetainedStore, OverlayLimits, RetainedStoreLimits,
    SuffixExpected, SuffixLimits,
};
use std::fs;
use std::hash::{DefaultHasher, Hash, Hasher};
use std::path::Path;

const LIMITS: RetainedStoreLimits = RetainedStoreLimits {
    base: Limits {
        file_bytes: 64 * 1024 * 1024,
        work_bytes: 64 * 1024 * 1024 + 1,
        entries: 20_000,
        key_bytes: 1024 * 1024,
    },
    index: IndexLimits {
        blocks: 512,
        anchor_bytes: 512 * 1024,
    },
    suffix: SuffixLimits {
        bytes: 2 * 1024 * 1024,
        operations: 20_000,
        work: 100_000_000_000,
    },
    overlay: OverlayLimits {
        entries: 20_000,
        key_bytes: 1024 * 1024,
    },
};

fn read_binding(root: &Path) -> Result<SuffixExpected, Box<dyn std::error::Error>> {
    let candidate = fs::read(root.join("candidate.binding"))?;
    let suffix = fs::read(root.join("suffix.binding"))?;
    assert_eq!(candidate.len(), 176);
    assert_eq!(suffix.len(), 40);
    Ok(SuffixExpected {
        candidate: Expected {
            header: candidate[..112].try_into()?,
            witness: candidate[112..144].try_into()?,
            base_digest: candidate[144..].try_into()?,
        },
        end: u64::from_le_bytes(suffix[..8].try_into()?),
        digest: suffix[8..].try_into()?,
    })
}

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let args: Vec<String> = std::env::args().collect();
    let [_, phase, input, root] = args.as_slice() else {
        return Err("expected phase, input and catalog".into());
    };
    let input = Path::new(input);
    let root = Path::new(root);
    if phase == "create" {
        let expected = read_binding(input)?;
        ManagedRetainedStore::create_from_suffix(
            input.join("candidate"),
            input.join("suffix"),
            root,
            LIMITS,
            &expected,
        )?;
        return Ok(());
    }
    if phase == "auto" || phase == "manual" {
        use std::time::Instant;
        let mut db = if phase == "auto" {
            ManagedRetainedStore::open_with_auto_reclaim(root, LIMITS, 4096.try_into()?)?
        } else {
            ManagedRetainedStore::open(root, LIMITS)?
        };
        let mut prev = db.generation_id()?;
        println!("write_ms switched file_bytes");
        for i in 0..8 {
            let now = Instant::now();
            db.put(format!("probe-{i}").as_bytes(), &[i; 900])?;
            let millis = now.elapsed().as_secs_f64() * 1000.0;
            let current = db.generation_id()?;
            println!(
                "{millis:.3} {} {}",
                u8::from(prev != current),
                file_bytes(root)?
            );
            prev = current;
        }
        return Ok(());
    }
    let mut db = ManagedRetainedStore::open(root, LIMITS)?;
    match phase.as_str() {
        "compact" => {
            db.compact()?;
        }
        "reclaim" => {
            assert!(db.reclaim_inactive()?);
        }
        "scan" => {
            let mut after = None;
            let mut hasher = DefaultHasher::new();
            let mut count = 0;
            loop {
                let page = db.scan(after.as_deref(), None, 1024)?;
                let Some((key, _)) = page.last() else { break };
                assert!(after.as_ref().is_none_or(|prior| prior < key));
                after = Some(key.clone());
                count += page.len();
                for entry in page {
                    entry.hash(&mut hasher);
                }
            }
            println!("{count} {:016x}", hasher.finish());
        }
        _ => return Err("unknown phase".into()),
    }
    Ok(())
}

fn file_bytes(directory: &Path) -> std::io::Result<u64> {
    let mut bytes = 0;
    for child in fs::read_dir(directory)? {
        let child = child?;
        let kind = child.file_type()?;
        if kind.is_dir() {
            bytes += file_bytes(&child.path())?;
        } else if kind.is_file() {
            bytes += child.metadata()?.len();
        }
    }
    Ok(bytes)
}
