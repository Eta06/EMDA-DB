"""Pair two rotation implementations on the same witnessed seed."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import sys


def sha(file):
    with file.open("rb") as stream:
        digest = hashlib.sha256()
        for block in iter(lambda: stream.read(64 * 1024), b""):
            digest.update(block)
        return digest.hexdigest()


def source_identity(root):
    source = root / "records.log"
    with source.open("rb") as handle:
        magic = handle.read(8)
    return {
        "log": sha(source),
        "witness": sha(root / "commit.state"),
        "xattr": os.getxattr(source, "user.db.commit.v3").hex() if magic == b"EMDALOG3" else None,
    }


baseline, candidate, runner, root, keys = sys.argv[1:]
keys = int(keys)
module = importlib.util.spec_from_file_location("benchmark", runner)
benchmark = importlib.util.module_from_spec(module)
module.loader.exec_module(benchmark)
root = Path(root)
root.mkdir()
binaries = {"baseline": Path(baseline), "candidate": Path(candidate)}
digests = {label: sha(binary) for label, binary in binaries.items()}
assert digests["baseline"] != digests["candidate"]
seed = root / "seed"
seed.mkdir()
benchmark.run(binaries["baseline"], seed, "setup", "retained-only", keys, 0)
source = seed / "fixture" / "retained"
identity = source_identity(source)
(root / "environment.json").write_text(json.dumps({
    "binary_sha256": digests, "harness_sha256": sha(Path(runner)), "keys": keys,
    "suffix_work": os.environ["EMDA_BENCH_SUFFIX_WORK"], "seed": identity,
}, indent=2))
for shape in ("clustered", "spread"):
    if shape == "spread":
        os.environ["EMDA_BENCH_SPREAD"] = "1"
    else:
        os.environ.pop("EMDA_BENCH_SPREAD", None)
    work = root / shape
    work.mkdir()
    for label, binary in binaries.items():
        directory = work / label
        (directory / "fixture").mkdir(parents=True)
        target = directory / "fixture" / "retained"
        shutil.copytree(source, target)
        assert identity == source_identity(target)
        benchmark.run(binary, directory, "cutover", "retained", keys, 0)
    for epoch in range(1, 7):
        order = ("baseline", "candidate") if epoch % 2 else ("candidate", "baseline")
        verified = []
        for label in order:
            binary = binaries[label]
            directory = work / label
            writes = benchmark.run(binary, directory, "mutate", "retained", keys, epoch)
            reads = benchmark.run(binary, directory, "reopen", "retained", keys, epoch)
            scans = benchmark.run(binary, directory, "verify", "retained", keys, epoch)
            verified.append((writes["rotations"], reads["suffix_bytes"], scans["verified_entries"]))
        assert verified[0] == verified[1], (shape, epoch, verified)
        print(f"{shape=} {epoch=} rotations={verified[0][0]} verified_entries={verified[0][2]}", flush=True)
    for label in binaries:
        shutil.rmtree(work / label / "fixture")
assert identity == source_identity(source)
