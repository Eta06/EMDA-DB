"""Verify the paired rotation campaign and summarize phase CPU."""
import json
from pathlib import Path
from statistics import median
import sys


def load(parent, variant):
    rows = [
        json.loads(line)
        for line in (parent / variant / "measurements.jsonl").read_text().splitlines()
    ]
    assert len(rows) == 19
    assert all(row["exit"] == 0 and row["keys"] == 524288 for row in rows)
    table = {(row["epoch"], row["phase"]): row for row in rows}
    assert len(table) == len(rows)
    return table


def summarize(root):
    results = []
    for platform, path in (("macos", root / "macos"), ("linux", root / "evidence/linux")):
        environment = json.loads((path / "environment.json").read_text())
        assert environment["keys"] == 524288 and environment["suffix_work"] == "240000000"
        assert len(set(environment["binary_sha256"].values())) == 2
        for shape in ("clustered", "spread"):
            baseline, candidate = (load(path / shape, variant) for variant in ("baseline", "candidate"))
            stride = 128 if shape == "spread" else 1
            rotations = []
            for epoch in range(1, 7):
                expected = 524288 - sum((index * stride + epoch) % 11 == 0 for index in range(4096))
                left, right = (table[epoch, "mutate"] for table in (baseline, candidate))
                assert left["rotations"] == right["rotations"]
                assert left["operations"] == right["operations"] == 4096
                assert left["batches"] == right["batches"] == 32
                assert baseline[epoch, "verify"]["verified_entries"] == candidate[epoch, "verify"]["verified_entries"] == expected
                if left["rotations"]:
                    rotations.append(epoch)
            assert rotations
            write_cpu = [[table[epoch, "mutate"]["mutate_cpu_ns"] / 1e6 for epoch in rotations]
                         for table in (baseline, candidate)]
            write_wall = [[table[epoch, "mutate"]["mutate_ns"] / 1e6 for epoch in rotations]
                          for table in (baseline, candidate)]
            results.append({
                "platform": platform,
                "shape": shape,
                "rotation_epochs": rotations,
                "rotation_write_cpu_ms": list(map(median, write_cpu)),
                "rotation_write_wall_ms": list(map(median, write_wall)),
                "paired_cpu_deltas_ms": [right - left for left, right in zip(*write_cpu)],
            })
    return results


if __name__ == "__main__":
    print(json.dumps(summarize(Path(sys.argv[1])), indent=2))
