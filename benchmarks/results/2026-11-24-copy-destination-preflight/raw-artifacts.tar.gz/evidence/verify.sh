#!/bin/sh
set -eu
root=$(dirname "$0")
python3 "$root/verify-hosted.py" "$root" d4402cef1ae711ccb6f7c95c3386c7ff2b90d59b 45449691940 45449691863 45448738115 45448738382 45448737998 macos-full.log 1366 occupied_copy_destinations_reject_before_source_reads_or_staging full_log_copy_publication_preserves_a_late_destination_conflict backup_restore_rejects_bad_inputs_and_conflicts_without_registering detailed_format_upgrade_preserves_source_and_existing_destination detailed_legacy_upgrade_classifies_empty_and_nonempty_sources --production-revision ac87adf71e430305250040b304d0cfaf631c6015
test "$(cat "$root/native/baseline.exit")" -eq 101
grep -Fq WouldBlock "$root/native/baseline.log"
printf '%s\n' 'Previous revision attempted to acquire the staging lock for an occupied destination'
python3 - "$root" <<'PYVERIFY'
import json
from pathlib import Path
import sys
root = Path(sys.argv[1])
for run in ('45448737917', '45448738571'):
    directory = root / run
    state = json.loads((directory / 'jobs.json').read_text())
    assert state['headSha'] == 'ac87adf71e430305250040b304d0cfaf631c6015'
    assert state['status'] == 'completed' and state['conclusion'] == 'failure'
    log = (directory / 'workflow.log').read_text()
    assert 'test detailed_format_upgrade_preserves_source_and_existing_destination ... FAILED' in log
    assert 'test detailed_legacy_upgrade_classifies_empty_and_nonempty_sources ... FAILED' in log
    print('Initial upgrade assertion failure retained', run)
attempt, = (root / '45448737917').rglob('attempt.json')
result = json.loads(attempt.read_text())
assert result['revision'] == 'ac87adf71e430305250040b304d0cfaf631c6015'
assert result['returncode'] == 0 and (attempt.parent / result['output']).is_file()
print('Initial million-key recovery attempt retained')
PYVERIFY
