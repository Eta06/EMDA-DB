#!/bin/bash
set -euo pipefail
r=$(cd "$(dirname "$0")" && pwd)
collect() {
  id=$1
  d="$r/$id"
  mkdir -p "$d"
  gh run watch "$id" --interval 20 --exit-status > "$d/watch.log" 2>&1 && code=0 || code=$?
  printf '%s\n' "$code" > "$d/watch.exit"
  gh run view "$id" --json headSha,conclusion,status,workflowName,jobs,url > "$d/jobs.json"
  gh run view "$id" --log > "$d/workflow.log"
  gh run download "$id" --dir "$d" > "$d/download.log" 2>&1 || true
  printf 'Collected %s, exit %s\n' "$id" "$code"
}
for id in "$@"; do collect "$id" & done
wait
