import sys, subprocess, statistics as st, json, os, tempfile
binary_dir, out = sys.argv[1], sys.argv[2]
results = []
for trial in range(3):
    for mode in ('readset', 'conservative'):
        for workload in ('disjoint', 'shared'):
            for version in ('before', 'after'):
                with tempfile.TemporaryDirectory(dir=binary_dir) as d:
                    line = subprocess.run([os.path.join(binary_dir, 'tx-' + version), mode, '8', '100', workload, d],
                                          check=True, capture_output=True, text=True).stdout.strip()
                fields = dict(part.split('=', 1) for part in line.split())
                samples = sorted(int(x) for x in fields['samples_ns'].split(','))
                elapsed = int(fields['elapsed_ns'])
                row = dict(trial=trial, mode=mode, workload=workload, version=version,
                           tps=round(len(samples) / (elapsed / 1e9)),
                           p50_ms=round(samples[len(samples) // 2] / 1e6, 2),
                           p99_ms=round(samples[int(len(samples) * 0.99)] / 1e6, 2),
                           conflicts=sum(int(x) for x in fields['conflicts'].split(',')))
                results.append(row)
                print(json.dumps(row), flush=True)
json.dump(results, open(out, 'w'), indent=1)
