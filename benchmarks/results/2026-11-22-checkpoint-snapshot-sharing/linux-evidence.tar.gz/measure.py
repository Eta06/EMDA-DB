"""Measure simultaneous checkpoint snapshots against a common fixture."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import tempfile


def run(args):
    return subprocess.run(args, check=True, capture_output=True, text=True, timeout=60).stdout


def contents(fixture):
    return {
        str(path.relative_to(fixture)): hashlib.sha256(path.read_bytes()).hexdigest()
        for path in (fixture / "index", fixture / "store/records.log", fixture / "store/commit.state")
    }


def paired(workspace, counts):
    rows = []
    for keys in counts:
        with tempfile.TemporaryDirectory(prefix=f"keys-{keys}-", dir=workspace) as owned:
            fixture = Path(owned) / "fixture"
            args = [str(fixture), str(keys)]
            run([str(workspace / "baseline"), "prepare", *args])
            before = contents(fixture)
            for pair in range(5):
                order = ("baseline", "candidate") if pair % 2 == 0 else ("candidate", "baseline")
                results = {}
                for build in order:
                    output = run([str(workspace / build), "measure", *args])
                    sample = {key: int(value) for key, value in (part.split("=") for part in output.split())}
                    assert sample["keys"] == keys
                    results[build] = sample
                    rows.append({"build": build, "pair": pair, **sample})
                old, new = results["baseline"], results["candidate"]
                assert old["blocks"] == new["blocks"] and old["blocks"] > 0
                assert old["descriptors"] == 16 and new["descriptors"] == 0
                assert old["allocations"] - new["allocations"] == old["blocks"] + 16
            assert contents(fixture) == before
    return rows


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("workspace", type=Path)
    args = parser.parse_args()
    print(json.dumps(paired(args.workspace.resolve(), (4096, 65536)), indent=2))
