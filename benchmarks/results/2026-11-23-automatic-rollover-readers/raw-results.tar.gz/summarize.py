"""Check trial coverage and summarize each platform's paired results."""
import json
from pathlib import Path
from statistics import median
import sys


def interval(values):
    return f"{median(values):.2f} ({min(values):.2f}–{max(values):.2f})"


assert len(sys.argv) == 3
for platform, path in zip(("macOS", "Linux"), sys.argv[1:]):
    first, *rows, last = map(json.loads, Path(path).read_text().splitlines())
    assert first["before"] == last["after"]
    assert first["keys"] == 262_144 and first["width"] == 32
    assert len(rows) == 44
    assert len({row["output_bytes"] for row in rows}) == 1
    for mode in ("on-demand", "worker"):
        by_pair = {}
        for variant in ("baseline", "candidate"):
            trials = sorted((row for row in rows if row["variant"] == variant and row["mode"] == mode),
                            key=lambda row: row["pair"])
            assert [row["pair"] for row in trials] == list(range(11))
            by_pair[variant] = [row["max_reader_ns"] for row in trials]
            max_read = interval([row["max_reader_ns"] / 1e6 for row in trials])
            elapsed = interval([row["elapsed_ns"] / 1e6 for row in trials])
            cpu = median(row["cpu_ns"] for row in trials) / 1e6
            samples = median(row["reader_samples"] for row in trials)
            print(f"| {platform} | {mode} | {variant} | {max_read} | {elapsed} | {cpu:.2f} | {samples} |")
        improved = sum(candidate < baseline for candidate, baseline in
                       zip(by_pair["candidate"], by_pair["baseline"]))
        print(f"{platform} {mode}: shorter worst read in {improved}/11 pairs", file=sys.stderr)
