#!/usr/bin/env python3
"""Exercise returned errors on Linux using disposable retained cutover fixtures."""
import argparse
import collections
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat
import subprocess
import tempfile

SYSCALLS = ("fsync", "fdatasync", "unlink", "unlinkat")
SYSCALL = re.compile(r"^(?:(?:\d+|\[pid\s+\d+\])\s+)?(fsync|fdatasync|unlink|unlinkat)\(")


def digest(data):
    return hashlib.sha256(data).hexdigest()


def manifest(root):
    state = {}
    for path in sorted(root.rglob("*")):
        relative = path.relative_to(root)
        if relative.parts[0] == "verified-restore":
            continue
        mode = path.lstat().st_mode
        xattrs = {
            name: digest(os.getxattr(path, name, follow_symlinks=False))
            for name in sorted(os.listxattr(path, follow_symlinks=False))
        }
        if stat.S_ISREG(mode):
            state[str(relative)] = {"mode": mode, "sha256": digest(path.read_bytes()), "xattrs": xattrs}
        elif stat.S_ISDIR(mode):
            state[str(relative)] = {"mode": mode, "xattrs": xattrs}
        else:
            raise ValueError(f"unexpected fixture file type: {relative}")
    return state


def probe(binary, phase, root, epoch=1, prefix=()):
    command = [*prefix, str(binary), phase, str(root), "retained", "4096", str(epoch)]
    run = subprocess.run(command, check=True, text=True, capture_output=True, timeout=90)
    return run.stdout


def events(trace):
    counters = collections.Counter()
    parsed = []
    for line in trace.splitlines():
        match = SYSCALL.match(line)
        if match:
            name = match[1]
            counters[name] += 1
            parsed.append((name, counters[name], line))
    return parsed


def archive_unlink(line, archives):
    if SYSCALL.match(line)[1] not in {"unlink", "unlinkat"}:
        return None
    return next((name for name in archives if str(Path(name).name) in line), None)


def call_identity(line, case):
    # Keep the descriptor path or unlink target and compare it at the selected ordinal.
    call = re.split(r"\s+= ", line, maxsplit=1)[0]
    for level, path in enumerate((case, *case.parents)):
        if path == Path("/"):
            break
        if str(path) in call:
            return call.replace(str(path), f"<fixture-level-{level}>")
    return call


def retire(binary, case, trace_path=None, fault=None):
    prefix = []
    if trace_path is not None:
        prefix = ["strace", "-qq", "-yy", "-e", "trace=" + ",".join(SYSCALLS), "-o", str(trace_path)]
    if fault is not None:
        syscall, ordinal = fault
        prefix += ["-e", f"inject={syscall}:error=EIO:when={ordinal}"]
    out = probe(binary, "retire", case, prefix=prefix)
    pattern = r"^classification=(\w+) (?:removed=(true|false)|errno=Some\((\d+)\))$"
    match = re.search(pattern, out, re.MULTILINE)
    if match is None:
        raise ValueError(f"unexpected retirement result: {out!r}")
    classification, removed, errno = match.groups()
    return {"class": classification, "removed": removed, "errno": int(errno) if errno else None}


def verify(binary, case, original, order):
    before = manifest(case)
    if order == "restore-first":
        probe(binary, "restore-retirement", case)
        probe(binary, "verify", case)
    else:
        probe(binary, "verify", case)
        probe(binary, "restore-retirement", case)
    assert manifest(case) == before
    assert all(before[name] == item for name, item in original.items() if name in before)


def copy_fixture(source, destination):
    subprocess.run(["cp", "-a", str(source), str(destination)], check=True, timeout=30)


def run_format(binary, scratch, output, fmt):
    with tempfile.TemporaryDirectory(prefix=f"retire-{fmt}-", dir=scratch) as run:
        root = Path(run)
        fixture = root / "fixture"
        probe(binary, "setup-v2" if fmt == "v2" else "setup", fixture, 0)
        old_log = fixture / "retained/records.log"
        assert old_log.read_bytes()[:8] == {"v2": b"EMDALOG2", "v3": b"EMDALOG3"}[fmt]
        probe(binary, "bind-archive", fixture, 0)
        probe(binary, "cutover", fixture, 0)
        probe(binary, "mutate", fixture)
        probe(binary, "prepare-retirement", fixture)
        original = manifest(fixture)
        archives = {name for name in original if Path(name).name in {"legacy.records", "legacy.witness"}}
        assert len(archives) == 2
        if fmt == "v3":
            log_name = next(name for name in archives if name.endswith("legacy.records"))
            assert "user.db.commit.v3" in original[log_name]["xattrs"]
        fixed = {name: item for name, item in original.items() if name not in archives}
        baseline_parent = root / "baseline"
        baseline_parent.mkdir()
        baseline = baseline_parent / "case"
        copy_fixture(fixture, baseline)
        assert manifest(baseline) == original
        baseline_trace = output / f"{fmt}-baseline.strace"
        assert retire(binary, baseline, baseline_trace) == {"class": "success", "removed": "true", "errno": None}
        assert manifest(baseline) == fixed
        verify(binary, baseline, original, "source-first")
        trace = events(baseline_trace.read_text())
        assert sum(archive_unlink(line, archives) is not None for _, _, line in trace) == 2
        (output / f"{fmt}-original.json").write_text(json.dumps(original, indent=2) + "\n")
        removed = set()
        count = 0
        for syscall, ordinal, line in trace:
            should_be_removed = removed.copy()
            expected_prefix = {name: item for name, item in original.items() if name not in removed}
            order = "restore-first" if count % 2 else "source-first"
            label = f"{fmt}-{syscall}-{ordinal}"
            with tempfile.TemporaryDirectory(prefix=f"{label}-", dir=root) as temporary:
                case = Path(temporary) / "case"
                copy_fixture(fixture, case)
                assert manifest(case) == original
                actual_trace = output / f"{label}.strace"
                outcome = retire(binary, case, actual_trace, (syscall, ordinal))
                failed = [(call, rank, text) for call, rank, text in events(actual_trace.read_text()) if "(INJECTED)" in text]
                assert len(failed) == 1 and failed[0][:2] == (syscall, ordinal) and " EIO " in failed[0][2]
                assert call_identity(failed[0][2], case) == call_identity(line, baseline), (
                    label, failed[0][2], line,
                )
                assert outcome["errno"] == 5
                on_unlink = archive_unlink(line, archives)
                if should_be_removed or on_unlink:
                    assert outcome["class"] == "outcome_unknown", outcome
                else:
                    assert outcome["class"] in {"open_failed", "not_published"}, outcome
                assert manifest(case) == expected_prefix, label
                verify(binary, case, original, order)
                retry = retire(binary, case)
                assert retry == {"class": "success", "removed": str(bool(archives - removed)).lower(), "errno": None}
                assert manifest(case) == fixed, label
                probe(binary, "verify", case)
                print(json.dumps({
                    "format": fmt, "syscall": syscall, "ordinal": ordinal, "baseline_call": line,
                    "outcome": outcome, "archives_remaining": sorted(archives - should_be_removed),
                    "verification_order": order, "retry": retry,
                    "unchanged_entries": len(fixed), "restore_verified": True,
                }), flush=True)
                if on_unlink:
                    removed.add(on_unlink)
            count += 1
        assert removed == archives


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("binary", type=Path)
    parser.add_argument("scratch", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    args.output.mkdir()
    for fmt in ("v2", "v3"):
        run_format(args.binary.resolve(), args.scratch, args.output, fmt)


if __name__ == "__main__":
    main()
