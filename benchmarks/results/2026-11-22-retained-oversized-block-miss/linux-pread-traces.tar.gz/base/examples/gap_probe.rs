use database_engine::{RetainedExportLimits, Store, retained_base_v2::Limits, retained_candidate::{Expected, IndexLimits, IndexedCandidate}};
use std::{fs, path::Path};
const MAX: usize = 16 * 1024 * 1024;
const FILE: u64 = 40 * 1024 * 1024;
fn main() -> Result<(), Box<dyn std::error::Error>> {
    let args: Vec<_> = std::env::args().collect();
    let root = Path::new(&args[2]);
    let path = root.join("candidate");
    if args[1] == "prepare" {
        let store = Store::open(root.join("source"))?;
        store.put(b"a", b"small")?;
        store.put(b"b", &vec![17; MAX])?;
        store.put(b"c", b"end")?;
        let expected = store.build_retained_candidate(&path, [3; 16], [4; 16],
            RetainedExportLimits { max_log_bytes: FILE, max_live_keys: 16,
                max_live_key_bytes: 64, max_output_bytes: FILE })?;
        fs::write(root.join("binding"), [expected.header.as_slice(), &expected.witness, &expected.base_digest].concat())?;
    } else {
        let binding = fs::read(root.join("binding"))?;
        let reader = IndexedCandidate::open(&path,
            Limits { file_bytes: FILE, entries: 16, key_bytes: 64, work_bytes: FILE + 1 },
            IndexLimits { blocks: 3, anchor_bytes: 3 },
            &Expected { header: binding[..112].try_into()?,
                witness: binding[112..144].try_into()?, base_digest: binding[144..].try_into()? })?;
        match args[1].as_str() {
            "gap" => assert_eq!(reader.get(b"bb", 0)?, None),
            "hit" => {
                let value = reader.get(b"b", MAX)?.unwrap();
                assert_eq!(value.len(), MAX);
                assert!(value.iter().all(|&byte| byte == 17));
            }
            _ => panic!("unknown mode"),
        }
    }
    Ok(())
}
