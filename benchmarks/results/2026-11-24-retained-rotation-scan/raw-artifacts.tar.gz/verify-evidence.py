import collections
import json
import pathlib
import sys

root = pathlib.Path(sys.argv[1])
revision = sys.argv[2]
runs = ("45387848504", "45387848239", "45387848206", "45387848308", "45387848289")
for run in runs:
    state = json.loads((root / run / "jobs.json").read_text())
    assert state["headSha"] == revision, state
    assert state["status"] == "completed" and state["conclusion"] == "success", state
    assert (root / run / "workflow.log").stat().st_size > 0, run
    print(state["workflowName"], run, state["conclusion"])

for label, directory, count in [
    ("standard benchmark smoke", root / "45387848239" / "ci-benchmark-smoke", 45),
    ("cross-engine smoke", root / "45387848289", 5),
    ("four-writer recovery memory workload", root / "45387848239" / "writable-recovery-memory-ceiling", 1),
]:
    attempts = list(directory.rglob("attempt.json"))
    assert len(attempts) == count, (label, len(attempts))
    dispositions = collections.Counter()
    for path in attempts:
        attempt = json.loads(path.read_text())
        assert attempt["revision"] == revision and attempt["tracked_changes"] == "", path
        assert attempt["status"] == "exited", path
        assert (path.parent / attempt["output"]).is_file(), path
        dispositions[attempt["returncode"], attempt["wrapper_exit_code"]] += 1
    assert dispositions == {(0, 0): count}, dispositions
    print(label, dispositions)

measurements, = root.rglob("measurements.jsonl")
phases = [json.loads(line) for line in measurements.read_text().splitlines()]
capped = [phase for phase in phases if phase["address_space_limit_bytes"] is not None]
assert len(phases) == 51 and len(capped) == 24, (len(phases), len(capped))
assert all(phase["address_space_limit_bytes"] == 48 * 1024**2 for phase in capped)
print("recovery phases", len(phases), "capped at 48 MiB", len(capped))

linux_log = (root / "45387848239" / "workflow.log").read_text()
for test in ("rotation_scan_limit_counts_touched_blocks_suffix_values_and_successor",
             "rotation_scan_limit_preserves_authority_on_rejection"):
    lines = [line for line in linux_log.splitlines() if test + " ... ok" in line]
    assert len(lines) >= 2, (test, lines)
    print(test, len(lines), "passes")
