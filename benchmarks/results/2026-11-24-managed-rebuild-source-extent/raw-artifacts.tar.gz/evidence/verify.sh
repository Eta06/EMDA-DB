#!/bin/sh
set -eu
root=$(dirname "$0")
python3 "$root/verify-hosted.py" "$root" 5eb5602bbd65c60caf85d37cbd8f679cccc2c6f2 45443519854 45443519852 45443519834 45443519951 45443520079 macos-full.log 1362 managed_rebuild_rejects_source_drift_before_reading_published_checkpoint bounded_rebuild_rechecks_published_checkpoint_and_log_before_selection
test "$(cat "$root/native/baseline.exit")" -eq 101
grep -Fq 'checkpoint was published but managed verification failed: No such file' "$root/native/baseline.log"
printf '%s\n' 'Previous revision reported the missing checkpoint before source drift'
