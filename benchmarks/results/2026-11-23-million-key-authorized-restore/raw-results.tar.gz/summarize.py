"""Check the phase matrix and emit the comparable recovery metrics."""
import hashlib
from itertools import permutations
import json
from pathlib import Path
from statistics import median
import sys

KEYS = 1_048_576
EPOCHS = 6
BACKENDS = ("ordinary", "retained", "sqlite")


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def live_count(epoch):
    return KEYS - sum((key + epoch) % 11 == 0 for key in range(4096))


def summarize(path, runner):
    rows = [json.loads(line) for line in (path / "measurements.jsonl").read_text().splitlines()]
    environment = json.loads((path / "environment.json").read_text())
    assert environment["authorized_restore"] and environment["retire_and_restore"]
    assert environment["runner_sha256"] == sha256(runner)
    assert environment["suffix_work_override"] == "240000000"
    assert environment["keys"] == KEYS and environment["epochs"] == EPOCHS
    assert tuple(map(tuple, environment["backend_orders"])) == tuple(permutations(BACKENDS))
    assert len(rows) == 58
    assert all(row["exit"] == 0 and row["keys"] == KEYS and row["peak_rss_bytes"] > 0 for row in rows)
    assert [row["phase"] for row in rows[:3]] == ["setup", "bind-archive", "cutover"]

    phases = {}
    for row in rows[3:-1]:
        key = row["epoch"], row["backend"], row["phase"]
        assert key not in phases
        phases[key] = row
    for epoch in range(1, EPOCHS + 1):
        for backend in BACKENDS:
            assert phases[epoch, backend, "mutate"]["batches"] == 32
            assert phases[epoch, backend, "mutate"]["operations"] == 4096
            assert phases[epoch, backend, "reopen"]["ready_ns"] > 0
            assert phases[epoch, backend, "verify"]["verified_entries"] == live_count(epoch)

    engines = []
    for backend in BACKENDS:
        reopens = [phases[epoch, backend, "reopen"] for epoch in range(1, EPOCHS + 1)]
        verifies = [phases[epoch, backend, "verify"] for epoch in range(1, EPOCHS + 1)]
        writes = [phases[epoch, backend, "mutate"] for epoch in range(1, EPOCHS + 1)]

        def mid_ms(records, key):
            return median(row[key] for row in records) / 1_000_000

        engines.append({
            "engine": backend,
            "ready_wall_ms": mid_ms(reopens, "ready_ns"),
            "ready_cpu_ms": mid_ms(reopens, "ready_cpu_ns"),
            "reopen_peak_rss_mib": max(row["peak_rss_bytes"] for row in reopens) / (1 << 20),
            "scan_wall_ms": mid_ms(verifies, "verify_ns"),
            "write_wall_ms": mid_ms(writes, "mutate_ns"),
            "write_cpu_ms": mid_ms(writes, "mutate_cpu_ns"),
            "write_allocation_peak_mib": max(row["allocated_peak_sample_bytes"] for row in writes) / (1 << 20),
        })

    retained = [phases[epoch, "retained", "mutate"] for epoch in range(1, EPOCHS + 1)]
    max_suffix = max(row["suffix_bytes"] for key, row in phases.items() if key[1] == "retained")
    assert max_suffix <= 768 * 1024
    lifecycle = rows[-1]
    assert lifecycle["phase"] == "authorized-lifecycle"
    log = (path / "06-retained-authorized-lifecycle.log").read_text().splitlines()
    assert log.count(f"verified_entries={live_count(6)}") == 2
    assert lifecycle["restore_prepare_ns"] + lifecycle["restore_register_ns"] <= lifecycle["restore_ns"]
    assert len({row["sqlite_version"] for key, row in phases.items() if key[1] == "sqlite"}) == 1

    return {
        "engines": engines,
        "rotations": sum(row["rotations"] for row in retained),
        "max_suffix_bytes": max_suffix,
        "write_cpu_ms_with_rotation": mid_ms([row for row in retained if row["rotations"]], "mutate_cpu_ns"),
        "write_cpu_ms_without_rotation": mid_ms([row for row in retained if not row["rotations"]], "mutate_cpu_ns"),
        "sqlite_version": phases[1, "sqlite", "reopen"]["sqlite_version"],
        "cutover_peak_rss_mib": rows[2]["peak_rss_bytes"] / (1 << 20),
        "final_entries": live_count(6),
        "lifecycle": lifecycle,
    }


if __name__ == "__main__":
    runner, macos, linux = map(Path, sys.argv[1:])
    print(json.dumps({"macos": summarize(macos, runner), "linux": summarize(linux, runner)}, indent=2))
