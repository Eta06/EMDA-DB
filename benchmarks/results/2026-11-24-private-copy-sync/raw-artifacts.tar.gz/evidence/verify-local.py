from collections import defaultdict
import json
from pathlib import Path
import re
from statistics import median
import sys

root = Path(sys.argv[1])
assert (root / 'baseline-revision.txt').read_text().strip() == '438a4e27adfce7851a8c4c16ee17caf66819409d'
assert 'is not an iterator' in (root / 'focused-first.log').read_text()
for log, total in [('online-final.log', 80), ('online-public.log', 20)]:
    output = (root / log).read_text()
    assert sum(int(n) for n in re.findall(r'test result: ok\. (\d+) passed;', output)) == total
    assert 'test result: FAILED' not in output
    print(log, total, 'tests')

profiles = defaultdict(list)
for location, revision in [('attempts', '233d4571ebadcff0c4dfa1bb5a42ed2482448bf2'), ('online-attempts', '07bb7cb41637dcaaf25e0964b8f3e0d9a3c6abe3')]:
    attempts = sorted((root / location).glob('*/attempt.json'))
    assert len(attempts) == 12, (location, len(attempts))
    for path in attempts:
        attempt = json.loads(path.read_text())
        assert attempt['revision'] == revision, path
        assert attempt['returncode'] == attempt['wrapper_exit_code'] == 0, path
        assert attempt['status'] == 'exited', path
        log = (path.parent / attempt['output']).read_text()
        label = attempt['case'].split('-')
        keys = int(label[1])
        profile = label[-1]
        if location == 'attempts':
            n, live, source, compact, us = map(int, re.search(r'^keys=(\d+) live=(\d+) source_bytes=(\d+) compact_bytes=(\d+) compact_us=(\d+)$', log, re.M).groups())
            assert keys == n and live == n - n // 8
            assert (source, compact) == {16384: (2346340, 1333276), 65536: (9385276, 5333020)}[n]
            case = f'ordinary {keys}'
        else:
            data = json.loads(next(line for line in log.splitlines() if line.startswith('{')))
            assert data['keys'] == 16000 and data['live_keys'] == 14000 and data['mode'] == label[2]
            assert data['log_format'] == 'V2' and data['staging_clean'] and data['reopen_verified']
            assert data['source_log_bytes'] == 2291380
            assert data['compacted_log_bytes'] == {'baseline': 1307722, 'online': 1302028}[profile]
            assert data['previous_log_bytes'] == (2291380 if label[2] == 'retain' else 0)
            us = data['elapsed_us']
            case = f'online {label[2]}'
        rss = int(re.search(r'^\s*(\d+)  maximum resident set size$', log, re.M)[1])
        cpu = sum(float(re.search(rf'^{part} (\d+\.\d+)$', log, re.M)[1]) for part in ('user', 'sys'))
        profiles[case, profile].append((us, rss, cpu))
for (case, profile), values in sorted(profiles.items()):
    assert len(values) == 3, (case, profile)
    us, rss, cpu = (median(column) for column in zip(*values))
    print(case, profile, 'median elapsed us', us, 'process peak RSS bytes', rss, 'process CPU', cpu)

sqlite_samples = defaultdict(list)
references = sorted((root / 'sqlite-attempts').glob('*/attempt.json'))
assert len(references) == 6
for path in references:
    attempt = json.loads(path.read_text())
    assert attempt['revision'] == '07bb7cb41637dcaaf25e0964b8f3e0d9a3c6abe3'
    assert attempt['status'] == 'exited' and attempt['returncode'] == attempt['wrapper_exit_code'] == 0, path
    log = (path.parent / attempt['output']).read_text()
    data = json.loads(next(line for line in log.splitlines() if line.startswith('{')))
    keys = data['keys']
    assert keys == int(attempt['case'].split('-')[2]) and data['live_keys'] == keys - keys // 8
    assert data['sqlite'] == '3.54.0' and data['journal'] == 'WAL' and data['synchronous'] == 'FULL'
    assert data['page_size'] == 4096 and data['autocheckpoint_pages'] == 1000
    assert data['complete_rows_reopen_verified']
    assert (data['source_db_wal_bytes'], data['compact_db_bytes']) == {16384: (3506128, 1163264), 65536: (7529336, 4620288)}[keys]
    sqlite_samples[keys].append(data['compact_us'])
for keys, samples in sorted(sqlite_samples.items()):
    assert len(samples) == 3
    print('SQLite', keys, 'median elapsed us', median(samples))
