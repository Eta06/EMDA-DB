import argparse
import json
import pathlib
import re
import subprocess
import sys

parser = argparse.ArgumentParser()
parser.add_argument("root", type=pathlib.Path)
parser.add_argument("revision")
parser.add_argument("linux")
parser.add_argument("macos")
parser.add_argument("comparison")
parser.add_argument("enospc")
parser.add_argument("filesystem")
parser.add_argument("native_log")
parser.add_argument("native_count", type=int)
parser.add_argument("test_names", nargs="+")
parser.add_argument("--macos-cancelled", action="store_true")
args = parser.parse_args()
for run in (args.linux, args.macos, args.comparison, args.enospc, args.filesystem):
    directory = args.root / run
    state = json.loads((directory / "jobs.json").read_text())
    assert state["headSha"] == args.revision, state
    cancelled = run == args.macos and args.macos_cancelled
    expected = "cancelled" if cancelled else "success"
    assert state["status"] == "completed" and state["conclusion"] == expected, state
    if cancelled:
        assert {job["name"]: job["conclusion"] for job in state["jobs"]} == {
            "Rust stable / macOS": "success", "Rust 1.85.0 / macOS": "cancelled"
        }, state
    assert (directory / "workflow.log").stat().st_size > 0, run
    print(state["workflowName"], run, state["conclusion"])

for directory, expected_attempts in [
    (args.root / args.linux / "ci-benchmark-smoke", 45),
    (args.root / args.comparison, 5),
    (args.root / args.linux / "writable-recovery-memory-ceiling", 1),
]:
    attempts = list(directory.rglob("attempt.json"))
    assert len(attempts) == expected_attempts, (directory, len(attempts))
    for path in attempts:
        attempt = json.loads(path.read_text())
        assert attempt["revision"] == args.revision and attempt["tracked_changes"] == "", path
        assert attempt["status"] == "exited", path
        assert attempt["returncode"] == attempt["wrapper_exit_code"] == 0, path
        assert (path.parent / attempt["output"]).is_file(), path
    print(directory.name, expected_attempts, "successful attempts")

measurements, = (args.root / args.linux / "writable-recovery-memory-ceiling").rglob("measurements.jsonl")
subprocess.run([sys.executable, str(args.root / "verify-linux-phases.py"), str(measurements)], check=True)
print("million-key memory matrix verified")
for run, expected_appearances in [(args.linux, 3), (args.macos, 1 if args.macos_cancelled else 2)]:
    hosted = (args.root / run / "workflow.log").read_text().splitlines()
    for name in args.test_names:
        count = sum(name + " ... ok" in line for line in hosted)
        assert count >= expected_appearances, (run, name, count)
        print(run, name, count, "passes")
native = (args.root / "native" / args.native_log).read_text()
counts = [int(count) for count in re.findall(r"test result: ok\. (\d+) passed", native)]
assert "test result: FAILED" not in native and sum(counts) == args.native_count, counts
print("native macOS", sum(counts), "passing tests")
