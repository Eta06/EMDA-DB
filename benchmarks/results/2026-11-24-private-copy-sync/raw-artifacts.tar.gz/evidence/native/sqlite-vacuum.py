"""Disposable SQLite compact-copy reference for the EMDA-DB key workload."""
from contextlib import closing
import json
import os
from pathlib import Path
import sqlite3
import sys
import tempfile
from time import perf_counter_ns


def key(n):
    return n.to_bytes(8, "big")


def value(n, round_number):
    return bytes(((n + round_number) % 251,)) * 64


def verify(connection, count):
    assert connection.execute("PRAGMA integrity_check").fetchall() == [("ok",)]
    live = count - count // 8
    seen = 0
    for n, (observed_key, observed_value) in enumerate(connection.execute("SELECT k, v FROM kv ORDER BY k")):
        assert observed_key == key(n) and observed_value == value(n, int(n < count // 2))
        seen += 1
    assert seen == live


def sync(path):
    fd = os.open(path, os.O_RDONLY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def main():
    parent, count = sys.argv[1:]
    count = int(count)
    assert 16 <= count <= 100_000 and Path(parent).is_dir()
    live = count - count // 8
    with tempfile.TemporaryDirectory(prefix="sqlite-compact-", dir=parent) as directory:
        root = Path(directory)
        path, stage, output = (root / name for name in ("source.sqlite", "stage.sqlite", "copy.sqlite"))
        with closing(sqlite3.connect(path)) as source:
            assert source.execute("PRAGMA journal_mode = WAL").fetchone() == ("wal",)
            source.execute("PRAGMA synchronous = FULL")
            source.execute("PRAGMA wal_autocheckpoint = 1000")
            source.execute("CREATE TABLE kv(k BLOB PRIMARY KEY, v BLOB NOT NULL) WITHOUT ROWID")
            for round_number, limit in enumerate((count, count // 2)):
                for start in range(0, limit, 512):
                    with source:
                        source.executemany("INSERT OR REPLACE INTO kv VALUES (?, ?)",
                                           ((key(n), value(n, round_number)) for n in range(start, min(start + 512, limit))))
            for start in range(live, count, 512):
                with source:
                    source.executemany("DELETE FROM kv WHERE k = ?",
                                       ((key(n),) for n in range(start, min(start + 512, count))))
            source_bytes = path.stat().st_size + (root / "source.sqlite-wal").stat().st_size
            page_size = source.execute("PRAGMA page_size").fetchone()[0]
            started = perf_counter_ns()
            verify(source, count)
            source.execute("VACUUM INTO ?", (str(stage),))
            with closing(sqlite3.connect(stage.as_uri() + "?mode=ro&immutable=1", uri=True)) as copy:
                verify(copy, count)
            sync(stage)
            os.link(stage, output)
            stage.unlink()
            sync(root)
            elapsed_us = (perf_counter_ns() - started) // 1000
            with closing(sqlite3.connect(output.as_uri() + "?mode=ro&immutable=1", uri=True)) as copy:
                verify(copy, count)
            print(json.dumps(dict(sqlite=sqlite3.sqlite_version, keys=count, live_keys=live,
                                  source_db_wal_bytes=source_bytes, compact_db_bytes=output.stat().st_size,
                                  page_size=page_size, compact_us=elapsed_us, journal="WAL", synchronous="FULL",
                                  autocheckpoint_pages=1000, complete_rows_reopen_verified=True), sort_keys=True))


if __name__ == "__main__":
    main()
