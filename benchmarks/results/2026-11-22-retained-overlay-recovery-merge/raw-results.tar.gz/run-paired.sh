set -eu
run=$1
scratch=$2
mkdir "$run/measurements"
for workload in 8192-front 65536-front 65536-back 65536-replace; do
  rows=${workload%-*}
  scenario=${workload#*-}
  for round in 1 2 3 4 5 6; do
    if [ $((round % 2)) -eq 1 ]; then order="baseline candidate"; else order="candidate baseline"; fi
    for mode in $order; do
      work=$(mktemp -d "$scratch/overlay-fixture.XXXXXX")
      "$run/$mode" "$work" "$rows" "$scenario" > "$run/measurements/$workload-$round-$mode.log" 2>&1
      python3 - "$work" <<'PY'
import shutil
import sys
shutil.rmtree(sys.argv[1])
PY
    done
  done
  printf '%s verified\n' "$workload"
done
