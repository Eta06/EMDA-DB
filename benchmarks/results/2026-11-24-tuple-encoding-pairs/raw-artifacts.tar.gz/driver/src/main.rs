use database_engine::{
    CollectionSchema, DocumentDatabase, DocumentQuery, IndexDefinition, IndexValue, PartialFilter,
    Store,
};
use rusqlite::{Connection, params};
use serde_json::{Value, json};
use std::time::Instant;

const SQL: &str = "SELECT o.id, o.doc, p.doc FROM orders o
    LEFT JOIN people p ON p.tenant = o.tenant AND p.email = o.email AND p.active = 1
    ORDER BY o.id";

fn main() {
    let dir = tempfile::tempdir().unwrap();
    let store = Store::open(dir.path().join("emda")).unwrap();
    let db = DocumentDatabase::new(&store);
    db.create_collection("orders", CollectionSchema::default()).unwrap();
    db.create_collection("people", CollectionSchema::default()).unwrap();
    let fields = [vec!["tenant".into()], vec!["email".into()]];
    db.create_index("people", IndexDefinition {
        name: "owner".into(), fields: fields.to_vec(), unique: true,
        partial: Some(PartialFilter::Equals { path: vec!["active".into()], value: IndexValue::Boolean(true) }),
    }).unwrap();

    let mut sqlite = Connection::open(dir.path().join("data.sqlite")).unwrap();
    sqlite.execute_batch("PRAGMA journal_mode=WAL; PRAGMA synchronous=FULL;
        CREATE TABLE people(tenant INTEGER, email TEXT, active INTEGER, doc TEXT);
        CREATE UNIQUE INDEX people_owner ON people(tenant,email) WHERE active=1;
        CREATE TABLE orders(id TEXT PRIMARY KEY, tenant INTEGER, email TEXT, doc TEXT);").unwrap();
    let txn = sqlite.transaction().unwrap();
    let people: Vec<_> = (0..512).map(|i| {
        json!({"tenant":i % 8,"email":format!("person-{i:04}@example.test"),
            "active":i % 5 != 0,"name":format!("Person {i}")})
    }).collect();
    for (batch, documents) in people.chunks(32).enumerate() {
        db.transaction(|tx| {
            for (item, person) in documents.iter().enumerate() {
                tx.insert("people", &format!("{:04}", batch * 32 + item), person)?;
            }
            Ok(())
        }).unwrap();
    }
    for person in &people {
        txn.execute("INSERT INTO people VALUES(?1,?2,?3,?4)", params![
            person["tenant"].as_i64().unwrap(), person["email"].as_str().unwrap(),
            i64::from(person["active"].as_bool().unwrap()), person.to_string(),
        ]).unwrap();
    }
    let expected: Vec<_> = (0..128).map(|i| {
        let person = if i % 7 == 0 { 1000 + i } else { i * 17 % 512 };
        let order = json!({"tenant":person % 8,"email":format!("person-{person:04}@example.test"),
            "amount":i % 32});
        let related = people.get(person).filter(|doc| doc["active"] == true).cloned();
        (format!("{i:04}"), order, related)
    }).collect();
    for rows in expected.chunks(32) {
        db.transaction(|tx| {
            for (id, order, _) in rows {
                tx.insert("orders", id, order)?;
            }
            Ok(())
        }).unwrap();
    }
    for (id, order, _) in &expected {
        txn.execute("INSERT INTO orders VALUES(?1,?2,?3,?4)", params![
            id, order["tenant"].as_i64().unwrap(), order["email"].as_str().unwrap(),
            order.to_string(),
        ]).unwrap();
    }
    txn.commit().unwrap();
    let plan: Vec<String> = sqlite.prepare(&format!("EXPLAIN QUERY PLAN {SQL}")).unwrap()
        .query_map([], |row| row.get(3)).unwrap().collect::<Result<_, _>>().unwrap();
    let version: String = sqlite.query_row("SELECT sqlite_version()", [], |row| row.get(0)).unwrap();
    println!("{}", json!({"sqlite_version":version, "sqlite_plan":plan,
        "target_rows":people.len(), "source_rows":expected.len(),
        "matches":expected.iter().filter(|row| row.2.is_some()).count(),
        "warmups":4, "recorded_rounds":20}));
    let query = DocumentQuery { max_scanned: 128, limit: 128, ..Default::default() };
    for cycle in 0..24 {
        for engine in [cycle % 2, 1 - cycle % 2] {
            let start = Instant::now();
            let rows = if engine == 0 {
                let page = db.lookup_unique_index("orders", &query, &fields, "people", "owner").unwrap();
                page.documents.into_iter().map(|row| (row.source.id, row.source.document, row.related)).collect()
            } else {
                let mut statement = sqlite.prepare_cached(SQL).unwrap();
                statement.query_map([], |row| {
                    let id: String = row.get(0)?;
                    let order: String = row.get(1)?;
                    let related: Option<String> = row.get(2)?;
                    Ok((id, serde_json::from_str::<Value>(&order).unwrap(),
                        related.map(|value| serde_json::from_str(&value).unwrap())))
                }).unwrap().collect::<Result<Vec<_>, _>>().unwrap()
            };
            let elapsed = start.elapsed().as_nanos() as u64;
            assert_eq!(rows, expected);
            println!("{}", json!({"engine": if engine == 0 { "emda" } else { "sqlite" },
                "cycle":cycle, "warmup":cycle < 4, "elapsed_ns":elapsed, "verified_rows": rows.len()}));
        }
    }
}
