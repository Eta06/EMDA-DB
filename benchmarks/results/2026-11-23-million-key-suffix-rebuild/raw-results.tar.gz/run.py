import filecmp
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import resource
import shutil
import subprocess
import sys
import tempfile

runner, parent = map(Path, sys.argv[1:])
linux = sys.platform == "linux"
cap = 48 * 1024 * 1024


def limit():
    resource.setrlimit(resource.RLIMIT_AS, (cap, cap))


def sha(path):
    with path.open("rb") as stream:
        digest = hashlib.sha256()
        for block in iter(lambda: stream.read(64 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def source(root):
    log = root / "store" / "records.log"
    with log.open("rb") as stream:
        magic = stream.read(8)
    result = {
        "format": magic.decode(),
        "log": sha(log),
        "log_bytes": log.stat().st_size,
        "sidecar": sha(root / "store" / "commit.state"),
    }
    if magic == b"EMDALOG3":
        result["inode_witness"] = os.getxattr(log, "user.db.commit.v3").hex()
    return result


def run(root, keys, mode, pair=None, bounded=False, measured=True):
    argv = [runner, mode, root, str(keys)]
    if measured:
        argv = (["/usr/bin/time", "-f", "peak_rss_kib=%M"] if linux
                else ["/usr/bin/time", "-lp"]) + argv
    result = subprocess.run(argv, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                            preexec_fn=limit if linux and bounded else None)
    metrics = {"keys": keys, "mode": mode, "pair": pair, "exit": result.returncode,
               "address_space_cap_bytes": cap if linux and bounded else None, "output": result.stdout}
    if linux:
        match = re.search(r"peak_rss_kib=(\d+)", result.stdout)
        if match:
            metrics["peak_rss_bytes"] = int(match[1]) * 1024
    else:
        match = re.search(r"(\d+)\s+maximum resident set size", result.stdout)
        if match:
            metrics["peak_rss_bytes"] = int(match[1])
    print(json.dumps(metrics), flush=True)
    result.check_returncode()
    if measured:
        assert "peak_rss_bytes" in metrics
        if bounded:
            assert metrics["peak_rss_bytes"] <= cap

if shutil.disk_usage(parent).free < 155 * 1024 * 1024:
    raise SystemExit("fixture parent needs at least 155 MiB free")
print(json.dumps({"platform": platform.platform(), "available_bytes": shutil.disk_usage(parent).free,
                  "linux_bounded_address_space_bytes": cap if linux else None}), flush=True)
keys = 1048576
with tempfile.TemporaryDirectory(dir=parent) as tmp:
    root = Path(tmp)
    run(root, keys, "setup", measured=False)
    source_path = root / "store"
    log = source_path / "records.log"
    anchor = source_path / "commit.state"
    selection = source_path / "checkpoint.selection"
    base = root / "base.index"
    original_selection = selection.read_bytes()
    original_base = sha(base)
    acknowledged = source(root)
    prior = (root / "prior.witness").read_bytes()
    if acknowledged["format"] == "EMDALOG3":
        os.setxattr(log, "user.db.commit.v3", prior)
        with log.open("rb") as stream:
            os.fsync(stream.fileno())
    else:
        with anchor.open("wb") as stream:
            stream.write(prior)
            stream.flush()
            os.fsync(stream.fileno())
    pending = source(root)
    assert pending != acknowledged and pending["log"] == acknowledged["log"]
    print(json.dumps({"keys": keys, "pending": pending}), flush=True)
    for mode in ("reject-log", "reject-spill", "reject-output"):
        run(root, keys, mode, bounded=True)
        assert source(root) == pending
        assert selection.read_bytes() == original_selection
        assert sha(base) == original_base
    run(root, keys, "suffix", bounded=True)
    assert selection.read_bytes() != original_selection
    assert filecmp.cmp(root / "reference.index", root / "checkpoint", shallow=False)
    run(root, keys, "verify", bounded=True)
    assert source(root) == acknowledged and sha(base) == original_base
    print(json.dumps({"keys": keys, "after": source(root), "byte_identical_checkpoint": True,
                      "trusted_base_preserved": True, "expected_witness_adopted": True}), flush=True)
