#!/bin/sh
set -eu
root=$(dirname "$0")
python3 "$root/verify-hosted.py" "$root" 9cba4be85015ff385dccfbd89bb4fda310b44585 45441083543 45441083739 45441083999 45441084005 45441083908 macos-full.log 1361 checkpoint_compaction_admits_exact_log_budgets_and_verifies_history
count=$(grep -Fc 'checkpoint_handoff_log_budgets_preserve_selection_on_rejection ... ok' "$root/45441083543/workflow.log")
test "$count" -ge 3
printf 'Linux checkpoint handoff regression passed %s times\n' "$count"
python3 - "$root" <<'PY'
import json
from pathlib import Path
import sys
root = Path(sys.argv[1])
revision = 'c8d1e9ba6cadc10d927c8cd7fb538e155286e922'
assert (root / 'native/revision.txt').read_text().strip() == revision
assert 'clippy::ok-expect' in (root / 'native/linux-lint-initial.log').read_text()
attempts = []
for run in ('45440664334', '45440664439', '45440664492', '45440664523', '45440664644'):
    directory = root / run
    state = json.loads((directory / 'jobs.json').read_text())
    assert state['headSha'] == revision and state['status'] == 'completed', state
    if run == '45440664492':
        assert state['conclusion'] == 'failure', state
    for path in directory.rglob('attempt.json'):
        result = json.loads(path.read_text())
        assert result['revision'] == revision and (path.parent / result['output']).is_file(), path
        attempts.append(result)
    print('Initial run', run, state['workflowName'], state['conclusion'])
assert len(attempts) == 6, len(attempts)
print('Initial benchmark attempts retained', len(attempts))
PY
