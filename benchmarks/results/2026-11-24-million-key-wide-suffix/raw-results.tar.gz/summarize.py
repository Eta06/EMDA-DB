#!/usr/bin/env python3
"""Check the complete campaign and reproduce the result tables."""
import argparse
import json
import math
from pathlib import Path
from statistics import median

BACKENDS = ("ordinary", "retained", "sqlite")
MIB = 1024**2
DATASETS = (
    ("macOS APFS", "baseline", "macos", 4096),
    ("macOS APFS", "wide", "wide-macos", 32768),
    ("Linux tmpfs", "baseline", "linux-evidence", 4096),
    ("Linux tmpfs", "wide", "linux-wide-evidence", 32768),
)


def load(path, churn):
    rows = [json.loads(line) for line in (path / "measurements.jsonl").read_text().splitlines()]
    assert len(rows) == 58 and all(row["exit"] == 0 for row in rows)
    assert {row["keys"] for row in rows} == {1048576}
    indexed = {(r["phase"], r["backend"], r["epoch"]): r for r in rows}
    assert len(indexed) == len(rows)
    final_count = 0
    for epoch in range(1, 7):
        final_count = 1048576 - sum((key + epoch) % 11 == 0 for key in range(churn))
        for backend in BACKENDS:
            for phase in ("mutate", "reopen", "verify"):
                entry = indexed[phase, backend, epoch]
                if phase == "verify":
                    assert entry["verified_entries"] == final_count
                if phase == "mutate":
                    assert entry["operations"] == churn
                    assert entry["batches"] == churn // 128
    assert (path / "06-retained-authorized-lifecycle.log").read_text().splitlines().count(
        f"verified_entries={final_count}"
    ) == 2
    return indexed


def summarize(directory):
    for platform, workload, name, churn in DATASETS:
        path = directory / name
        rows = load(path, churn)
        for backend in BACKENDS:
            probes = [rows["reopen", backend, epoch] for epoch in range(1, 7)]
            writes = [rows["mutate", backend, epoch] for epoch in range(1, 7)]
            verify = [rows["verify", backend, epoch] for epoch in range(1, 7)]
            ready = median(r["ready_ns"] for r in probes) / 1e6
            cpu = median(r["ready_cpu_ns"] for r in probes) / 1e6
            rss = max(r["peak_rss_bytes"] for r in probes) / MIB
            scan = median(r["verify_ns"] for r in verify) / 1e6
            write = median(r["mutate_ns"] for r in writes) / 1e6
            print(f"| {platform} | {workload} | {backend} | {ready:.2f} | {cpu:.2f} | {rss:.2f} | {scan:.2f} | {write:.2f} |")
        probes = [rows["reopen", "retained", epoch] for epoch in range(1, 7)]
        writes = [rows["mutate", "retained", epoch] for epoch in range(1, 7)]
        phases = {r["rotations"] for r in writes}
        assert phases == {0, 1}
        wall = [median(r["mutate_ns"] for r in writes if r["rotations"] == n) / 1e6
                for n in (0, 1)]
        suffix = max(r["suffix_bytes"] for r in probes) / MIB
        rotations = sum(r["rotations"] for r in writes)
        restored = rows["authorized-lifecycle", "retained", 6]
        print(f"Retained {platform} {workload} | rotations {rotations} | max suffix {suffix:.3f} MiB | write median without/with rotation {wall[0]:.2f} / {wall[1]:.2f} ms")
        fields = [restored[f"{phase}_ns"] / 1e6 for phase in ("backup", "retire", "restore_prepare", "restore_register", "restore")]
        assert all(math.isfinite(n) and n > 0 for n in fields)
        print(f"Lifecycle {platform} {workload} | " + " | ".join(f"{ms:.2f}" for ms in fields) +
              f" | {restored['peak_rss_bytes'] / MIB:.2f} MiB RSS | {restored['allocated_peak_sample_bytes'] / MIB:.2f} MiB sampled allocated | {restored['verified_entries']} entries")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    summarize(parser.parse_args().directory)
