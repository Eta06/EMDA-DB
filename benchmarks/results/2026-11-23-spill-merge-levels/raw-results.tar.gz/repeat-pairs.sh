#!/bin/sh
set -eu
run=$1
for count in 2048 4096 8192; do
    mkdir "$run/$count"
    (
        cd "$run/$count"
        "$run/probe" setup store "$count"
        shasum -a 256 store/records.log store/commit.state >source-before.sha256
        "$run/probe" ordinary store reference "$count" >ordinary.log
        for trial in 1 2 3; do
            if [ "$((trial % 2))" -eq 0 ]; then variants='tiered probe'; else variants='probe tiered'; fi
            for variant in $variants; do
                destination="paired-$variant-$trial"
                /usr/bin/time -lp "$run/$variant" bounded store "$destination" "$count" >"$destination.log" 2>&1
                cmp "$destination" reference
            done
        done
        shasum -a 256 -c source-before.sha256
    )
done
