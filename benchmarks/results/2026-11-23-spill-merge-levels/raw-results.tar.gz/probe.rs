use database_engine::{BatchOperation, BoundedFullRebuildLimits, CheckpointStore, Store};
use std::{error::Error, path::Path, time::Instant};

const BATCH: usize = 256;

fn main() -> Result<(), Box<dyn Error>> {
    let args: Vec<_> = std::env::args().collect();
    match args.as_slice() {
        [_, mode, path, count] if mode == "setup" => {
            let count: usize = count.parse()?;
            let store = Store::open(path)?;
            for begin in (0..count).step_by(BATCH) {
                let keys: Vec<_> = (begin..(begin + BATCH).min(count))
                    .map(|n| format!("witnessed-benchmark-key-{n:08}"))
                    .collect();
                let value = [37_u8; 64];
                let records: Vec<_> = keys
                    .iter()
                    .map(|key| BatchOperation::Put {
                        key: key.as_bytes(),
                        value: &value,
                    })
                    .collect();
                store.write_batch(&records)?;
            }
        }
        [_, mode, path, destination, count] => {
            let count: usize = count.parse()?;
            let start = Instant::now();
            let digest = if mode == "ordinary" {
                CheckpointStore::rebuild_managed_selection(path, destination)?
            } else if mode == "bounded" {
                CheckpointStore::rebuild_managed_selection_full_bounded(
                    path,
                    destination,
                    BoundedFullRebuildLimits {
                        max_log_bytes: Path::new(path).join("records.log").metadata()?.len(),
                        max_operations: count as u64,
                        max_live_keys: count,
                        max_live_key_bytes: count as u64 * 32,
                        max_chunk_keys: 8,
                        max_chunk_key_bytes: 256,
                        max_spill_bytes: 64 << 20,
                        max_merge_fan_in: 2,
                    },
                )?
            } else {
                return Err("unknown rebuild mode".into());
            };
            println!(
                "rebuild_ns={} keys={count} digest={digest:02x?}",
                start.elapsed().as_nanos()
            );
        }
        _ => {
            return Err("usage: probe setup STORE COUNT | probe ordinary|bounded STORE CHECKPOINT COUNT".into());
        }
    }
    Ok(())
}
