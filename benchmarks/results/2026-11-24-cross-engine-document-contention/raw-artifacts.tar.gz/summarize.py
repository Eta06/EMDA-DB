from collections import Counter, defaultdict
from pathlib import Path
from statistics import median
import gzip
import json
import math
import sys

path = Path(sys.argv[1])
with gzip.open(path, "rt") as file:
    report = json.load(file)
assert not report.get("failure"), report.get("failure")
engines = ("store", "checkpoint", "sqlite", "postgres", "mongo")
rows = defaultdict(list)
run_ids = set()
for run in report["runs"]:
    result = run["result"]
    engine, clients = result["engine"], result["clients"]
    identity = (engine, clients, run["round"])
    assert identity not in run_ids, identity
    run_ids.add(identity)
    assert result["reopen_verified"] and run["returncode"] == 0, identity
    assert not run.get("error"), identity
    assert set(result["configuration"]) if engine in engines[3:] else True
    assert result["documents"] == report["documents"], identity
    assert len(result["clients_samples"]) == clients, identity
    values = {op: [v for sample in result["clients_samples"] for v in sample[op]]
              for op in ("update_ns", "query_ns")}
    for v in values.values():
        assert len(v) == clients * report["cycles_per_client"] and all(x >= 0 for x in v)
    def percentile(samples, p):
        return sorted(samples)[math.ceil(len(samples) * p) - 1] / 1_000
    row = dict(throughput=result["ops_per_sec"],
               update_p50=percentile(values["update_ns"], .5),
               update_p99=percentile(values["update_ns"], .99),
               query_p50=percentile(values["query_ns"], .5),
               query_p99=percentile(values["query_ns"], .99),
               samples=len(values["update_ns"]),
               update_retries=sum(s["update_retries"] for s in result["clients_samples"]),
               query_retries=sum(s["query_retries"] for s in result["clients_samples"]),
               quiet=run.get("pre_run_quiet", {}).get("quiet"),
               iowait=run["telemetry"]["vm_iowait_percent"],
               steal=run["telemetry"]["vm_steal_percent"],
               RSS_kib=result.get("peak_rss_kib"), child_cpu_seconds=run.get("child_cpu_seconds"))
    if engine in engines[3:]:
        before, after = result["resources_before"], result["resources_after"]
        server_cpu_before = before["server_cgroup_cpu"] or {}
        server_cpu_after = after["server_cgroup_cpu"] or {}
        row.update(client_cpu_ms=(after["client_cpu_ns"] - before["client_cpu_ns"]) / 1e6,
                   client_rss_mib=int(after["client_rss_kib"]) / 1024 if after["client_rss_kib"] is not None else None,
                   server_cpu_ms=(server_cpu_after["usage_usec"] - server_cpu_before["usage_usec"]) / 1000
                   if {"usage_usec"} <= server_cpu_before.keys() & server_cpu_after.keys() else None,
                   server_cgroup_mib=int(after["server_cgroup_memory_bytes"]) / 1048576
                   if after["server_cgroup_memory_bytes"] is not None else None,
                   server_io_available=bool(after["server_cgroup_io"] is not None))
    rows[(engine, clients)].append(row)

expected = {(engine, count, round_number)
            for engine in engines for count in report["clients"] for round_number in range(1, report["rounds"] + 1)}
assert run_ids == expected, (len(expected), len(run_ids))
def mid(items, key):
    values = [r[key] for r in items if r.get(key) is not None]
    return median(values) if values else None
summary = []
for count in report["clients"]:
    for engine in engines:
        items = rows[engine, count]
        summary.append(dict(engine=engine, clients=count, runs=len(items),
                            samples=sum(row["samples"] for row in items),
                            throughput_min=min(row["throughput"] for row in items),
                            throughput_max=max(row["throughput"] for row in items),
                            update_retries=sum(row["update_retries"] for row in items),
                            query_retries=sum(row["query_retries"] for row in items),
                            quiet=sum(row["quiet"] is True for row in items),
                            **{key: mid(items, key) for key in ("throughput", "update_p50", "update_p99", "query_p50", "query_p99",
                                                               "RSS_kib", "child_cpu_seconds", "client_cpu_ms", "client_rss_mib",
                                                               "server_cpu_ms", "server_cgroup_mib")}))
print(json.dumps(dict(source=report["source_revision"], platform=report["platform"], filesystem=report["filesystem"],
                      driver_cpu=report["cpu_affinity"], server_cpu=report["server_cpu_affinity"],
                      document_count=report["documents"], cycles=report["cycles_per_client"],
                      total_samples_per_operation=sum(s["samples"] for s in summary),
                      max_iowait=max(row["iowait"] or 0 for items in rows.values() for row in items),
                      max_steal=max(row["steal"] or 0 for items in rows.values() for row in items),
                      summary=summary), indent=2))
