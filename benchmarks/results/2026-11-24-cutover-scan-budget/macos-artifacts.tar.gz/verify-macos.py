import json
from pathlib import Path
import sys

root = Path(sys.argv[1])
attempt = json.loads((root / "attempt/attempt.json").read_text())
assert attempt["status"] == "exited"
assert attempt["returncode"] == attempt["wrapper_exit_code"] == 0
rows = [json.loads(line) for line in (root / "workload/measurements.jsonl").read_text().splitlines()]
assert len(rows) == 17 and len({(r["backend"], r["epoch"], r["phase"]) for r in rows}) == 17
assert all(r["exit"] == 0 and r["keys"] == 1048576 and r["address_space_limit_bytes"] is None for r in rows)
life, = (r for r in rows if r["phase"] == "authorized-lifecycle")
assert life["source_verified_entries"] == life["restored_verified_entries"] == 1045598
assert life["lifecycle_recovery_scan_limit_bytes"] == 140 * 1024**2
assert life["backup_restore_scan_limit_bytes"] == 2 * life["lifecycle_recovery_scan_limit_bytes"]
assert life["archive_retirement_scan_limit_bytes"] == life["backup_restore_scan_limit_bytes"] + life["retired_log_bytes"] + 72
print(len(rows), "successful phases,", life["source_verified_entries"], "verified entries per catalog")
print("backup ms", life["backup_ns"] / 1e6, "retirement ms", life["retire_ns"] / 1e6,
      "restore ms", life["restore_ns"] / 1e6, "peak RSS bytes", life["peak_rss_bytes"])
