use database_engine::{
    BatchOperation, CheckpointRecoveryLimits, CheckpointStore, CheckpointStoreLimits,
    RecoveryOpenFailure, Store,
};
use std::{env, fs, io, path::Path, time::Instant};

fn main() {
    let args: Vec<_> = env::args().collect();
    let root = Path::new(&args[2]);
    let path = root.join("store");
    let checkpoint = root.join("checkpoint");
    let digest_path = root.join("digest");
    if args[1] == "setup" {
        let keys: u64 = args[3].parse().unwrap();
        let store = Store::open(&path).unwrap();
        for start in (0..keys).step_by(1024) {
            let group = (start..(start + 1024).min(keys))
                .map(u64::to_be_bytes)
                .collect::<Vec<_>>();
            let ops = group
                .iter()
                .map(|key| BatchOperation::Put { key, value: b"sample-value" })
                .collect::<Vec<_>>();
            store.write_batch(&ops).unwrap();
        }
        fs::write(digest_path, store.checkpoint_to(checkpoint).unwrap()).unwrap();
        return;
    }

    let digest: [u8; 32] = fs::read(digest_path).unwrap().try_into().unwrap();
    let length = fs::metadata(path.join("records.log")).unwrap().len();
    let reject = args[1] == "short";
    let limit = length - u64::from(reject);
    let start = Instant::now();
    let result = CheckpointStore::open_with_recovery_limits(
        &path,
        &checkpoint,
        &digest,
        CheckpointStoreLimits::default(),
        CheckpointRecoveryLimits {
            max_tail_operations: Some(0),
            max_log_scan_bytes: Some(limit),
        },
    );
    let elapsed = start.elapsed().as_nanos();
    if reject {
        assert!(matches!(result, Err(RecoveryOpenFailure::NotAdopted(error))
            if error.kind() == io::ErrorKind::InvalidInput
                && error.to_string() == "checkpoint recovery log scan byte limit exceeded"));
    } else {
        assert_eq!(result.unwrap().get(&0_u64.to_be_bytes()).unwrap().as_deref(), Some(b"sample-value".as_slice()));
    }
    println!("{elapsed}");
}
