import hashlib
import json
from pathlib import Path
import platform
import random
import statistics
import subprocess
import sys
import time

root = Path(sys.argv[1]).resolve()
fixture = root / 'fixture'
cases = [(variant, mode) for variant in ('baseline', 'fixed')
         for mode in ('short', 'exact')]
fingerprints = {str(p.relative_to(fixture)): hashlib.sha256(p.read_bytes()).hexdigest()
                for p in sorted(fixture.rglob('*')) if p.is_file()}
provenance = {
    'platform': platform.platform(),
    'machine': platform.machine(),
    'compiler': subprocess.check_output(['rustc', '+1.85.0', '-Vv'], text=True),
    'fixture_keys': 262144,
    'fixture_bytes': {name: (fixture / name).stat().st_size for name in fingerprints},
    'fixture_sha256': fingerprints,
    'binaries': {variant: {
        'sha256': hashlib.sha256((root / f'{variant}.bin').read_bytes()).hexdigest(),
        'revision': (root / variant / 'source-revision').read_text().strip()
    } for variant in ('baseline', 'fixed')},
    'seed': 42,
}
(root / 'environment.json').write_text(json.dumps(provenance, indent=2) + '\n')
assert provenance['binaries']['baseline']['sha256'] != provenance['binaries']['fixed']['sha256']
rng = random.Random(42)
samples = []
with (root / 'samples.jsonl').open('x') as output:
    for repetition in range(36):
        rng.shuffle(cases)
        for variant, mode in cases:
            command = ['/usr/bin/time', '-lp', str(root / f'{variant}.bin'), mode, str(fixture)]
            start = time.monotonic_ns()
            result = subprocess.run(command, capture_output=True, text=True)
            trial = dict(variant=variant, mode=mode, repetition=repetition, warmup=repetition < 4,
                         command=command, exit=result.returncode, stdout=result.stdout,
                         stderr=result.stderr, process_elapsed_ns=time.monotonic_ns()-start)
            print(json.dumps(trial), file=output, flush=True)
            assert result.returncode == 0, trial
            samples.append((variant, mode, repetition, int(result.stdout)))
after = {str(p.relative_to(fixture)): hashlib.sha256(p.read_bytes()).hexdigest()
         for p in sorted(fixture.rglob('*')) if p.is_file()}
(root / 'fixture-after.json').write_text(json.dumps(after, indent=2) + '\n')
assert after == fingerprints
for variant, mode in sorted(cases):
    times = [ns for v, m, r, ns in samples if v == variant and m == mode and r >= 4]
    print(f'{variant} {mode}: {len(times)} samples, median {statistics.median(times)/1e6:.3f} ms')
