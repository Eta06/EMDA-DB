import collections
import json
import pathlib
import sys

root = pathlib.Path(sys.argv[1])
revision = sys.argv[2]
runs = ("45380616015", "45380615876", "45380616116", "45380615960")
for run in runs:
    state = json.loads((root / run / "jobs.json").read_text())
    assert state["headSha"] == revision, state
    assert state["status"] == "completed" and state["conclusion"] == "success", state
    assert (root / run / "workflow.log").stat().st_size > 0, run
    print(state["workflowName"], run, state["conclusion"])

for label, directory, count in [
    ("standard benchmark smoke", root / "45380616015" / "ci-benchmark-smoke", 45),
    ("cross-engine smoke", root / "45380615960", 5),
    ("four-writer recovery memory workload", root / "45380616015" / "writable-recovery-memory-ceiling", 1),
]:
    attempts = list(directory.rglob("attempt.json"))
    assert len(attempts) == count, (label, len(attempts))
    dispositions = collections.Counter()
    for path in attempts:
        attempt = json.loads(path.read_text())
        assert attempt["revision"] == revision and attempt["tracked_changes"] == "", path
        assert attempt["status"] == "exited", path
        assert (path.parent / attempt["output"]).is_file(), path
        dispositions[attempt["returncode"], attempt["wrapper_exit_code"]] += 1
    assert dispositions == {(0, 0): count}, dispositions
    print(label, dispositions)

measurements, = root.rglob("measurements.jsonl")
phases = [json.loads(line) for line in measurements.read_text().splitlines()]
capped = [phase for phase in phases if phase["address_space_limit_bytes"] is not None]
assert len(phases) == 51 and len(capped) == 24, (len(phases), len(capped))
assert all(phase["address_space_limit_bytes"] == 48 * 1024**2 for phase in capped)
print("recovery phases", len(phases), "capped at 48 MiB", len(capped))

linux_log = (root / "45380616015" / "workflow.log").read_text()
for test in ("nested_membership_work_limit_is_shared_by_scans_and_indexed_aggregation",
             "repeated_string_equality_stops_at_the_shared_text_limit"):
    lines = [line for line in linux_log.splitlines() if test + " ... ok" in line]
    assert len(lines) >= 2, (test, lines)
    print(test, len(lines), "passes")

baseline = (root / "native-macos" / "baseline-regressions.log").read_text()
for test in ("nested_membership_work_limit_is_shared_by_scans_and_indexed_aggregation",
             "repeated_string_equality_stops_at_the_shared_text_limit"):
    assert f"{test} ... FAILED" in baseline
assert "2 passed; 2 failed" in baseline
assert baseline.count("called `Result::unwrap_err()` on an `Ok` value") == 2
print("baseline reproduction", "both new regressions unexpectedly succeeded on the old code")

macos = json.loads((root / "macos-hosted-snapshot.json").read_text())
assert macos["headSha"] == revision
stable = next(job for job in macos["jobs"] if job["name"] == "Rust stable / macOS")
assert stable["conclusion"] == "success"
assert (root / "hosted-macos-stable.log").stat().st_size > 0
msrv = next(job for job in macos["jobs"] if job["name"] == "Rust 1.85.0 / macOS")
print("hosted macOS stable passed, hosted macOS Rust 1.85.0 at capture:", msrv["status"], msrv["conclusion"])

final_macos = json.loads((root / "45380616017" / "jobs.json").read_text())
assert final_macos["headSha"] == revision and final_macos["conclusion"] == "success"
assert all(job["conclusion"] == "success" for job in final_macos["jobs"])
assert (root / "45380616017" / "workflow.log").stat().st_size > 0
print("hosted macOS both toolchains passed")
