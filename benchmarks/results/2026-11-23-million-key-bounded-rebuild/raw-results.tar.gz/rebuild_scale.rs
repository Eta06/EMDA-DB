use database_engine::{
    BatchOperation, BoundedFullRebuildLimits, CheckpointStore, CheckpointViewLimits,
    ManagedRebuildFailure, Store,
};
use std::{error::Error, fs, io, path::Path, time::Instant};

type Result<T> = std::result::Result<T, Box<dyn Error>>;
const BATCH: usize = 1024;
const CHURN: usize = 16384;

fn prepare(root: &Path, keys: usize) -> Result<()> {
    let source = root.join("store");
    let store = Store::open(&source)?;
    for first in (0..keys).step_by(BATCH) {
        let bytes: Vec<_> = (first..first + BATCH)
            .map(|id| (id as u64).to_be_bytes())
            .collect();
        let entries: Vec<_> = bytes
            .iter()
            .map(|key| BatchOperation::Put { key, value: key })
            .collect();
        store.write_batch(&entries)?;
    }
    let step = keys / CHURN;
    for first in (0..CHURN).step_by(BATCH) {
        let bytes: Vec<_> = (first..first + BATCH)
            .map(|id| {
                let key = if id % 4 < 2 { id * step } else { keys + id } as u64;
                let value = if id % 4 == 1 { !key } else { key };
                (key.to_be_bytes(), value.to_be_bytes())
            })
            .collect();
        let entries: Vec<_> = bytes
            .iter()
            .enumerate()
            .map(|(i, (key, value))| {
                if i % 4 == 0 {
                    BatchOperation::Delete { key }
                } else {
                    BatchOperation::Put { key, value }
                }
            })
            .collect();
        store.write_batch(&entries)?;
    }
    drop(store);
    let output = root.join("checkpoint");
    let token = CheckpointStore::rebuild_managed_selection(&source, &output)?;
    fs::write(root.join("reference.digest"), token)?;
    fs::rename(output, root.join("reference.index"))?;
    Ok(())
}

fn rebuild(root: &Path, keys: usize, mode: &str) -> Result<()> {
    let source = root.join("store");
    let output = root.join("checkpoint");
    let selection = source.join("checkpoint.selection");
    let selected_before = fs::read(&selection)?;
    assert!(!output.exists());
    let accepted_peak = keys + CHURN / 4;
    let log_len = fs::metadata(source.join("records.log"))?.len();
    let reference_bytes = fs::metadata(root.join("reference.index"))?.len();
    let limits = BoundedFullRebuildLimits {
        max_log_bytes: log_len - u64::from(mode == "reject-log"),
        max_operations: (keys + CHURN) as u64,
        max_live_keys: accepted_peak,
        max_live_key_bytes: (accepted_peak * 8) as u64,
        max_chunk_keys: 2048,
        max_chunk_key_bytes: 16 * 1024,
        max_spill_bytes: if mode == "reject-spill" { 1 } else { 96 << 20 },
        max_merge_fan_in: 8,
    };
    let mut output_limits = CheckpointViewLimits::default();
    output_limits.max_file_bytes = reference_bytes - u64::from(mode == "reject-output");
    let start = Instant::now();
    let digest = if mode == "ordinary" {
        CheckpointStore::rebuild_managed_selection(&source, &output)?
    } else {
        let result = CheckpointStore::rebuild_managed_selection_full_bounded_with_checkpoint_limits(
            &source,
            &output,
            limits,
            output_limits,
        );
        if mode.starts_with("reject-") {
            let Err(ManagedRebuildFailure::NotPublished(error)) = result else {
                return Err(format!("{mode} unexpectedly returned {result:?}").into());
            };
            let marker = match mode {
                "reject-log" => "log exceeds",
                "reject-spill" => "spill byte limit",
                "reject-output" => "checkpoint exceeds",
                _ => unreachable!(),
            };
            assert_eq!(error.kind(), io::ErrorKind::InvalidInput, "{error}");
            assert!(error.to_string().contains(marker), "{error}");
            assert!(!output.exists());
            assert_eq!(fs::read(selection)?, selected_before);
            println!(
                "mode={mode} classified=not_published verified_unchanged_selection=true reason={error}"
            );
            return Ok(());
        }
        result?
    };
    let millis = start.elapsed().as_millis();
    assert_eq!(digest.as_slice(), fs::read(root.join("reference.digest"))?);
    println!(
        "mode={mode} keys={keys} rebuild_ms={millis} checkpoint_bytes={reference_bytes} log_bytes={log_len}"
    );
    Ok(())
}

fn verify(root: &Path, keys: usize) -> Result<()> {
    let store = CheckpointStore::open_managed(root.join("store"))?;
    assert_eq!(store.tail_bytes()?, 0);
    assert_eq!(store.overlay_keys()?, 0);
    let step = keys / CHURN;
    let expected = (0..keys + CHURN).filter_map(|id| {
        let value = if id < keys {
            match if id % step == 0 { (id / step) % 4 } else { 3 } {
                0 => return None,
                1 => !(id as u64),
                _ => id as u64,
            }
        } else {
            if (id - keys) % 4 < 2 {
                return None;
            }
            id as u64
        };
        Some(((id as u64).to_be_bytes(), value.to_be_bytes()))
    });
    let mut expected = expected.peekable();
    let mut after = None;
    let mut seen = 0;
    loop {
        let rows = store.scan(after.as_deref(), None, 1024)?;
        if rows.is_empty() {
            break;
        }
        for (key, value) in rows {
            let (expected_key, expected_value) = expected.next().ok_or("unexpected live entry")?;
            assert_eq!(key, expected_key);
            assert_eq!(value, expected_value);
            after = Some(key);
            seen += 1;
        }
    }
    assert!(expected.next().is_none());
    assert_eq!(seen, keys + CHURN / 4);
    println!("verified_entries={seen} managed_overlay_keys=0");
    Ok(())
}

fn main() -> Result<()> {
    let args: Vec<_> = std::env::args().collect();
    let [_, mode, root, size] = args.as_slice() else {
        return Err("usage: rebuild_scale MODE ROOT KEYS".into());
    };
    let keys: usize = size.parse()?;
    assert!(keys >= CHURN && keys % CHURN == 0);
    let root = Path::new(root);
    match mode.as_str() {
        "setup" => prepare(root, keys),
        "verify" => verify(root, keys),
        _ => rebuild(root, keys, mode),
    }
}
