import filecmp
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import resource
import shutil
import subprocess
import sys
import tempfile

runner, parent = map(Path, sys.argv[1:])
linux = sys.platform == "linux"
cap = 48 * 1024 * 1024


def limit():
    resource.setrlimit(resource.RLIMIT_AS, (cap, cap))


def sha(path):
    with path.open("rb") as stream:
        digest = hashlib.sha256()
        for block in iter(lambda: stream.read(64 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def source(root):
    log = root / "store" / "records.log"
    with log.open("rb") as stream:
        magic = stream.read(8)
    result = {
        "format": magic.decode(),
        "log": sha(log),
        "log_bytes": log.stat().st_size,
        "sidecar": sha(root / "store" / "commit.state"),
    }
    if magic == b"EMDALOG3":
        result["inode_witness"] = os.getxattr(log, "user.db.commit.v3").hex()
    return result


def run(root, keys, mode, pair=None, bounded=False, measured=True):
    argv = [runner, mode, root, str(keys)]
    if measured:
        argv = (["/usr/bin/time", "-f", "peak_rss_kib=%M"] if linux
                else ["/usr/bin/time", "-lp"]) + argv
    result = subprocess.run(argv, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                            preexec_fn=limit if linux and bounded else None)
    metrics = {"keys": keys, "mode": mode, "pair": pair, "exit": result.returncode,
               "address_space_cap_bytes": cap if linux and bounded else None, "output": result.stdout}
    if linux:
        match = re.search(r"peak_rss_kib=(\d+)", result.stdout)
        if match:
            metrics["peak_rss_bytes"] = int(match[1]) * 1024
    else:
        match = re.search(r"(\d+)\s+maximum resident set size", result.stdout)
        if match:
            metrics["peak_rss_bytes"] = int(match[1])
    print(json.dumps(metrics), flush=True)
    result.check_returncode()
    if measured:
        assert "peak_rss_bytes" in metrics
        if bounded:
            assert metrics["peak_rss_bytes"] <= cap

if shutil.disk_usage(parent).free < 190 * 1024 * 1024:
    raise SystemExit("fixture parent needs at least 190 MiB free")
print(json.dumps({"platform": platform.platform(), "available_bytes": shutil.disk_usage(parent).free,
                  "linux_bounded_address_space_bytes": cap if linux else None}), flush=True)
for keys in (131072, 1048576):
    with tempfile.TemporaryDirectory(dir=parent) as tmp:
        root = Path(tmp)
        run(root, keys, "setup", measured=False)
        before = source(root)
        print(json.dumps({"keys": keys, "before": before}), flush=True)
        for mode in ("reject-log", "reject-spill", "reject-output"):
            run(root, keys, mode, bounded=True)
            assert source(root) == before
        for pair in range(3):
            variants = ("ordinary", "bounded") if pair % 2 == 0 else ("bounded", "ordinary")
            for mode in variants:
                run(root, keys, mode, pair, bounded=mode == "bounded")
                assert filecmp.cmp(root / "reference.index", root / "checkpoint", shallow=False)
                run(root, keys, "verify", pair, bounded=mode == "bounded")
                (root / "checkpoint").unlink()
        after = source(root)
        assert after == before
        print(json.dumps({"keys": keys, "after": after}), flush=True)
