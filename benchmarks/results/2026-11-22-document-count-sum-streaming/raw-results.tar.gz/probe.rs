use database_engine::{
    AggregateRequest, CheckpointStore, CollectionSchema, DocumentDatabase, DocumentFilter,
    IndexValue, Store,
};
use serde_json::json;
use std::{error::Error, fs, path::Path, time::Instant};

const DOCUMENTS: usize = 192;
const GROUPS: usize = 8;
const PAYLOAD_BYTES: usize = 128 * 1024;

fn scan(db: &DocumentDatabase<'_>) -> Result<(), Box<dyn Error>> {
    let start = Instant::now();
    let result = db.aggregate(
        "c",
        &AggregateRequest {
            filter: DocumentFilter::All,
            group_by: Some(vec!["group".into()]),
            sum: Some(vec!["n".into()]),
            max_scanned: DOCUMENTS,
        },
    )?;
    let elapsed = start.elapsed().as_nanos();
    assert_eq!(result.groups.len(), GROUPS);
    assert_eq!(result.plan.scanned, DOCUMENTS);
    assert_eq!(result.plan.matched, DOCUMENTS);
    assert_eq!(result.plan.returned, DOCUMENTS);
    for (number, group) in result.groups.iter().enumerate() {
        assert_eq!(group.key, Some(IndexValue::Integer(number as i64)));
        assert_eq!(group.count, (DOCUMENTS / GROUPS) as u64);
        assert_eq!(
            group.sum,
            Some(
                (number..DOCUMENTS)
                    .step_by(GROUPS)
                    .map(|id| id as i64)
                    .sum()
            )
        );
    }
    println!("query_ns={elapsed} documents={DOCUMENTS} groups={GROUPS}");
    Ok(())
}

fn main() -> Result<(), Box<dyn Error>> {
    let args = std::env::args().collect::<Vec<_>>();
    let [_, mode, directory] = args.as_slice() else {
        return Err("usage: probe setup|ordinary|checkpoint DIRECTORY".into());
    };
    let directory = Path::new(directory);
    let source = directory.join("store");
    let checkpoint = directory.join("checkpoint");
    match mode.as_str() {
        "setup" => {
            fs::create_dir(directory)?;
            let store = Store::open(&source)?;
            let docs = DocumentDatabase::new(&store);
            docs.create_collection("c", CollectionSchema::default())?;
            let payload = "x".repeat(PAYLOAD_BYTES);
            for id in 0..DOCUMENTS {
                docs.insert(
                    "c",
                    &format!("{id:03}"),
                    &json!({
                        "group": id % GROUPS, "n": id, "payload": payload,
                    }),
                )?;
            }
            let digest = store.checkpoint_to(&checkpoint)?;
            fs::write(directory.join("digest"), digest)?;
        }
        "ordinary" => {
            let store = Store::open(&source)?;
            scan(&DocumentDatabase::new(&store))?;
        }
        "checkpoint" => {
            let digest: [u8; 32] = fs::read(directory.join("digest"))?
                .try_into()
                .map_err(|_| "wrong checkpoint digest length")?;
            let store = CheckpointStore::open(&source, &checkpoint, &digest)?;
            scan(&DocumentDatabase::with_checkpoint_store(&store))?;
        }
        _ => return Err("unknown mode".into()),
    }
    Ok(())
}
