import collections
import json
import pathlib
import sys

root = pathlib.Path(sys.argv[1])
revision = sys.argv[2]
runs = ("45383673314", "45383673286", "45383673257", "45383673093", "45383673255")
for run in runs:
    state = json.loads((root / run / "jobs.json").read_text())
    assert state["headSha"] == revision, state
    assert state["status"] == "completed" and state["conclusion"] == "success", state
    assert (root / run / "workflow.log").stat().st_size > 0, run
    print(state["workflowName"], run, state["conclusion"])

for label, directory, count in [
    ("standard benchmark smoke", root / "45383673286" / "ci-benchmark-smoke", 45),
    ("cross-engine smoke", root / "45383673255", 5),
    ("four-writer recovery memory workload", root / "45383673286" / "writable-recovery-memory-ceiling", 1),
]:
    attempts = list(directory.rglob("attempt.json"))
    assert len(attempts) == count, (label, len(attempts))
    dispositions = collections.Counter()
    for path in attempts:
        attempt = json.loads(path.read_text())
        assert attempt["revision"] == revision and attempt["tracked_changes"] == "", path
        assert attempt["status"] == "exited", path
        assert (path.parent / attempt["output"]).is_file(), path
        dispositions[attempt["returncode"], attempt["wrapper_exit_code"]] += 1
    assert dispositions == {(0, 0): count}, dispositions
    print(label, dispositions)

measurements, = root.rglob("measurements.jsonl")
phases = [json.loads(line) for line in measurements.read_text().splitlines()]
capped = [phase for phase in phases if phase["address_space_limit_bytes"] is not None]
assert len(phases) == 51 and len(capped) == 24, (len(phases), len(capped))
assert all(phase["address_space_limit_bytes"] == 48 * 1024**2 for phase in capped)
print("recovery phases", len(phases), "capped at 48 MiB", len(capped))

linux_log = (root / "45383673286" / "workflow.log").read_text()
for test in ("recovery_scan_budget_includes_the_base_before_checking_payloads",
             "recovery_adopts_an_exact_proposed_tail_before_finalizing_a_pending_intent"):
    lines = [line for line in linux_log.splitlines() if test + " ... ok" in line]
    assert len(lines) >= 2, (test, lines)
    print(test, len(lines), "passes")

artifact, = (root / "45383673093").rglob("rebuild-witness-faults.jsonl")
traces = [case for line in artifact.read_text().splitlines()
          if (case := json.loads(line)).get("rebuild") == "retained-managed"]
assert len(traces) == 4
assert {(case["format"], case["point"]) for case in traces} == {
    (fmt, name) for fmt in ("v2", "v3")
    for name in ("retained recovery scan limit", "retained recovery suffix scan limit")
}
for case in traces:
    assert len(case["checks"]) == 4
    combined = case["point"] == "retained recovery scan limit"
    for check, (count, accepted) in zip(case["checks"], ((2, False), (2, True), (1, False), (1, True))):
        base_bytes = case["base_bytes"]
        suffix_bytes = case["suffix_bytes"]
        want = (base_bytes if combined else 0) + count * suffix_bytes
        assert check["cap"] == want - int(not accepted)
        assert check["outcome"]["status"] == ("success" if accepted else "error")
        assert sum(check["suffix_reads"]) == (count * suffix_bytes if accepted else 0)
        assert sum(check["base_reads"]) == (base_bytes if accepted else 0)
        assert check["trace"]
    print(case["format"], case["point"], "base", case["base_bytes"], "suffix", case["suffix_bytes"])
