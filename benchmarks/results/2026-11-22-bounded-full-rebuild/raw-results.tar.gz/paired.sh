set -eu
run=$1
mkdir "$run/samples"
for n in 1 2 3; do
  if [ "$((n % 2))" -eq 1 ]; then order="ordinary bounded"; else order="bounded ordinary"; fi
  for mode in $order; do
    /usr/bin/time -lp "$run/probe" "$mode" "$run/store" "$run/sampled-$mode-$n.checkpoint" > "$run/samples/$mode-$n.log" 2>&1
  done
  cmp "$run/sampled-ordinary-$n.checkpoint" "$run/sampled-bounded-$n.checkpoint"
done
