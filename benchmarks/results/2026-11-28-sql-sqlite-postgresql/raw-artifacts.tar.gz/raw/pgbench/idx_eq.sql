\set id random(0, 9999)
SELECT id, code, tag, active, score FROM items1 WHERE code = :id * 3 + 7;
