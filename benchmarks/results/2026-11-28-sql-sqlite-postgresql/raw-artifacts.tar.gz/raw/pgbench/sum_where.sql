SELECT SUM(val) FROM agg_items WHERE active = TRUE AND score >= 0.0;
