\set id random(0, 1999)
SELECT u.name, o.total FROM users u JOIN orders o ON o.user_id = u.id WHERE u.id = :id;
