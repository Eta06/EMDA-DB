\set t random(0, 49)
SELECT u.name, t.title FROM users u JOIN teams t ON t.id = u.team WHERE u.team = :t ORDER BY u.name;
