\set id random(0, 1999)
SELECT u.name, t.title FROM users u JOIN teams t ON t.id = u.team WHERE u.id = :id;
