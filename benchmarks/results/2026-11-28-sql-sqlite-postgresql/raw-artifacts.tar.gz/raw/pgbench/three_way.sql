SELECT o.id, u.name, t.title FROM orders o JOIN users u ON u.id = o.user_id JOIN teams t ON t.id = u.team WHERE o.total > 20.0 ORDER BY o.id LIMIT 20;
