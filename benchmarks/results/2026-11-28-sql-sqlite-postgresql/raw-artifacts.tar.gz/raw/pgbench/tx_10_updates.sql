BEGIN;
\set id0 random(0, 9999)
UPDATE tx_items SET score = 0.5 WHERE id = :id0;
\set id1 random(0, 9999)
UPDATE tx_items SET score = 1.5 WHERE id = :id1;
\set id2 random(0, 9999)
UPDATE tx_items SET score = 2.5 WHERE id = :id2;
\set id3 random(0, 9999)
UPDATE tx_items SET score = 3.5 WHERE id = :id3;
\set id4 random(0, 9999)
UPDATE tx_items SET score = 4.5 WHERE id = :id4;
\set id5 random(0, 9999)
UPDATE tx_items SET score = 5.5 WHERE id = :id5;
\set id6 random(0, 9999)
UPDATE tx_items SET score = 6.5 WHERE id = :id6;
\set id7 random(0, 9999)
UPDATE tx_items SET score = 7.5 WHERE id = :id7;
\set id8 random(0, 9999)
UPDATE tx_items SET score = 8.5 WHERE id = :id8;
\set id9 random(0, 9999)
UPDATE tx_items SET score = 9.5 WHERE id = :id9;
COMMIT;
