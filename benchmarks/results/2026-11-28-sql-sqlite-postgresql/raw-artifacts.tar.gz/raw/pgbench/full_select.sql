SELECT id FROM items WHERE score >= 0.0 AND active = TRUE;
