SELECT COUNT(*) FROM agg_items;
