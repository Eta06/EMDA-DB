DELETE FROM items WHERE id = (SELECT min(id) FROM items WHERE id >= 1000000);
