SELECT grp, COUNT(*), SUM(val), AVG(score) FROM agg_items GROUP BY grp;
