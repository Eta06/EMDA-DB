\set id random(0, 9989)
SELECT id, code, tag, active, score FROM items1 WHERE code >= :id * 3 + 7 AND code < :id * 3 + 37;
