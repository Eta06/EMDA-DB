INSERT INTO items VALUES (nextval('new_ids'), 'new', 1.5, true);
