\set id random(20000, 600000000)
INSERT INTO items3 VALUES (:id, :id * 3 + 7, 'tag-0001', true, 1.5);
