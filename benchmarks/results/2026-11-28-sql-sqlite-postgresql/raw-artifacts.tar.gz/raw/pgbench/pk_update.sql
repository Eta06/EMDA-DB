\set id random(0, 9999)
UPDATE items SET score = -1.0 WHERE id = :id;
