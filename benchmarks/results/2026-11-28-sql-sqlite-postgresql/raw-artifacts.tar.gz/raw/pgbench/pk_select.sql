\set id random(0, 9999)
SELECT id, name, score, active FROM items WHERE id = :id;
