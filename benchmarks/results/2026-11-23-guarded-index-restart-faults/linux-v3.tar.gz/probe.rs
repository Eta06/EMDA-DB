use database_engine::{
    CheckpointStore, CollectionSchema, DocumentDatabase, DocumentTransactionMode, IndexDefinition,
    IndexJobStatus, MaintenanceKey, Store, TransactionFailure,
};
use serde_json::json;
use std::{env, fs, io, path::Path};

fn index() -> IndexDefinition {
    IndexDefinition { name: "guarded".into(), fields: vec![vec!["x".into()]], unique: true, partial: None }
}

fn restart(db: &DocumentDatabase<'_>) -> io::Result<()> {
    eprintln!("RESTART-BEGIN");
    let result = db.transaction_detailed(DocumentTransactionMode::ReadSet, None, None, |tx| {
        tx.restart_index_build_guarded("c", &index(), &key())?;
        tx.put_raw(b"restart-receipt", b"guarded")
    });
    match result {
        Ok(()) => println!("committed"),
        Err(TransactionFailure::OutcomeUnknown(error)) => println!("unknown {error:?}"),
        Err(error) => panic!("unexpected outcome: {error:?}"),
    }
    Ok(())
}

fn key() -> MaintenanceKey {
    MaintenanceKey::from_bytes([7; 32])
}

fn check(db: &DocumentDatabase<'_>, committed: bool) -> io::Result<()> {
    assert_eq!(db.transaction(|tx| tx.get_raw(b"restart-receipt"))?.as_deref(), committed.then_some(b"guarded".as_slice()));
    assert_eq!(db.index_jobs("c")?, vec![IndexJobStatus::Building {
        definition: index(), after: (!committed).then(|| "a".to_owned()),
    }]);
    let error = db.transaction::<()>(|tx| {
        let advance = |tx: &mut database_engine::DocumentTransaction<'_, '_>| {
            if committed { tx.advance_index_build_guarded("c", "guarded", 1, &key()) }
            else { tx.advance_index_build("c", "guarded", 1) }
        };
        for _ in 0..if committed { 2 } else { 1 } {
            let progress = advance(tx)?;
            assert_eq!((progress.processed, progress.complete), (1, false));
        }
        assert!(advance(tx)?.complete);
        let integrity = tx.verify_collection("c")?;
        assert_eq!((integrity.documents, integrity.index_keys), (2, 4));
        Err(io::Error::other("discard"))
    }).unwrap_err();
    assert_eq!(error.to_string(), "discard");
    println!("verified committed={committed}");
    Ok(())
}

fn main() -> io::Result<()> {
    let args = env::args().collect::<Vec<_>>();
    let root = Path::new(&args[2]);
    let path = root.join("store");
    let checkpoint = root.join("checkpoint");
    if args[1] == "setup" {
        fs::create_dir(root)?;
        let store = Store::open(&path)?;
        let db = DocumentDatabase::new(&store);
        db.create_collection("c", CollectionSchema::default())?;
        db.insert("c", "a", &json!({"x":1}))?;
        db.insert("c", "b", &json!({"x":2}))?;
        db.start_index_build("c", index())?;
        assert_eq!(db.advance_index_build("c", "guarded", 1)?.processed, 1);
        fs::write(root.join("digest"), store.checkpoint_to(&checkpoint)?)?;
    } else if args[3] == "checkpoint" {
        let digest = fs::read(root.join("digest"))?.try_into().unwrap();
        let store = CheckpointStore::open(path, checkpoint, &digest)?;
        let db = DocumentDatabase::with_checkpoint_store(&store);
        if args[1] == "restart" { restart(&db)?; }
        else { check(&db, args[4] == "true")?; }
    } else {
        let store = Store::open(path)?;
        let db = DocumentDatabase::new(&store);
        if args[1] == "restart" { restart(&db)?; }
        else { check(&db, args[4] == "true")?; }
    }
    Ok(())
}
