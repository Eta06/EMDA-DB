use database_engine::retained_base_v2::Limits;
use database_engine::retained_candidate::{
    AuthorityPoint, AuthorityRecord, AuthorizedRetainedStore, IndexLimits, OverlayLimits,
    RetainedAuthority, RetainedStoreLimits, SuffixLimits,
};
use database_engine::{RetainedExportLimits, Store};
use std::{
    fs,
    io::{self, Write},
    path::PathBuf,
};

const LIMITS: RetainedStoreLimits = RetainedStoreLimits {
    base: Limits {
        file_bytes: 8192,
        entries: 32,
        key_bytes: 256,
        work_bytes: 8193,
    },
    index: IndexLimits {
        blocks: 4,
        anchor_bytes: 64,
    },
    suffix: SuffixLimits {
        bytes: 8192,
        operations: 64,
        work: 4096,
    },
    overlay: OverlayLimits {
        entries: 32,
        key_bytes: 256,
    },
};
fn encode(point: AuthorityPoint, bytes: &mut Vec<u8>) {
    bytes.extend(point.catalog);
    bytes.extend(point.generation);
    bytes.extend(point.header_digest);
    bytes.extend(point.suffix_end.to_le_bytes());
    bytes.extend(point.suffix_digest);
}
fn decode(bytes: &[u8]) -> AuthorityPoint {
    AuthorityPoint {
        catalog: bytes[..16].try_into().unwrap(),
        generation: bytes[16..32].try_into().unwrap(),
        header_digest: bytes[32..64].try_into().unwrap(),
        suffix_end: u64::from_le_bytes(bytes[64..72].try_into().unwrap()),
        suffix_digest: bytes[72..104].try_into().unwrap(),
    }
}

// Single-updater test adapter. The shell always waits for each process exit.
struct LocalProbe {
    path: PathBuf,
    stop: String,
}
impl LocalProbe {
    fn pause(&self, boundary: &str) {
        if self.stop == boundary {
            println!("rotation {boundary}");
            io::stdout().flush().unwrap();
            loop {
                std::thread::park()
            }
        }
    }
}
impl RetainedAuthority for LocalProbe {
    fn read(&mut self) -> io::Result<Option<AuthorityRecord>> {
        let bytes = match fs::read(&self.path) {
            Ok(bytes) => bytes,
            Err(error) if error.kind() == io::ErrorKind::NotFound => return Ok(None),
            Err(error) => return Err(error),
        };
        assert!(bytes.len() == 112 || bytes.len() == 216);
        Ok(Some(AuthorityRecord {
            revision: u64::from_le_bytes(bytes[..8].try_into().unwrap()),
            committed: decode(&bytes[8..112]),
            pending: (bytes.len() == 216).then(|| decode(&bytes[112..])),
        }))
    }
    fn compare_and_swap(
        &mut self,
        previous: Option<AuthorityRecord>,
        next: AuthorityRecord,
    ) -> io::Result<bool> {
        if self.read()? != previous {
            return Ok(false);
        }
        self.pause("before");
        let mut bytes = next.revision.to_le_bytes().to_vec();
        encode(next.committed, &mut bytes);
        if let Some(point) = next.pending {
            encode(point, &mut bytes);
        }
        let stage = self.path.with_extension("next");
        let mut output = fs::OpenOptions::new()
            .write(true)
            .create_new(true)
            .open(&stage)?;
        output.write_all(&bytes)?;
        output.sync_all()?;
        fs::rename(stage, &self.path)?;
        fs::File::open(self.path.parent().unwrap())?.sync_all()?;
        self.pause("after");
        Ok(true)
    }
}
fn main() {
    let args: Vec<String> = std::env::args().collect();
    let phase = &args[1];
    let catalog = PathBuf::from(&args[2]);
    let mut provider = LocalProbe {
        path: PathBuf::from(&args[3]),
        stop: args.get(4).cloned().unwrap_or_default(),
    };
    if phase == "seed" {
        let source = catalog.with_extension("source");
        let store = Store::open(&source).unwrap();
        store.put(b"base", b"verified").unwrap();
        let initial = AuthorizedRetainedStore::<LocalProbe>::prepare_from_store(
            store,
            &source,
            &catalog,
            RetainedExportLimits {
                max_log_bytes: 8192,
                max_live_keys: 32,
                max_live_key_bytes: 256,
                max_output_bytes: 8192,
            },
            LIMITS,
        )
        .unwrap();
        assert!(provider.compare_and_swap(None, initial).unwrap());
        let mut db = AuthorizedRetainedStore::open(catalog, LIMITS, provider).unwrap();
        db.put(b"ack", b"acknowledged").unwrap();
        return;
    }
    let prior = provider.read().unwrap().unwrap();
    let mut db = AuthorizedRetainedStore::open(catalog, LIMITS, provider).unwrap();
    assert_eq!(db.get(b"ack", 12).unwrap().unwrap(), b"acknowledged");
    if phase == "rotate" {
        db.compact().unwrap();
    } else {
        assert_eq!(prior.committed.suffix_end == 0, phase == "recover-after");
        assert!(db.reclaim_inactive().unwrap());
        db.put(b"new", b"recovered").unwrap();
        assert_eq!(db.get(b"new", 9).unwrap().unwrap(), b"recovered");
        println!("{phase} verified");
    }
}
