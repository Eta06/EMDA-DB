use database_engine::{CollectionSchema, DocumentDatabase, IndexDefinition, MaintenanceKey, Store};
fn main() -> std::io::Result<()> {
    let path = std::env::args_os().nth(1).unwrap();
    let store = Store::open(path)?;
    let db = DocumentDatabase::new(&store);
    for collection in ["guarded-index", "guarded-schema", "legacy"] {
        db.create_collection(collection, CollectionSchema::default())?;
    }
    db.start_index_build_guarded("guarded-index", IndexDefinition {
        name: "score".into(), fields: vec![vec!["n".into()]], unique: true, partial: None,
    }, &MaintenanceKey::generate()?)?;
    db.start_schema_migration_guarded("guarded-schema", CollectionSchema::default(), &MaintenanceKey::generate()?)?;
    Ok(())
}
