use database_engine::{DocumentDatabase, Store};
use std::io::ErrorKind;
fn main() -> std::io::Result<()> {
    let path = std::env::args_os().nth(1).unwrap();
    let store = Store::open(path)?;
    let db = DocumentDatabase::new(&store);
    assert!(db.index_jobs("legacy")?.is_empty());
    assert_eq!(db.advance_index_build("guarded-index", "score", 1).unwrap_err().kind(), ErrorKind::InvalidData);
    assert_eq!(db.advance_schema_migration("guarded-schema", 1).unwrap_err().kind(), ErrorKind::InvalidData);
    println!("previous reader accepted legacy metadata and rejected both guarded job types");
    Ok(())
}
