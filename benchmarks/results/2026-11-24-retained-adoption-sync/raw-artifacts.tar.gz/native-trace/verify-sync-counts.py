import re
import sys
from pathlib import Path

root = Path(sys.argv[1])
for variant in ("baseline", "candidate"):
    for branch in ("ADOPT", "VISIBLE"):
        text = (root / f"{variant}-{branch}.log").read_text()
        assert "test result: ok. 1 passed; 0 failed" in text
        matches = list(re.finditer(fr"^TRACE {branch} START$\n(.*?)^TRACE {branch} END$", text, re.M | re.S))
        assert len(matches) == 1, matches
        observed = matches[0][1].splitlines()
        expected = ["TRACE LOCAL LOG", "TRACE LOCAL WITNESS"]
        if variant == "baseline" and branch == "ADOPT":
            expected *= 2
        assert observed == expected, (variant, branch, observed)
        print(variant, branch, observed)
