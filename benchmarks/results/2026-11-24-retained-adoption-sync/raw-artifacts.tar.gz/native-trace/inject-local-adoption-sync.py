from pathlib import Path

def replace(path, before, after):
    path = Path(path)
    source = path.read_text()
    assert source.count(before) == 1, before
    path.write_text(source.replace(before, after))

production = "src/retained_candidate/writable.rs"
test = "src/retained_candidate/writable/managed/authority/tests.rs"
failure = """
        let point = std::env::var("EMDA_LOCAL_ADOPTION_SYNC_FAILURE").ok();
        if point.as_deref() == Some("POINT") {
            return Err(io::Error::from_raw_os_error(rustix::io::Errno::IO.raw_os_error()));
        }
"""
replace(
    production,
    '            log.sync_data()?;\n            eprintln!("TRACE LOCAL LOG");',
    failure.replace("POINT", "log") + '            log.sync_data()?;\n            eprintln!("TRACE LOCAL LOG");',
)
replace(
    production,
    "    write_witness(file, header, end, &hash.clone().finalize().into())?;\n    file.sync_data()",
    "    write_witness(file, header, end, &hash.clone().finalize().into())?;\n"
    + failure.replace("POINT", "witness") + "    file.sync_data()",
)
replace(
    test,
    "    let mut recovered = open_combined(cap).unwrap();",
    """
    let recovered = open_combined(cap);
    if let Ok(point) = std::env::var("EMDA_LOCAL_ADOPTION_SYNC_FAILURE") {
        let error = recovered.err().expect("open must fail at the selected synchronization");
        assert_eq!(error.raw_os_error(), Some(rustix::io::Errno::IO.raw_os_error()));
        assert_eq!(f.provider.clone().read().unwrap(), authority);
        assert_eq!(fs::read(&log_path).unwrap(), original_log);
        let visible = fs::read(&witnessed_path).unwrap();
        assert_eq!(visible != witness, point == "witness");
        println!("TRACE INJECT {point} PRESERVED AUTHORITY");
        return;
    }
    let mut recovered = recovered.unwrap();
""",
)
