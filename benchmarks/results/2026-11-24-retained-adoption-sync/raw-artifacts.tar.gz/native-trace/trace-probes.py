from pathlib import Path

path = Path("src/retained_candidate/writable/managed/authority/tests.rs")
text = path.read_text()
adoption = "    let mut recovered = open_combined(cap).unwrap();"
assert text.count(adoption) == 1
text = text.replace(adoption, f'    eprintln!("TRACE ADOPT START");\n{adoption}\n    eprintln!("TRACE ADOPT END");')
start = text.index("fn pending_recovery_requires_local_sync_even_with_an_advanced_witness()")
first = text.index("    let mut reopened = AuthorizedRetainedStore::open_with_suffix_scan_limit(", start)
last = text.index("\n    assert_eq!(reopened.get", first)
text = text[:first] + '    eprintln!("TRACE VISIBLE START");\n' + text[first:last] + '\n    eprintln!("TRACE VISIBLE END");' + text[last:]
path.write_text(text)
