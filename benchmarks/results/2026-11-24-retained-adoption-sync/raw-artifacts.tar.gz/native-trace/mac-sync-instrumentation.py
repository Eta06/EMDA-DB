from pathlib import Path

path = Path("src/retained_candidate/writable.rs")
text = path.read_text()
statements = {
    "            log.sync_data()?;\n            // Bind the witness update": (
        '            log.sync_data()?;\n'
        '            eprintln!("TRACE LOCAL LOG");\n'
        '            // Bind the witness update'
    ),
    "            update_witness(&witness, header.bytes(), suffix_len, &hash)?;": (
        '            update_witness(&witness, header.bytes(), suffix_len, &hash)?;\n'
        '            eprintln!("TRACE LOCAL WITNESS");'
    ),
    "        self.log.sync_data()?;\n        self.witness.sync_data()": (
        '        self.log.sync_data()?;\n'
        '        eprintln!("TRACE LOCAL LOG");\n'
        '        self.witness.sync_data()?;\n'
        '        eprintln!("TRACE LOCAL WITNESS");\n'
        '        Ok(())'
    ),
}
for before, after in statements.items():
    assert text.count(before) == 1, before
    text = text.replace(before, after)
path.write_text(text)
