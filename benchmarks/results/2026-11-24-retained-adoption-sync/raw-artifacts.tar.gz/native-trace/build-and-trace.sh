set -eu
work=$1
variant=$2
output="$work/evidence"
cd "$work/src"
export CARGO_TARGET_DIR="$work/target"
export CARGO_PROFILE_TEST_DEBUG=0 CARGO_INCREMENTAL=0 TMPDIR="$work/tmp"
export PATH="$HOME/.cargo/bin:$PATH"
cargo +1.85.0 test --lib --no-run --offline --locked -j 2 --message-format=json > "$output/$variant-build.jsonl" 2> "$output/$variant-build.log"
binary=$(python3 - "$output/$variant-build.jsonl" <<'PY'
import json, sys
with open(sys.argv[1]) as f:
    binaries = [p["executable"] for line in f if (p := json.loads(line)).get("executable") and p["target"]["kind"] == ["lib"]]
assert len(binaries) == 1, binaries
print(binaries[0])
PY
)
sha256sum "$binary" > "$output/$variant-binary.sha256"
for spec in ADOPT:recovery_adopts_an_exact_proposed_tail_before_finalizing_a_pending_intent VISIBLE:pending_recovery_requires_local_sync_even_with_an_advanced_witness; do
    case_name=${spec%%:*}
    test_name=${spec#*:}
    strace -f -yy -s 180 -e trace=fdatasync,fsync,write -o "$output/$variant-$case_name.strace" \
        "$binary" "retained_candidate::writable::managed::authority::tests::$test_name" --exact --nocapture \
        > "$output/$variant-$case_name.log" 2>&1
done
