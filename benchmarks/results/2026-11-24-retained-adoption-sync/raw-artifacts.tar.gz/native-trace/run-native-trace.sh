set -eu
src=$1
output=$2
variant=$3
export PATH="$HOME/.cargo/bin:$PATH"
export CARGO_TARGET_DIR="$src/target" CARGO_PROFILE_TEST_DEBUG=0 CARGO_INCREMENTAL=0
cd "$src"
cargo +1.85.0 test --locked --offline --lib --no-run -j 2 --message-format=json > "$output/$variant-build.jsonl" 2> "$output/$variant-build.log"
binary=$(python3 - "$output/$variant-build.jsonl" <<'PY'
import json, sys
with open(sys.argv[1]) as f:
    binaries = [p["executable"] for line in f if (p := json.loads(line)).get("executable") and p["target"]["kind"] == ["lib"]]
assert len(binaries) == 1, binaries
print(binaries[0])
PY
)
shasum -a 256 "$binary" > "$output/$variant-binary.sha256"
for spec in ADOPT:recovery_adopts_an_exact_proposed_tail_before_finalizing_a_pending_intent VISIBLE:pending_recovery_requires_local_sync_even_with_an_advanced_witness; do
    case_name=${spec%%:*}
    test_name=${spec#*:}
    "$binary" "retained_candidate::writable::managed::authority::tests::$test_name" --exact --nocapture \
        > "$output/$variant-$case_name.log" 2>&1
done
