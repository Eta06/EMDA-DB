set -eu
run=$1
store=$2
mkdir "$run/samples"
for n in 1 2 3 4 5 6; do
  if [ "$((n % 2))" -eq 1 ]; then order="baseline candidate"; else order="candidate baseline"; fi
  for mode in $order; do
    /usr/bin/time -lp "$run/$mode" bounded "$store" "$run/$mode-$n.checkpoint" > "$run/samples/$mode-$n.log" 2>&1
  done
  cmp "$run/baseline-$n.checkpoint" "$run/candidate-$n.checkpoint"
done
