"""Pair automatic checkpoint trials on private copies of a witnessed fixture."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile


def digest(path, prefix=None):
    value = hashlib.sha256()
    with path.open("rb") as file:
        while prefix != 0:
            length = 64 * 1024 if prefix is None else min(prefix, 64 * 1024)
            block = file.read(length)
            if not block:
                assert prefix is None
                break
            value.update(block)
            if prefix is not None:
                prefix -= len(block)
    return value.hexdigest()


def identity(root):
    log = root / "records.log"
    with log.open("rb") as source:
        magic = source.read(8)
    result = {
        "magic": magic.decode(),
        "log": digest(log),
        "witness": digest(root / "commit.state"),
        "selection": digest(root / "checkpoint.selection"),
        "log_bytes": log.stat().st_size,
    }
    if magic == b"EMDALOG3":
        result["metadata_witness"] = os.getxattr(log, "user.db.commit.v3").hex()
    return result


baseline, candidate, parent = map(Path, sys.argv[1:])
keys, width = 131_072, 32
with tempfile.TemporaryDirectory(dir=parent) as tmp:
    root = Path(tmp)
    subprocess.run([baseline, "seed", root, str(keys), str(width)], check=True, timeout=180)
    before = identity(root / "store")
    print(json.dumps({"keys": keys, "width": width, "before": before}), flush=True)
    for pair in range(7):
        variants = [("baseline", baseline), ("candidate", candidate)]
        modes = ("on-demand", "worker", "sustained")
        if pair % 2:
            variants.reverse()
            modes = modes[::-1]
        for mode in modes:
            for variant, binary in variants:
                with tempfile.TemporaryDirectory(dir=root) as trial_dir:
                    trial = Path(trial_dir) / "store"
                    shutil.copytree(root / "store", trial)
                    assert identity(trial) == before
                    out = subprocess.check_output(
                        [binary, "run", root, trial, str(width), mode], text=True, timeout=45
                    )
                    after = identity(trial)
                    assert after["selection"] != before["selection"]
                    assert digest(trial / "records.log", before["log_bytes"]) == before["log"]
                    if mode == "worker":
                        assert after == {**before, "selection": after["selection"]}
                    else:
                        assert after["log_bytes"] > before["log_bytes"]
                    values = dict(field.split("=", 1) for field in out.split())
                    print(json.dumps({"pair": pair, "variant": variant, "mode": mode,
                                      "after": after,
                                      **{name: int(value) for name, value in values.items()}}),
                          flush=True)
    after = identity(root / "store")
    assert after == before
    print(json.dumps({"after": after}), flush=True)
