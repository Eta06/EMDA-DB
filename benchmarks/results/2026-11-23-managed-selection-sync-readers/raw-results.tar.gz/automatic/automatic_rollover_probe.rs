use database_engine::{BatchOperation, COMPACTED_CHECKPOINT_FILE, CheckpointStore, Store};
use rustix::time::{ClockId, clock_gettime};
use std::error::Error;
use std::fs::File;
use std::io::{BufReader, Read};
use std::path::Path;
use std::sync::{
    Arc, Barrier,
    atomic::{AtomicBool, Ordering},
};
use std::time::{Duration, Instant};

type Result<T> = std::result::Result<T, Box<dyn Error>>;
const BATCH: usize = 1024;

fn key(id: usize, width: usize) -> Vec<u8> {
    let mut key = (id as u64).to_be_bytes().to_vec();
    key.resize(width, b'k');
    key
}

fn put_batch(store: &Store, first: usize, width: usize, value: &[u8]) -> Result<()> {
    let keys = (first..first + BATCH)
        .map(|i| key(i, width))
        .collect::<Vec<_>>();
    let ops = keys
        .iter()
        .map(|key| BatchOperation::Put { key, value })
        .collect::<Vec<_>>();
    store.write_batch(&ops)?;
    Ok(())
}

fn seed(root: &Path, keys: usize, width: usize) -> Result<()> {
    assert_eq!(keys % BATCH, 0);
    let path = root.join("store");
    let store = Store::open(&path)?;
    for start in (0..keys).step_by(BATCH) {
        put_batch(&store, start, width, b"initial!")?;
    }
    let base = root.join("base");
    let digest = store.checkpoint_to(&base)?;
    drop(store);
    let store = CheckpointStore::open(&path, &base, &digest)?;
    store.rollover_managed(root.join("managed"))?;
    store.enable_automatic_checkpoints()?;
    drop(store);
    let store = Store::open(&path)?;
    put_batch(&store, 0, width, b"updated!")?;
    put_batch(&store, keys, width, b"inserted")?;
    store.checkpoint_to(root.join("reference"))?;
    Ok(())
}

fn cpu_ns() -> i128 {
    let time = clock_gettime(ClockId::ProcessCPUTime);
    i128::from(time.tv_sec) * 1_000_000_000 + i128::from(time.tv_nsec)
}

fn assert_same_file(reference: &Path, candidate: &Path) -> Result<u64> {
    const CHUNK: usize = 64 * 1024;
    let reference = File::open(reference)?;
    let candidate = File::open(candidate)?;
    let bytes = reference.metadata()?.len();
    assert_eq!(bytes, candidate.metadata()?.len());
    let mut reference = BufReader::new(reference);
    let mut candidate = BufReader::new(candidate);
    let mut left = [0_u8; CHUNK];
    let mut right = [0_u8; CHUNK];
    let mut remaining = bytes;
    while remaining > 0 {
        let count = remaining.min(CHUNK as u64) as usize;
        reference.read_exact(&mut left[..count])?;
        candidate.read_exact(&mut right[..count])?;
        assert_eq!(&left[..count], &right[..count]);
        remaining -= count as u64;
    }
    Ok(bytes)
}

fn run(root: &Path, store_path: &Path, width: usize, mode: &str) -> Result<()> {
    let on_demand = match mode {
        "on-demand" => true,
        "worker" => false,
        _ => return Err("unknown rollover mode".into()),
    };
    let store = Arc::new(CheckpointStore::open_managed_with_resource_limits(
        store_path,
        1024 * 1024,
        2 * BATCH,
        2 * BATCH * width,
        None,
    )?);
    assert!(store.automatic_checkpoints_enabled()?);
    assert_eq!(store.overlay_keys()?, 2 * BATCH);
    let worker = if on_demand {
        None
    } else {
        Some(store.start_checkpoint_worker(Duration::from_secs(3600), 1)?)
    };
    let output = store_path
        .join(".emda-auto-checkpoints-v1/slot-0")
        .join(COMPACTED_CHECKPOINT_FILE);
    let target_key = key(0, width);
    let trigger_key = b"trigger";
    let barrier = Barrier::new(2);
    let done = AtomicBool::new(false);
    let (result, elapsed, cpu, sample_count, read_max) = std::thread::scope(|scope| {
        let reader = scope.spawn(|| {
            barrier.wait();
            let mut count = 0;
            let mut max = 0;
            loop {
                let start = Instant::now();
                let value = store.get(&target_key).unwrap().unwrap();
                let elapsed = start.elapsed().as_nanos();
                assert_eq!(value, b"updated!");
                max = max.max(elapsed);
                count += 1;
                if done.load(Ordering::Acquire) {
                    return (count, max);
                }
                std::thread::sleep(Duration::from_millis(1));
            }
        });
        barrier.wait();
        let start = Instant::now();
        let cpu_start = cpu_ns();
        let result = (|| -> Result<()> {
            if let Some(worker) = &worker {
                worker.request_check()?;
                loop {
                    let status = worker.status();
                    if status.checkpoints == 1 {
                        return Ok(());
                    }
                    if status.last_error.is_some() || start.elapsed() >= Duration::from_secs(20) {
                        return Err(format!("worker rollover did not complete: {status:?}").into());
                    }
                    std::thread::sleep(Duration::from_micros(250));
                }
            }
            store.put(trigger_key, b"committed")?;
            Ok(())
        })();
        let cpu = cpu_ns() - cpu_start;
        let elapsed = start.elapsed().as_nanos();
        done.store(true, Ordering::Release);
        let (count, read_max) = reader.join().unwrap();
        (result, elapsed, cpu, count, read_max)
    });
    result?;
    if let Some(worker) = worker {
        assert_eq!(worker.stop()?.checkpoints, 1);
    }
    let expected_trigger = on_demand.then(|| b"committed".to_vec());
    assert_eq!(store.overlay_keys()?, usize::from(on_demand));
    assert_eq!(store.get(trigger_key)?, expected_trigger);
    let bytes = assert_same_file(&root.join("reference"), &output)?;
    drop(store);
    let reopened = CheckpointStore::open_managed(store_path)?;
    assert_eq!(reopened.get(&target_key)?.unwrap(), b"updated!");
    assert_eq!(reopened.get(trigger_key)?, expected_trigger);
    assert_eq!(reopened.overlay_keys()?, usize::from(on_demand));
    println!(
        "elapsed_ns={elapsed} cpu_ns={cpu} output_bytes={bytes} reader_samples={sample_count} max_reader_ns={read_max}"
    );
    Ok(())
}

fn run_sustained(store_path: &Path, width: usize) -> Result<()> {
    const ROUNDS: usize = 12;
    let store = CheckpointStore::open_managed_with_resource_limits(
        store_path,
        1024 * 1024,
        2 * BATCH,
        2 * BATCH * width,
        None,
    )?;
    let target_key = key(0, width);
    let trigger_keys = [b"trigger-a", b"trigger-b"];
    let filler: Vec<_> = (1..2 * BATCH).map(|i| key(i, width)).collect();
    let barrier = Barrier::new(2);
    let done = AtomicBool::new(false);
    let (result, elapsed, cpu, samples, read_max, write_max, write_sum) =
        std::thread::scope(|scope| {
            let reader = scope.spawn(|| {
                barrier.wait();
                let mut count = 0;
                let mut max = 0;
                loop {
                    let start = Instant::now();
                    let value = store.get(&target_key).unwrap().unwrap();
                    max = max.max(start.elapsed().as_nanos());
                    assert_eq!(value, b"updated!");
                    count += 1;
                    if done.load(Ordering::Acquire) {
                        return (count, max);
                    }
                    std::thread::sleep(Duration::from_millis(1));
                }
            });
            barrier.wait();
            let start = Instant::now();
            let cpu_start = cpu_ns();
            let mut write_max = 0;
            let mut write_sum = 0;
            let result = (|| -> Result<()> {
                for round in 0..ROUNDS {
                    if store.overlay_keys()? != 2 * BATCH {
                        return Err("sustained overlay was not full".into());
                    }
                    let timer = Instant::now();
                    store.put(trigger_keys[round % 2], &(round as u64).to_le_bytes())?;
                    let writer = timer.elapsed().as_nanos();
                    write_max = write_max.max(writer);
                    write_sum += writer;
                    if store.overlay_keys()? != 1 {
                        return Err("trigger write did not roll over".into());
                    }
                    if round + 1 < ROUNDS {
                        for chunk in filler.chunks(BATCH) {
                            let value = (round as u64).to_le_bytes();
                            let ops: Vec<_> = chunk
                                .iter()
                                .map(|key| BatchOperation::Put { key, value: &value })
                                .collect();
                            store.write_batch(&ops)?;
                        }
                    }
                }
                Ok(())
            })();
            let elapsed = start.elapsed().as_nanos();
            let cpu = cpu_ns() - cpu_start;
            done.store(true, Ordering::Release);
            let (samples, read_max) = reader.join().unwrap();
            (
                result, elapsed, cpu, samples, read_max, write_max, write_sum,
            )
        });
    result?;
    drop(store);
    let slots = store_path.join(".emda-auto-checkpoints-v1");
    for slot in ["slot-0", "slot-1"] {
        assert!(slots.join(slot).join(COMPACTED_CHECKPOINT_FILE).is_file());
    }
    let assert_values = |get: &dyn Fn(&[u8]) -> std::io::Result<Option<Vec<u8>>>| -> Result<()> {
        assert_eq!(get(&target_key)?.as_deref(), Some(b"updated!".as_slice()));
        for (index, key) in trigger_keys.iter().enumerate() {
            assert_eq!(
                get(*key)?.unwrap(),
                ((ROUNDS - 2 + index) as u64).to_le_bytes()
            );
        }
        for key in &filler {
            assert_eq!(get(key)?.unwrap(), ((ROUNDS - 2) as u64).to_le_bytes());
        }
        Ok(())
    };
    let reopened = CheckpointStore::open_managed(store_path)?;
    assert_eq!(reopened.overlay_keys()?, 1);
    assert_values(&|key| reopened.get(key))?;
    drop(reopened);
    let ordinary = Store::open(store_path)?;
    assert_values(&|key| ordinary.get(key))?;
    println!(
        "elapsed_ns={elapsed} cpu_ns={cpu} reader_samples={samples} max_reader_ns={read_max}          max_writer_ns={write_max} mean_writer_ns={} rollovers={ROUNDS}",
        write_sum / ROUNDS as u128
    );
    Ok(())
}

fn main() -> Result<()> {
    let args = std::env::args().collect::<Vec<_>>();
    match args.as_slice() {
        [_, phase, root, keys, width] if phase == "seed" => {
            seed(Path::new(root), keys.parse()?, width.parse()?)?
        }
        [_, phase, root, store, width, mode] if phase == "run" => {
            if mode == "sustained" {
                run_sustained(Path::new(store), width.parse()?)?;
            } else {
                run(Path::new(root), Path::new(store), width.parse()?, mode)?;
            }
        }
        _ => {
            return Err(
                "usage: automatic_rollover_probe seed ROOT KEYS WIDTH | run ROOT STORE WIDTH MODE"
                    .into(),
            );
        }
    }
    Ok(())
}
