"""Summarize paired trials in milliseconds and confirm the fixture hashes."""
from collections import defaultdict
import json
from pathlib import Path
from statistics import median
import sys


def summarize(directory):
    data = defaultdict(dict)
    for platform in ("macos", "linux"):
        for family in ("manual", "automatic"):
            path = directory / f"{family}-{platform}.jsonl"
            first, *rows, last = map(json.loads, path.read_text().splitlines())
            assert first["before"] == last["after"]
            assert first["keys"] == 131_072 and first["width"] == 32
            modes = {"manual"} if family == "manual" else {"on-demand", "worker", "sustained"}
            assert len(rows) == 14 * len(modes)
            assert {row.get("mode", "manual") for row in rows} == modes
            for row in rows:
                mode = row.get("mode", "manual")
                if mode == "sustained":
                    assert row["rollovers"] == 12
                by_pair = data[platform, mode].setdefault(row["variant"], {})
                assert row["pair"] not in by_pair
                by_pair[row["pair"]] = row

    results = []
    for (platform, mode), variants in data.items():
        assert set(variants) == {"baseline", "candidate"}
        baseline, candidate = (variants[variant] for variant in ("baseline", "candidate"))
        assert set(baseline) == set(candidate) == set(range(7))
        if mode != "sustained":
            assert len({row["output_bytes"] for row in (*baseline.values(), *candidate.values())}) == 1
        metric = "mean_writer_ns" if mode == "sustained" else "elapsed_ns"

        def median_ms(rows, key):
            return median(row[key] for row in rows.values()) / 1_000_000

        def extrema_ms(rows, key):
            values = [row[key] / 1_000_000 for row in rows.values()]
            return [min(values), max(values)]

        results.append({
            "platform": platform,
            "mode": mode,
            "reader_worst_median_ms": [median_ms(rows, "max_reader_ns") for rows in (baseline, candidate)],
            "reader_worst_range_ms": [extrema_ms(rows, "max_reader_ns") for rows in (baseline, candidate)],
            "elapsed_median_ms": [median_ms(rows, metric) for rows in (baseline, candidate)],
            "writer_max_median_ms": [median_ms(rows, "max_writer_ns") for rows in (baseline, candidate)]
                                   if mode == "sustained" else None,
            "reader_improved_pairs": sum(candidate[i]["max_reader_ns"] < baseline[i]["max_reader_ns"]
                                         for i in range(7)),
        })
    return results


if __name__ == "__main__":
    print(json.dumps(summarize(Path(sys.argv[1])), indent=2))
