"""Pair checkpoint publication trials on identical disposable fixtures."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile


def digest(path):
    value = hashlib.sha256()
    with path.open("rb") as file:
        for block in iter(lambda: file.read(64 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def source_identity(root):
    log = root / "records.log"
    with log.open("rb") as source:
        magic = source.read(8)
    identity = {
        "magic": magic.decode(),
        "log": digest(log),
        "witness": digest(root / "commit.state"),
        "log_bytes": log.stat().st_size,
    }
    if magic == b"EMDALOG3":
        identity["metadata_witness"] = os.getxattr(log, "user.db.commit.v3").hex()
    return identity


baseline, candidate, parent = map(Path, sys.argv[1:])
keys = 131_072
for width in (32,):
    with tempfile.TemporaryDirectory(dir=parent) as tmp:
        root = Path(tmp)
        subprocess.run([baseline, "seed", root, str(keys), str(width)], check=True)
        before = source_identity(root / "store")
        print(json.dumps({"keys": keys, "width": width, "before": before}), flush=True)
        for pair in range(7):
            variants = [("baseline", baseline), ("candidate", candidate)]
            if pair % 2:
                variants.reverse()
            for variant, binary in variants:
                out = subprocess.check_output([binary, "run", root, str(width)], text=True)
                values = dict(field.split("=", 1) for field in out.split())
                print(json.dumps({"pair": pair, "variant": variant, "keys": keys, "width": width,
                                  **{name: int(value) for name, value in values.items()}}),
                      flush=True)
        after = source_identity(root / "store")
        assert after == before
        print(json.dumps({"keys": keys, "width": width, "after": after}), flush=True)
