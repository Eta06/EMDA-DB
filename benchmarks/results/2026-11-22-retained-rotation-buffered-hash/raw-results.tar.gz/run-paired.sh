set -eu
run=$1
pristine=$2
scratch=$3
export EMDA_BENCH_SUFFIX_WORK=60000000
mkdir "$run/measurements"
for round in 1 2 3 4 5 6; do
  if [ $((round % 2)) -eq 1 ]; then order="baseline candidate"; else order="candidate baseline"; fi
  for mode in $order; do
    work=$(mktemp -d "$scratch/replica.XXXXXX")
    cp -Rp "$pristine/retained" "$pristine/authority" "$work/"
    if [ "$(uname -s)" = Darwin ]; then
      /usr/bin/time -lp "$run/$mode" mutate "$work" retained 131072 7 > "$run/measurements/$round-$mode-mutate.log" 2>&1
    else
      /usr/bin/time -f 'peak_rss_kib=%M' "$run/$mode" mutate "$work" retained 131072 7 > "$run/measurements/$round-$mode-mutate.log" 2>&1
    fi
    "$run/$mode" verify "$work" retained 131072 7 > "$run/measurements/$round-$mode-verify.log"
    python3 - "$work" <<'PY'
import shutil
import sys
shutil.rmtree(sys.argv[1])
PY
  done
  printf 'round %s verified\n' "$round"
done
