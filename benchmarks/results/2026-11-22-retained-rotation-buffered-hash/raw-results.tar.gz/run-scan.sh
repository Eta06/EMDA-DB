set -eu
run=$1
fixture=$2
export EMDA_BENCH_SUFFIX_WORK=60000000
mkdir "$run/scan-measurements"
for round in 1 2 3 4 5 6 7 8 9 10 11 12; do
  if [ $((round % 2)) -eq 1 ]; then order="baseline candidate"; else order="candidate baseline"; fi
  for mode in $order; do
    "$run/$mode" verify "$fixture" retained 131072 6 > "$run/scan-measurements/$round-$mode.log"
  done
done
