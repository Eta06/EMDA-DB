import collections
import json
import pathlib
import re
import sys

root = pathlib.Path(sys.argv[1])
revision = sys.argv[2]
runs = ("45390622461", "45390622510", "45390622259", "45390622268", "45390622515")
for run in runs:
    state = json.loads((root / run / "jobs.json").read_text())
    assert state["headSha"] == revision, state
    assert state["status"] == "completed" and state["conclusion"] == "success", state
    assert (root / run / "workflow.log").stat().st_size > 0, run
    print(state["workflowName"], run, state["conclusion"])

for label, directory, count in [
    ("standard benchmark smoke", root / "45390622510" / "ci-benchmark-smoke", 45),
    ("cross-engine smoke", root / "45390622515", 5),
    ("four-writer recovery memory workload", root / "45390622510" / "writable-recovery-memory-ceiling", 1),
]:
    attempts = list(directory.rglob("attempt.json"))
    assert len(attempts) == count, (label, len(attempts))
    dispositions = collections.Counter()
    for path in attempts:
        attempt = json.loads(path.read_text())
        assert attempt["revision"] == revision and attempt["tracked_changes"] == "", path
        assert attempt["status"] == "exited", path
        assert (path.parent / attempt["output"]).is_file(), path
        dispositions[attempt["returncode"], attempt["wrapper_exit_code"]] += 1
    assert dispositions == {(0, 0): count}, dispositions
    print(label, dispositions)

measurements, = root.rglob("measurements.jsonl")
phases = [json.loads(line) for line in measurements.read_text().splitlines()]
capped = [phase for phase in phases if phase["address_space_limit_bytes"] is not None]
assert len(phases) == 51 and len(capped) == 24, (len(phases), len(capped))
assert all(phase["address_space_limit_bytes"] == 48 * 1024**2 for phase in capped)
print("recovery phases", len(phases), "capped at 48 MiB", len(capped))

linux_log = (root / "45390622510" / "workflow.log").read_text()
for test in ("automatic_maintenance_scan_limit_is_shared_and_resets_per_mutation",
             "automatic_maintenance_scan_limit_charges_cleanup_before_rotation",
             "automatic_maintenance_scan_limit_rejects_before_retirement_fence_and_append"):
    lines = [line for line in linux_log.splitlines() if test + " ... ok" in line]
    assert len(lines) >= 2, (test, lines)
    print(test, len(lines), "passes")

macos_log = (root / "45390622461" / "workflow.log").read_text()
for test in ("automatic_maintenance_scan_limit_is_shared_and_resets_per_mutation",
             "automatic_maintenance_scan_limit_charges_cleanup_before_rotation",
             "automatic_maintenance_scan_limit_rejects_before_retirement_fence_and_append"):
    assert sum(test + " ... ok" in line for line in macos_log.splitlines()) == 2, test
native_log = (root / "native-macos" / "macos-full-final.log").read_text()
counts = [int(count) for count in re.findall(r"test result: ok\. (\d+) passed", native_log)]
assert "test result: FAILED" not in native_log
assert sum(counts) == 1335 and sum(count > 0 for count in counts) == 112, counts
print("native macOS", sum(counts), "passing tests")
