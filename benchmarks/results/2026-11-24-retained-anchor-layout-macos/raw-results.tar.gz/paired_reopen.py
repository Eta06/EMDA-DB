from pathlib import Path
import json
import re
import subprocess
import sys

root = Path(sys.argv[1]).resolve()
output = root / "paired-attempt"
fixture = root / "baseline-attempt/phases/fixture"
for cycle in range(8):
    order = ("baseline", "candidate", "candidate", "baseline")
    if cycle % 2:
        order = tuple("baseline" if variant == "candidate" else "candidate" for variant in order)
    for position, variant in enumerate(order):
        command = ["/usr/bin/time", "-lp", str(root / variant), "reopen", str(fixture), "retained", "262144", "6"]
        log = f"{cycle:02}-{position}-{variant}.log"
        result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, check=False)
        (output / log).write_bytes(result.stdout)
        values = dict(re.findall(r"(\w+)=(\d+)", result.stdout.decode()))
        rss = re.search(rb"(\d+)\s+maximum resident set size", result.stdout)
        with (output / "measurements.jsonl").open("a") as raw:
            print(json.dumps({"cycle": cycle, "position": position, "variant": variant, "command": command,
                              "log": log, "exit": result.returncode, **{name: int(value) for name, value in values.items()},
                              "peak_rss_bytes": int(rss[1]) if rss else None}), file=raw)
        if result.returncode or "ready_ns" not in values or not rss:
            raise SystemExit(f"reopen unsuccessful, see {log}")
