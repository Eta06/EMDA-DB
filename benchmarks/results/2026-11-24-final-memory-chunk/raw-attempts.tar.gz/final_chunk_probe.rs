use database_engine::{BatchOperation, BoundedFullRebuildLimits, CheckpointStore, Store};
use std::{fs, io, path::Path, time::Instant};

const WRITES: usize = 6_144;

fn key(index: usize) -> [u8; 64] {
    let mut result = [b'x'; 64];
    result[..8].copy_from_slice(&(index as u64).to_be_bytes());
    result
}

fn io_counts() -> io::Result<(u64, u64, u64, u64)> {
    let values = fs::read_to_string("/proc/self/io")?;
    let field = |prefix| {
        values
            .lines()
            .find_map(|line| line.strip_prefix(prefix))
            .and_then(|value| value.trim().parse().ok())
            .ok_or_else(|| io::Error::other("missing process I/O counter"))
    };
    Ok((field("rchar:")?, field("syscr:")?, field("wchar:")?, field("syscw:")?))
}

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let args = std::env::args().collect::<Vec<_>>();
    let root = Path::new(&args[1]);
    let mode = &args[2];
    let keys = args[3].parse::<usize>()?;
    assert!(keys == 4096 || keys == WRITES);
    let source = root.join("store");
    if mode == "setup" {
        fs::create_dir(root)?;
        let store = Store::open(&source)?;
        for start in (0..WRITES).step_by(512) {
            let prepared: Vec<_> = (start..start + 512)
                .map(|number| (key(number % keys), (number as u64).to_be_bytes()))
                .collect();
            let batch: Vec<_> = prepared
                .iter()
                .map(|(key, value)| BatchOperation::Put { key, value })
                .collect();
            store.write_batch(&batch)?;
        }
        return Ok(());
    }
    let destination = root.join("checkpoint");
    let log = source.join("records.log");
    let limits = BoundedFullRebuildLimits {
        max_log_bytes: fs::metadata(&log)?.len(),
        max_operations: WRITES as u64,
        max_live_keys: keys,
        max_live_key_bytes: (keys * 64) as u64,
        max_chunk_keys: 1024,
        max_chunk_key_bytes: 64 * 1024,
        max_spill_bytes: 64 * 1024 * 1024,
        max_merge_fan_in: 4,
    };
    let before = io_counts()?;
    let start = Instant::now();
    CheckpointStore::rebuild_managed_selection_full_bounded(&source, &destination, limits)?;
    let micros = start.elapsed().as_micros();
    let after = io_counts()?;
    let view = CheckpointStore::open_managed(&source)?;
    let mut next = 0;
    let mut after_key = None;
    loop {
        let page = view.scan(after_key.as_deref(), None, 1024)?;
        if page.is_empty() {
            break;
        }
        for (actual, value) in page {
            assert_eq!(actual, key(next));
            let last_write = next + ((WRITES - 1 - next) / keys) * keys;
            assert_eq!(value, (last_write as u64).to_be_bytes());
            after_key = Some(actual);
            next += 1;
        }
    }
    assert_eq!(next, keys);
    println!(
        "{mode} keys={keys} rchar={} syscr={} wchar={} syscw={} elapsed_us={micros}",
        after.0 - before.0,
        after.1 - before.1,
        after.2 - before.2,
        after.3 - before.3
    );
    Ok(())
}
