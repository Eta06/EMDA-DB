use database_engine::{
    CheckpointStore, CollectionSchema, DocumentDatabase, DocumentFilter, DocumentQuery,
    DocumentQueryAccess, IndexDefinition, Store,
};
use serde_json::json;
use std::{env, fs, path::Path};

fn id(i: usize) -> String {
    format!("doc-{i:03}")
}

fn main() -> std::io::Result<()> {
    let args = env::args().collect::<Vec<_>>();
    let root = Path::new(&args[2]);
    let source = root.join("store");
    let checkpoint = root.join("checkpoint");
    if args[1] == "setup" {
        fs::create_dir_all(root)?;
        let store = Store::open(&source)?;
        let db = DocumentDatabase::new(&store);
        db.create_collection("docs", CollectionSchema::default())?;
        db.create_index("docs", IndexDefinition {
            name: "group".into(),
            fields: vec![vec!["group".into()]],
            unique: false,
            partial: None,
        })?;
        db.transaction(|txn| {
            for i in 0..96 {
                txn.insert("docs", &id(i), &json!({"group": i / 4, "ordinal": i}))?;
            }
            Ok(())
        })?;
        store.put(b"y-a", b"one")?;
        store.put(b"y-b", b"two")?;
        fs::write(root.join("digest"), store.checkpoint_to(&checkpoint)?)?;
        return Ok(());
    }

    let digest = fs::read(root.join("digest"))?.try_into().unwrap();
    let store = CheckpointStore::open(&source, &checkpoint, &digest)?;
    let db = DocumentDatabase::with_checkpoint_store(&store);
    eprintln!("TX-SCAN-BEGIN");
    match args[1].as_str() {
        "raw" | "repeat" => {
            store.transaction_with_read_set(|tx| {
                let expected = vec![(b"y-a".to_vec(), b"one".to_vec())];
                assert_eq!(tx.scan(Some(b"x"), Some(b"z"), 1)?, expected);
                if args[1] == "repeat" {
                    assert_eq!(tx.scan(Some(b"x"), Some(b"z"), 1)?, expected);
                }
                Ok(())
            })?;
        }
        "document" => {
            let query = DocumentQuery {
                filter: DocumentFilter::Equal {path: vec!["group".into()], value: json!(5)},
                limit: 4,
                ..Default::default()
            };
            let planned = db.transaction_with_read_set(|tx| tx.query_planned("docs", &query))?;
            assert_eq!(planned.access, DocumentQueryAccess::EqualityIndex {index: "group".into()});
            assert_eq!(planned.result.documents.len(), 4);
            for (i, item) in (20..24).zip(planned.result.documents) {
                assert_eq!(item.id, id(i));
                assert_eq!(item.document, json!({"group": 5, "ordinal": i}));
            }
        }
        other => panic!("invalid operation {other}"),
    }
    eprintln!("TX-SCAN-END");
    Ok(())
}
