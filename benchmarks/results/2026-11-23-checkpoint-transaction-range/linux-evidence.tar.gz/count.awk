/TX-SCAN-BEGIN/ {active=1; next}
/TX-SCAN-END/ {active=0; complete=1}
active && /\/checkpoint>/ && $NF ~ /^[0-9]+$/ {calls++; bytes+=$NF}
END {
    if (!complete || !calls) exit 1
    print label,calls,bytes
}
