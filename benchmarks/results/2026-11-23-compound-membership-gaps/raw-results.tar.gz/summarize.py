"""Summarize the median of nine process-level query medians."""
import json
import statistics
import sys

print("| Platform | Case | EMDA before µs | EMDA after µs | SQLite µs | Candidates before → after |")
print("| --- | --- | ---: | ---: | ---: | ---: |")
assert len(sys.argv) == 3
for label, file in zip(("macOS ARM64", "Linux ARM64"), sys.argv[1:]):
    with open(file) as samples:
        rows = [json.loads(line) for line in samples]
    assert len(rows) == 54
    for name in ("short-gapped", "wide-gapped", "range-only"):
        def group(variant):
            selected = [row for row in rows if row["case"] == name and row["variant"] == variant]
            assert {row["pair"] for row in selected} == set(range(9))
            return selected

        def median(group, engine):
            per_process = [statistics.median(row[engine + "_ns"]) for row in group]
            return statistics.median(per_process) / 1000

        before = group("candidate")
        after = group("optimized")
        left = median(before, "emda")
        right = median(after, "emda")
        sqlite = median(after, "sqlite")
        candidates = f'{before[0]["candidates"]} → {after[0]["candidates"]}'
        print(f"| {label} | {name} | {left:.2f} | {right:.2f} | {sqlite:.2f} | {candidates} |")
