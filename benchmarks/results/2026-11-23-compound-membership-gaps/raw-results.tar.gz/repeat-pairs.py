"""Use the same synchronized, reopened fixture for both revisions."""
import json
from pathlib import Path
import subprocess
import sys
import tempfile

expanded, grouped, parent = map(Path, sys.argv[1:])
with tempfile.TemporaryDirectory(dir=parent) as fixture:
    subprocess.run([expanded, "seed", fixture], check=True, timeout=180)
    for pair in range(9):
        variants = [("candidate", expanded), ("optimized", grouped)]
        if pair % 2:
            variants.reverse()
        for variant, binary in variants:
            out = subprocess.check_output(
                [binary, "run", fixture, variant, str(pair)], text=True, timeout=60
            )
            rows = [json.loads(line) for line in out.splitlines()]
            assert {row["case"] for row in rows} == {"short-gapped", "wide-gapped", "range-only"}
            for row in rows:
                assert row["variant"] == variant
                assert len(row["sqlite_ns"]) == len(row["emda_ns"]) == 100
                print(json.dumps({"pair": pair, **row}), flush=True)
