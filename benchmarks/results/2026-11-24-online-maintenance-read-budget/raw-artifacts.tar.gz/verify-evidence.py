import collections
import json
import pathlib
import sys

root = pathlib.Path(sys.argv[1])
revision = sys.argv[2]
runs = ("45372841380", "45372841309", "45372841466", "45372841347", "45372841286")
for run in runs:
    state = json.loads((root / run / "jobs.json").read_text())
    assert state["headSha"] == revision, state
    assert state["status"] == "completed" and state["conclusion"] == "success", state
    assert (root / run / "workflow.log").stat().st_size > 0, run
    print(state["workflowName"], run, state["conclusion"])

for label, directory, count in [
    ("standard benchmark smoke", root / "45372841309" / "ci-benchmark-smoke", 45),
    ("cross-engine smoke", root / "45372841286", 5),
    ("four-writer recovery memory workload", root / "45372841309" / "writable-recovery-memory-ceiling", 1),
]:
    attempts = list(directory.rglob("attempt.json"))
    assert len(attempts) == count, (label, len(attempts))
    dispositions = collections.Counter()
    for path in attempts:
        attempt = json.loads(path.read_text())
        assert attempt["revision"] == revision and attempt["tracked_changes"] == "", path
        assert attempt["status"] == "exited", path
        assert (path.parent / attempt["output"]).is_file(), path
        dispositions[attempt["returncode"], attempt["wrapper_exit_code"]] += 1
    assert dispositions == {(0, 0): count}, dispositions
    print(label, dispositions)

measurements, = root.rglob("measurements.jsonl")
phases = [json.loads(line) for line in measurements.read_text().splitlines()]
capped = [phase for phase in phases if phase["address_space_limit_bytes"] is not None]
assert len(phases) == 51 and len(capped) == 24, (len(phases), len(capped))
assert all(phase["address_space_limit_bytes"] == 48 * 1024**2 for phase in capped)
print("recovery phases", len(phases), "capped at 48 MiB", len(capped))

linux_log = (root / "45372841309" / "workflow.log").read_text()
for test in ("source_read_limit_counts_both_replays_value_copies_and_confirmation",
             "scoped_cleanup_keeps_retired_copy_when_verification_limits_are_too_small"):
    lines = [line for line in linux_log.splitlines() if test + " ... ok" in line]
    assert len(lines) >= 2, (test, lines)
    print(test, len(lines), "passes")
