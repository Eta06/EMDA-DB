"""Validate sample coverage and produce the table of per-round medians."""
from collections import defaultdict
import json
from pathlib import Path
from statistics import median
import sys


def summary(rows, kind):
    assert all(len(row[kind]) == 100 and min(row[kind]) > 0 for row in rows)
    p50s = [median(row[kind]) / 1000 for row in rows]
    return f"{median(p50s):.2f} ({min(p50s):.2f}–{max(p50s):.2f})"


assert len(sys.argv) == 3
for platform, filename in zip(("macOS", "Linux"), sys.argv[1:]):
    groups = defaultdict(list)
    for line in Path(filename).read_text().splitlines():
        row = json.loads(line)
        assert row["sqlite_version"] == "3.49.1"
        groups[row["case"], row["variant"]].append(row)
    assert len(groups) == 6
    for case, matches in (("sparse", 8), ("dense", 192), ("range-only", 192)):
        before = groups[case, "baseline"]
        after = groups[case, "candidate"]
        for rows in (before, after):
            assert sorted(row["pair"] for row in rows) == list(range(9))
            assert {row["matches"] for row in rows} == {matches}
            assert {row["candidates"] for row in rows} == {matches}
            assert all(any("SEARCH docs USING INDEX docs_tenant_score" in step for step in row["sqlite_plan"]) for row in rows)
        if case == "dense":
            assert all("probes: 192" in row["emda_access"] for row in before)
            assert all("IntegerMembershipIndex" in row["emda_access"] and "probes: 64" in row["emda_access"] for row in after)
        print(
            f"| {platform} | {case} | {matches} | "
            f"{summary(before, 'emda_ns')} | {summary(after, 'emda_ns')} | "
            f"{summary(after, 'sqlite_ns')} |"
        )
