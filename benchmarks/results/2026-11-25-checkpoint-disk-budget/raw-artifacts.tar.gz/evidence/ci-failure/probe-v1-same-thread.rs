//! Temporary diagnostic probe; not committed. Shows that dropping a flocked
//! descriptor does not release the lock while a forked child still holds an
//! inherited duplicate, and that an explicit unlock does.
use std::fs::File;
use std::os::unix::process::CommandExt;
use std::process::Command;
use std::time::Duration;

fn spawn_slow_child() -> std::process::Child {
    let mut command = Command::new("true");
    // Runs in the child after fork and before exec, while it holds
    // duplicates of every parent descriptor, including CLOEXEC ones.
    unsafe {
        command.pre_exec(|| {
            std::thread::sleep(Duration::from_millis(500));
            Ok(())
        });
    }
    command.spawn().unwrap()
}

#[test]
fn dropped_lock_survives_in_a_forked_child_until_exec() {
    let dir = tempfile::tempdir().unwrap();
    let held = File::open(dir.path()).unwrap();
    fs2::FileExt::try_lock_exclusive(&held).unwrap();
    let mut child = spawn_slow_child();
    drop(held);
    let other = File::open(dir.path()).unwrap();
    let blocked = fs2::FileExt::try_lock_shared(&other);
    println!("after drop while child pre-exec: {blocked:?}");
    assert_eq!(blocked.unwrap_err().raw_os_error(), Some(libc_eagain()));
    child.wait().unwrap();
    fs2::FileExt::try_lock_shared(&other).unwrap();
    println!("after child exec: acquired");
}

#[test]
fn explicit_unlock_releases_despite_the_forked_child() {
    let dir = tempfile::tempdir().unwrap();
    let held = File::open(dir.path()).unwrap();
    fs2::FileExt::try_lock_exclusive(&held).unwrap();
    let mut child = spawn_slow_child();
    fs2::FileExt::unlock(&held).unwrap();
    drop(held);
    let other = File::open(dir.path()).unwrap();
    fs2::FileExt::try_lock_shared(&other).unwrap();
    println!("explicit unlock: acquired while child pre-exec");
    child.wait().unwrap();
}

fn libc_eagain() -> i32 {
    if cfg!(target_os = "linux") { 11 } else { 35 }
}
