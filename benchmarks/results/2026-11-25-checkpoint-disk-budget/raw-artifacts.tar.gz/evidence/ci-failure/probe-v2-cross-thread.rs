//! Temporary diagnostic probe; not committed. Another thread forks a child
//! (as a parallel test spawning `mkfifo` does) while this thread holds a
//! directory flock. Dropping the descriptor during the child's fork-to-exec
//! window does not release the lock; an explicit unlock does.
use std::fs::File;
use std::os::unix::process::CommandExt;
use std::process::Command;
use std::thread;
use std::time::Duration;

fn spawn_slow_child_in_another_thread() -> thread::JoinHandle<()> {
    let handle = thread::spawn(|| {
        let mut command = Command::new("true");
        // Runs in the child after fork and before exec, while it holds
        // duplicates of every parent descriptor, including CLOEXEC ones.
        unsafe {
            command.pre_exec(|| {
                std::thread::sleep(Duration::from_millis(500));
                Ok(())
            });
        }
        command.spawn().unwrap().wait().unwrap();
    });
    // Let the other thread fork before this thread drops its descriptor.
    thread::sleep(Duration::from_millis(150));
    handle
}

fn eagain() -> i32 {
    if cfg!(target_os = "linux") { 11 } else { 35 }
}

#[test]
fn dropped_lock_survives_in_a_forked_child_until_exec() {
    let dir = tempfile::tempdir().unwrap();
    let held = File::open(dir.path()).unwrap();
    fs2::FileExt::try_lock_exclusive(&held).unwrap();
    let child = spawn_slow_child_in_another_thread();
    drop(held);
    let other = File::open(dir.path()).unwrap();
    let blocked = fs2::FileExt::try_lock_shared(&other);
    println!("drop during another thread's fork-to-exec window: {blocked:?}");
    assert_eq!(blocked.unwrap_err().raw_os_error(), Some(eagain()));
    child.join().unwrap();
    fs2::FileExt::try_lock_shared(&other).unwrap();
    println!("after the child execs: acquired");
}

#[test]
fn explicit_unlock_releases_despite_the_forked_child() {
    let dir = tempfile::tempdir().unwrap();
    let held = File::open(dir.path()).unwrap();
    fs2::FileExt::try_lock_exclusive(&held).unwrap();
    let child = spawn_slow_child_in_another_thread();
    fs2::FileExt::unlock(&held).unwrap();
    drop(held);
    let other = File::open(dir.path()).unwrap();
    fs2::FileExt::try_lock_shared(&other).unwrap();
    println!("explicit unlock during the same window: acquired");
    child.join().unwrap();
}
