import collections
import json
import pathlib
import sys

root = pathlib.Path(sys.argv[1])
revision = sys.argv[2]
runs = ("45385831216", "45385831058", "45385830967", "45385831050", "45385830952")
for run in runs:
    state = json.loads((root / run / "jobs.json").read_text())
    assert state["headSha"] == revision, state
    assert state["status"] == "completed" and state["conclusion"] == "success", state
    assert (root / run / "workflow.log").stat().st_size > 0, run
    print(state["workflowName"], run, state["conclusion"])

for label, directory, count in [
    ("standard benchmark smoke", root / "45385831058" / "ci-benchmark-smoke", 45),
    ("cross-engine smoke", root / "45385830952", 5),
    ("four-writer recovery memory workload", root / "45385831058" / "writable-recovery-memory-ceiling", 1),
]:
    attempts = list(directory.rglob("attempt.json"))
    assert len(attempts) == count, (label, len(attempts))
    dispositions = collections.Counter()
    for path in attempts:
        attempt = json.loads(path.read_text())
        assert attempt["revision"] == revision and attempt["tracked_changes"] == "", path
        assert attempt["status"] == "exited", path
        assert (path.parent / attempt["output"]).is_file(), path
        dispositions[attempt["returncode"], attempt["wrapper_exit_code"]] += 1
    assert dispositions == {(0, 0): count}, dispositions
    print(label, dispositions)

measurements, = root.rglob("measurements.jsonl")
phases = [json.loads(line) for line in measurements.read_text().splitlines()]
capped = [phase for phase in phases if phase["address_space_limit_bytes"] is not None]
assert len(phases) == 51 and len(capped) == 24, (len(phases), len(capped))
assert all(phase["address_space_limit_bytes"] == 48 * 1024**2 for phase in capped)
print("recovery phases", len(phases), "capped at 48 MiB", len(capped))

linux_log = (root / "45385831058" / "workflow.log").read_text()
for test in ("reclamation_budget_counts_resumed_cleanup_and_new_retirement",
             "reclamation_rejects_unavailable_inactive_slot_before_advancing_authority"):
    lines = [line for line in linux_log.splitlines() if test + " ... ok" in line]
    assert len(lines) >= 2, (test, lines)
    print(test, len(lines), "passes")

artifact, = (root / "45385831050").rglob("authority-replacement-faults.jsonl")
traces = [case for line in artifact.read_text().splitlines()
          if (case := json.loads(line)).get("point") == "reclamation scan limit"]
assert len(traces) == 2
for case, accepted in zip(traces, (False, True)):
    base, suffix = case["base_bytes"], case["suffix_bytes"]
    assert suffix > 0
    assert case["cap"] == base + suffix - int(not accepted)
    assert case["outcome"]["status"] == ("success" if accepted else "error")
    assert case["base_pread"] == 144 + (base if accepted else 0)
    assert case["suffix_pread"] == suffix * (2 if accepted else 1)
    assert case["trace"]
    if accepted:
        assert case["outcome"]["removed"] is True
    else:
        assert case["outcome"]["fence"] == "not_attempted"
        assert case["outcome"]["cleanup"] == "not_started"
    print("retained reclamation cap", case["cap"], case["outcome"], "base", base, "suffix", suffix)
