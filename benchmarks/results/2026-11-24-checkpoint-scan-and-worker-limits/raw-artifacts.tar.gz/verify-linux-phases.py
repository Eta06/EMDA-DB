import json
import sys
from pathlib import Path

phases = [json.loads(line) for line in Path(sys.argv[1]).read_text().splitlines()]
keys, operations, limit = 1_048_576, 32_768, 48 * 1024**2
bounded = {"checkpoint", "retained"}
backends = bounded | {"ordinary", "sqlite"}
expected = {
    (backend, epoch, phase)
    for backend in backends
    for epoch in range(1, 5)
    for phase in ("mutate", "reopen", "verify")
} | {
    ("all", 0, "setup"), ("checkpoint", 0, "checkpoint-setup"),
    ("retained", 0, "bind-archive"), ("retained", 0, "cutover"),
    ("retained", 4, "authorized-lifecycle"),
}
observed = {(row["backend"], row["epoch"], row["phase"]) for row in phases}
if len(phases) != len(expected) or observed != expected:
    raise SystemExit("Missing, extra or duplicate recovery workload phase")
for row in phases:
    backend, epoch, phase = row["backend"], row["epoch"], row["phase"]
    expected_limit = limit if backend in bounded and epoch else None
    if (row["keys"] != keys or row["exit"] != 0
            or row["address_space_limit_bytes"] != expected_limit
            or row["peak_rss_bytes"] <= 0
            or (expected_limit is not None and row["peak_rss_bytes"] > expected_limit)):
        raise SystemExit(f"Invalid recovery scope or memory coverage: {row}")
    if expected_limit is not None and (
        row.get("rlimit_as_soft_bytes"), row.get("rlimit_as_hard_bytes")
    ) != (expected_limit, expected_limit):
        raise SystemExit(f"Incorrect kernel address-space limits: {row}")
    if phase == "mutate" and (row["writers"], row["operations"]) != (4, operations):
        raise SystemExit(f"Wrong write workload: {row}")
    # The epoch deletes IDs in [0, operations) congruent to -epoch modulo 11.
    live = keys - ((operations - 1 + epoch) // 11 - (epoch - 1) // 11)
    if phase == "verify" and row["verified_entries"] != live:
        raise SystemExit(f"Incomplete ordered verification: {row}")
    if phase == "authorized-lifecycle":
        if row["restored_verified_entries"] != live or row["source_verified_entries"] != live:
            raise SystemExit("Expected complete restored and source verification under the ceiling")
        recovery_scan = 140 * 1024**2  # 128 MiB base + 12 MiB suffix
        # Retirement verifies both retained copies, the log and both 36-byte witnesses.
        archive_scan = 2 * recovery_scan + row["retired_log_bytes"] + 72
        if (row["lifecycle_recovery_scan_limit_bytes"] != recovery_scan
                or row["backup_restore_scan_limit_bytes"] != 2 * recovery_scan
                or row["archive_retirement_scan_limit_bytes"] != archive_scan):
            raise SystemExit("Expected logical copy, registration and archive scan ceilings")
if not any(row["backend"] == "retained" and row["phase"] == "mutate"
           and row.get("rotations", 0) > 0 for row in phases):
    raise SystemExit("Expected a retained rotation under the ceiling")
if not any(row["backend"] == "checkpoint" and row["phase"] == "mutate"
           and row.get("checkpoint_advanced", 0) > 0 for row in phases):
    raise SystemExit("Expected a checkpoint rollover under the ceiling")
