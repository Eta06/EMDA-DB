import json
from pathlib import Path
import re
import subprocess
import sys

root = Path(sys.argv[1])
first = "4e06804214b83a3fe336eba5aa34f9a3fcfaf5ea"
second = "79e939e4a40cca4929f952812ac81678e15982dd"
for run, revision, conclusion, cases in (
    ("45401676743", first, "success", 0),
    ("45401676776", first, "success", 5),
    ("45401676868", first, "success", 0),
    ("45401676890", first, "failure", 1),
    ("45401676928", first, "cancelled", 0),
    ("45402264753", second, "failure", 1),
    ("45402264808", second, "success", 0),
    ("45402264879", second, "cancelled", 0),
):
    directory = root / run
    workflow = json.loads((directory / "jobs.json").read_text())
    assert workflow["headSha"] == revision and workflow["conclusion"] == conclusion, workflow
    assert (directory / "workflow.log").stat().st_size > 0, run
    attempts = list(directory.rglob("attempt.json"))
    assert len(attempts) == cases, (run, len(attempts))
    for path in attempts:
        result = json.loads(path.read_text())
        assert result["revision"] == revision and not result["tracked_changes"], path
        assert result["status"] == "exited", path
        assert result["returncode"] == result["wrapper_exit_code"] == 0, path
        assert (path.parent / result["output"]).is_file(), path
    if conclusion == "failure":
        jobs = {job["name"]: job for job in workflow["jobs"]}
        assert jobs["Rust 1.85.0 / Linux"]["conclusion"] == "success", run
        assert jobs["Writable recovery / Linux memory ceiling"]["conclusion"] == "success", run
        stable = jobs["Rust stable / Linux"]
        assert [s["name"] for s in stable["steps"] if s["conclusion"] == "failure"] == ["Lint"], run
        data, = directory.rglob("measurements.jsonl")
        subprocess.run([sys.executable, str(root / "verify-linux-phases.py"), str(data)], check=True)
    print(run, workflow["workflowName"], conclusion, cases, "recorded benchmark attempts")

native = (root / "native" / "macos-initial-full.log").read_text()
counts = [int(count) for count in re.findall(r"test result: ok\. (\d+) passed", native)]
assert "test result: FAILED" not in native and sum(counts) == 1343
print("native macOS at", first[:8], sum(counts), "passing tests")
