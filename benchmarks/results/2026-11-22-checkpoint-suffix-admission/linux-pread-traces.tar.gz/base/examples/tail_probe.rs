use database_engine::{CheckpointStore, CheckpointStoreLimits, RecoveredCheckpointView, RecoveredViewLimits, Store};
use std::{fs, io, path::Path};
fn main() -> Result<(), Box<dyn std::error::Error>> {
    let args: Vec<_> = std::env::args().collect();
    let root = Path::new(&args[2]);
    let path = root.join("store");
    let checkpoint = root.join("checkpoint");
    if args[1] == "prepare" {
        let store = Store::open(&path)?;
        store.put(b"a", &vec![42; 8 * 1024 * 1024])?;
        store.put(b"a", b"base")?;
        fs::write(root.join("digest"), store.checkpoint_to(&checkpoint)?)?;
        store.put(b"a", b"tail")?;
    } else {
        let digest = fs::read(root.join("digest"))?.try_into().unwrap();
        let rejected = if args[1] == "read-only" {
            RecoveredCheckpointView::open_with_options(&path, &checkpoint, &digest,
                RecoveredViewLimits { max_tail_bytes: 0, ..Default::default() }).err()
        } else {
            assert_eq!(args[1], "write");
            CheckpointStore::open_with_options(&path, &checkpoint, &digest,
                CheckpointStoreLimits { max_tail_bytes: 0, ..Default::default() }).err()
        }.expect("oversized tail admitted");
        assert_eq!(rejected.kind(), io::ErrorKind::InvalidInput);
        assert!(rejected.to_string().contains("suffix byte limit exceeded"));
    }
    Ok(())
}
