set -eu
run=$1
fixture=$2
mkdir "$run/samples"
for backend in ordinary checkpoint; do
  for round in 1 2 3 4 5 6 7 8; do
    if [ "$((round % 2))" -eq 1 ]; then
      order="baseline candidate"
    else
      order="candidate baseline"
    fi
    for mode in $order; do
      /usr/bin/time -lp "$run/$mode" "$backend" "$fixture" > "$run/samples/$backend-$round-$mode.log" 2>&1
      grep -q 'documents=192 returned=5' "$run/samples/$backend-$round-$mode.log"
    done
  done
done
