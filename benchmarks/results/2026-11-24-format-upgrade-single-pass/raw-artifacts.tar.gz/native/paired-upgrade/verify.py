from pathlib import Path
import hashlib
import json
import re
import statistics

root = Path(__file__).resolve().parent
fixture = json.loads((root / "fixture.json").read_text())
checks = [json.loads(line) for line in (root / "outputs.jsonl").read_text().splitlines()]
assert fixture["log_bytes"] == 134_219_868
assert len(checks) == 12
source_digest = hashlib.sha256((root / "upgrade_probe.rs").read_bytes()).hexdigest()
cases = []
for pair in range(1, 7):
    order = ("before", "after") if pair % 2 else ("after", "before")
    cases.extend(f"{pair:02d}-{variant}" for variant in order)
assert [row["case"] for row in checks] == cases
elapsed = {"before": [], "after": []}
rss = {"before": [], "after": []}
for row in checks:
    case, variant = row["case"], row["variant"]
    assert case.endswith(variant)
    assert row["bytes"] == fixture["log_bytes"] and row["records"] == fixture["records"]
    assert row["revision"] == (root / f"{variant}.revision").read_text().strip()
    hashes = (root / f"{variant}-hashes.txt").read_text().splitlines()
    assert row["binary_sha256"] == hashes[0].split()[0]
    assert source_digest == hashes[1].split()[0]
    meta = json.loads((root / case / "attempt.json").read_text())
    assert meta["case"] == f"format-upgrade-{case}"
    assert meta["status"] == "exited" and meta["returncode"] == meta["wrapper_exit_code"] == 0
    command = (root / case / meta["output"]).read_text()
    assert "verified_entries=32" in command
    elapsed[variant].append(int(re.search(r"elapsed_ns=([1-9][0-9]*)", command)[1]) / 1e6)
    rss[variant].append(int(re.search(r"^\s*([1-9][0-9]*)\s+maximum resident set size", command, re.M)[1]))
for variant in ("before", "after"):
    print(variant, "elapsed_ms", elapsed[variant], "median", round(statistics.median(elapsed[variant]), 3))
    print(variant, "peak_rss_bytes", rss[variant], "median", statistics.median(rss[variant]))
print("median elapsed reduction", round((1 - statistics.median(elapsed["after"]) / statistics.median(elapsed["before"])) * 100, 2))
