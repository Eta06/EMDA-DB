use database_engine::Store;
use std::{env, path::Path, time::Instant};

const KEYS: u64 = 32;

fn verify(store: &Store) {
    for key in 0..KEYS {
        assert_eq!(store.get(&key.to_be_bytes()).unwrap().as_deref(), Some(&key.to_le_bytes()[..]));
    }
    assert_eq!(store.scan(None, None, 1024).unwrap().len(), KEYS as usize);
}

fn main() {
    let mut args = env::args().skip(1);
    let phase = args.next().unwrap();
    let path = args.next().unwrap();
    let source = Path::new(&path);
    if phase == "setup" {
        let store = Store::open(source).unwrap();
        let big = vec![42; 4 * 1024 * 1024];
        for key in 0..KEYS {
            store.put(&key.to_be_bytes(), &big).unwrap();
            store.put(&key.to_be_bytes(), &key.to_le_bytes()).unwrap();
        }
        verify(&store);
        return;
    }
    assert_eq!(phase, "upgrade");
    let target = args.next().unwrap();
    let store = Store::open(source).unwrap();
    let start = Instant::now();
    store.upgrade_format(&target).unwrap();
    println!("elapsed_ns={}", start.elapsed().as_nanos());
    verify(&Store::open(target).unwrap());
    println!("verified_entries={KEYS}");
}
