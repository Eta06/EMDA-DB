from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import sys

scratch = Path(sys.argv[1]).resolve()
data = Path(__file__).resolve().parent
source = scratch / "fixture" / "source"

def digest(path, offset=0):
    result = hashlib.sha256()
    with path.open("rb") as file:
        file.seek(offset)
        for chunk in iter(lambda: file.read(1 << 20), b""):
            result.update(chunk)
    return result.hexdigest()

log = source / "records.log"
with log.open("rb") as header:
    assert header.read(8) == b"EMDALOG2"
witness = source / "commit.state"
baseline = {
    "log": digest(log), "records": digest(log, 28), "witness": digest(witness),
    "log_bytes": log.stat().st_size,
}
(data / "fixture.json").write_text(json.dumps(baseline, indent=2) + "\n")
with (data / "outputs.jsonl").open("x") as checks:
    for pair in range(1, 7):
        order = ("before", "after") if pair % 2 else ("after", "before")
        for variant in order:
            case = f"{pair:02d}-{variant}"
            target = scratch / "fixture" / case
            binary = scratch / f"{variant}-upgrade"
            binary_digest = digest(binary)
            assert binary_digest == (data / f"{variant}-hashes.txt").read_text().split()[0]
            subprocess.run([
                sys.executable, "-m", "scripts.benchmarks.record_case",
                "--directory", str(data / case), "--case", f"format-upgrade-{case}",
                "--", "/usr/bin/time", "-l", str(binary), "upgrade", str(source), str(target),
            ], check=True)
            copied = target / "records.log"
            observed = {
                "case": case, "variant": variant, "binary_sha256": binary_digest,
                "revision": (data / f"{variant}.revision").read_text().strip(),
                "records": digest(copied, 28), "bytes": copied.stat().st_size,
            }
            assert observed["records"] == baseline["records"]
            assert observed["bytes"] == baseline["log_bytes"]
            assert digest(log) == baseline["log"] and digest(witness) == baseline["witness"]
            checks.write(json.dumps(observed) + "\n")
            checks.flush()
            shutil.rmtree(target)
