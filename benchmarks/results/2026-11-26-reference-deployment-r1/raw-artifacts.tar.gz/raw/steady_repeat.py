"""Drive the R1 reference deployment: steady-state trials and kill drills.

usage: python3 -I drive.py <binary> <work-dir> <output.json>
"""
import json
import random
import re
import shutil
import signal
import subprocess
import sys
import threading
import time
from pathlib import Path

BIN, WORK, OUT = sys.argv[1], Path(sys.argv[2]), Path(sys.argv[3])
RNG = random.Random(20261126)
TIME_FIELDS = {
    "maximum resident set size": "max_rss_bytes",
    "peak memory footprint": "peak_footprint_bytes",
}


def timed(*args):
    """Run one phase under /usr/bin/time -l and return its JSON and resources."""
    proc = subprocess.run(
        ["/usr/bin/time", "-l", BIN, *args], capture_output=True, text=True
    )
    if proc.returncode != 0:
        raise SystemExit(f"{args} failed: {proc.stderr[-2000:]}")
    record = json.loads(proc.stdout.strip().splitlines()[-1])
    for line in proc.stderr.splitlines():
        match = re.match(r"\s*(\d+)\s+(.+)$", line)
        if match and match.group(2) in TIME_FIELDS:
            record[TIME_FIELDS[match.group(2)]] = int(match.group(1))
        match = re.match(r"\s*([\d.]+) real", line)
        if match:
            record["wall_s"] = float(match.group(1))
    return record


def clone(name):
    target = WORK / name
    if target.exists():
        shutil.rmtree(target)
    # APFS clone: cheap and independent of the fixture.
    subprocess.run(["cp", "-c", "-R", str(WORK / "fixture"), str(target)], check=True)
    return target


def kill_drill(name, mode):
    root = clone(name)
    proc = subprocess.Popen(
        [BIN, "run", str(root), "0", "1000000"],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        bufsize=1,
    )
    acks = []
    events = []
    rotations_done = [0]
    killed = threading.Event()
    operator = {"mode": mode}

    def kill(reason):
        if not killed.is_set():
            killed.set()
            operator["sigkill_at"] = time.time()
            operator["reason"] = reason
            proc.send_signal(signal.SIGKILL)

    def read_events():
        for line in proc.stderr:
            line = line.strip()
            if not line.startswith("EVENT"):
                continue
            _, kind, batch = line.split()
            events.append((kind, int(batch)))
            if kind == "done":
                rotations_done[0] += 1
            # Let one rotation finish first so every drill has a retired slot
            # history, then kill at the chosen boundary of the second.
            if rotations_done[0] < 1:
                continue
            if mode == "prepare" and kind == "prepare":
                delay = RNG.uniform(0.1, 1.2)
                operator["delay_s"] = delay
                threading.Timer(delay, kill, ["during prepare"]).start()
            elif mode == "complete" and kind == "complete":
                kill("at complete event")
            elif mode == "reclaim" and kind == "reclaim":
                kill("at reclaim event")

    reader = threading.Thread(target=read_events)
    reader.start()
    if mode == "random":
        delay = RNG.uniform(3.0, 30.0)
        operator["delay_s"] = delay
        threading.Timer(delay, kill, ["random time"]).start()
    for line in proc.stdout:
        if line.startswith("ACK "):
            acks.append(int(line.split()[1]))
    proc.wait()
    reader.join()
    if not killed.is_set():
        raise SystemExit(f"{name}: writer exited before the kill")
    if acks != list(range(len(acks))):
        raise SystemExit(f"{name}: acknowledgements are not consecutive")
    acked = len(acks)
    last_event = events[-1] if events else None
    opened = timed("open", str(root))
    verified = timed("verify", str(root), str(acked))
    start = acked + (1 if verified["inflight_applied"] else 0)
    # Keep working after recovery: at least one more rotation must finish.
    continued = timed("run", str(root), str(start), "2600")
    reverified = timed("verify", str(root), str(start + 2600))
    shutil.rmtree(root)
    return {
        "name": name,
        "operator": operator,
        "exit_code": proc.returncode,
        "acknowledged_batches": acked,
        "last_event_before_kill": last_event,
        "rotations_completed_before_kill": rotations_done[0],
        "open": opened,
        "verify": verified,
        "continued_run": continued,
        "verify_after_continue": reverified,
    }


def main():
    results = {"steady_repeat": []}
    for trial in range(3, 6):
        root = clone(f"steady{trial}")
        run = timed("run", str(root), "0", "12000")
        opened = timed("open", str(root))
        verified = timed("verify", str(root), "12000")
        shutil.rmtree(root)
        results["steady_repeat"].append({"trial": trial, "run": run, "open": opened, "verify": verified})
        print(f"steady {trial} done", flush=True)
    OUT.write_text(json.dumps(results, indent=1) + "\n")


main()
