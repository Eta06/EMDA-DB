use database_engine::{
    BatchOperation, CheckpointStore, CheckpointStoreLimits, RecoveredCheckpointView,
    RecoveredViewLimits, Store,
};
use std::{env, fs, io, path::Path};

fn run() -> io::Result<()> {
    let args: Vec<_> = env::args().skip(1).collect();
    let path = Path::new(&args[1]);
    let limit: u64 = args[2].parse().unwrap();
    if args[0] == "setup" {
        fs::create_dir(path)?;
        let store = Store::open(path.join("live"))?;
        let value = vec![39; 1024 * 1024];
        for _ in 0..limit {
            store.put(b"key", &value)?;
        }
        let digest = store.checkpoint_to(path.join("index"))?;
        fs::write(path.join("digest"), digest)?;
        store.write_batch(&[
            BatchOperation::Delete { key: b"key" },
            BatchOperation::Put { key: b"key", value: b"current" },
        ])?;
        return Ok(());
    }
    let digest: [u8; 32] = fs::read(path.join("digest"))?.try_into().unwrap();
    let result = match args[0].as_str() {
        "writer" => CheckpointStore::open_with_suffix_operation_limit(
            path.join("live"), path.join("index"), &digest, CheckpointStoreLimits::default(), limit,
        ).and_then(|store| store.get(b"key")),
        "reader" => RecoveredCheckpointView::open_with_suffix_operation_limit(
            path.join("live"), path.join("index"), &digest, RecoveredViewLimits::default(), limit,
        ).and_then(|store| store.get(b"key")),
        _ => panic!("unknown mode"),
    };
    if limit == 1 {
        let error = result.unwrap_err();
        assert_eq!(error.kind(), io::ErrorKind::InvalidInput);
        assert_eq!(error.to_string(), "checkpoint suffix operation limit exceeded");
        println!("rejected");
    } else {
        assert_eq!(result?.as_deref(), Some(b"current".as_slice()));
        println!("verified");
    }
    Ok(())
}

fn main() -> io::Result<()> { run() }
