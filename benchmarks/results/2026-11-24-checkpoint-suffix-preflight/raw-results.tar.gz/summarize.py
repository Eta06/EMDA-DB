from collections import defaultdict
from pathlib import Path
import csv
import re
import sys

root = Path(sys.argv[1])
totals = defaultdict(set)
read_call = re.compile(r"^(?:read|pread64|preadv)\(\d+<[^>]+/records\.log>.*\)\s+= (\d+)$")
for path in sorted(root.glob("*.trace")):
    size, mode, limit, cycle, build = path.stem.split("-")
    log = path.with_suffix(".log").read_text().strip()
    assert log == ("rejected" if limit == "1" else "verified"), path
    lines = path.read_text().splitlines()
    assert not any(line.startswith(("write(", "pwrite64(", "fsync(", "fdatasync("))
                   and ("/records.log>" in line or "/commit.state>" in line)
                   for line in lines), path
    count = sum(int(match[1]) for line in lines if (match := read_call.match(line)))
    assert count > 0, path
    totals[size, mode, limit, build].add(count)
assert len(list(root.glob("*.trace"))) == 72
assert len(totals) == 24
writer = csv.writer(sys.stdout)
writer.writerow(("history_mib", "mode", "limit", "baseline_log_bytes", "candidate_log_bytes"))
for size in ("1", "8", "32"):
    for mode in ("reader", "writer"):
        for limit in ("1", "2"):
            before = totals[size, mode, limit, "baseline"]
            after = totals[size, mode, limit, "candidate"]
            assert len(before) == len(after) == 1
            if limit == "1":
                assert next(iter(before)) > next(iter(after))
            else:
                assert before == after
            writer.writerow((size, mode, limit, next(iter(before)), next(iter(after))))
