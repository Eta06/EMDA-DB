"""Run 24 alternating baseline/candidate pairs and retain each attempt."""
import json
import pathlib
import subprocess
import tempfile

out = pathlib.Path(__file__).resolve().parent
root = out.parent
settings = [
    ("8b-idle", 8, 300_000, 0),
    ("257b-idle", 257, 300_000, 0),
    ("4mib-idle", 4_194_304, 768, 0),
    ("4mib-writer", 4_194_304, 1_536, 96),
]
failed = False
for case, value_bytes, comparisons, writes in settings:
    for pair in range(1, 7):
        labels = ("baseline", "candidate") if pair % 2 else ("candidate", "baseline")
        for label in labels:
            artifacts = out / "attempts" / case / str(pair) / label
            artifacts.mkdir(parents=True, exist_ok=False)
            with tempfile.TemporaryDirectory(prefix=f"{label}-{case}-", dir=root) as directory:
                command = ["/usr/bin/time", "-l", str(root / f"{label}-probe"), directory, str(value_bytes), str(comparisons), str(writes)]
                with (artifacts / "output.log").open("wb") as output, (artifacts / "time.log").open("wb") as timing:
                    status = subprocess.run(command, stdout=output, stderr=timing, check=False)
                metadata = {"command": command, "case": case, "pair": pair, "label": label, "returncode": status.returncode}
                (artifacts / "attempt.json").write_text(json.dumps(metadata) + "\n")
                failed = failed or status.returncode != 0
                print(case, pair, label, status.returncode, flush=True)
raise SystemExit(1 if failed else 0)
