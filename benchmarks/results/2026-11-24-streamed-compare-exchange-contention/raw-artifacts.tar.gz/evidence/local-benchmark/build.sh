#!/bin/bash
set -euo pipefail
r=$(cd "$(dirname "$0")/.." && pwd)
export CARGO_TARGET_DIR="$r/bench-target"
for pair in "$@"; do
    label=${pair%%:*}
    revision=${pair#*:}
    printf '%s %s\n' "$label" "$revision"
    git archive "$revision" -- Cargo.toml Cargo.lock src | tar -xf - -C "$r/$label"
    cargo +1.85.0 build --manifest-path "$r/$label/Cargo.toml" --release --locked --lib > "$r/local-benchmark/$label-build.log" 2>&1
    rustc +1.85.0 --edition=2024 -C opt-level=3 -L "dependency=$CARGO_TARGET_DIR/release/deps" --extern "database_engine=$CARGO_TARGET_DIR/release/libdatabase_engine.rlib" "$r/local-benchmark/probe.rs" -o "$r/$label-probe" >> "$r/local-benchmark/$label-build.log" 2>&1
done
(cd "$r" && shasum -a 256 baseline-probe candidate-probe local-benchmark/probe.rs)
