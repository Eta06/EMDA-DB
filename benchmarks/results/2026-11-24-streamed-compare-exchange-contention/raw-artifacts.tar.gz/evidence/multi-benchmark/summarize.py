"""Check round identities and correctness receipts and report sample medians."""
import json
import pathlib
from statistics import median

out = pathlib.Path(__file__).resolve().parent
spec = {"4mib-four-readers": (4_194_304, 1_536, 0), "4mib-four-readers-writer": (4_194_304, 1_536, 96)}
for case, (value_bytes, comparisons, writes) in spec.items():
    for label in ("baseline", "candidate"):
        samples = []
        for pair in range(1, 7):
            artifacts = out / "attempts" / case / str(pair) / label
            meta = json.loads((artifacts / "attempt.json").read_text())
            assert (meta["pair"], meta["case"], meta["label"], meta["returncode"]) == (pair, case, label, 0)
            result = json.loads((artifacts / "output.log").read_text())
            assert (result["bytes"], result["comparisons"], result["writes"]) == (value_bytes, comparisons, writes)
            assert result["readers"] == 4
            assert len(result["write_ns"]) == writes
            samples.append(result)
        compare_rate = median(comparisons * 1e9 / sample["compare_ns"] for sample in samples)
        print(f"{case} {label:9} {compare_rate:10.1f} compare/s", end="")
        if writes:
            writer_total = median(sample["writer_ns"] / 1e6 for sample in samples)
            writer_p95 = median(sorted(sample["write_ns"])[(95 * writes + 99) // 100 - 1] / 1e6 for sample in samples)
            print(f" {writer_total:8.3f} ms writer total {writer_p95:6.3f} ms writer p95", end="")
        print()
assert len(list((out / "attempts").glob("*/*/*/attempt.json"))) == 24
