use database_engine::Store;
use std::path::Path;
use std::sync::{Arc, Barrier};
use std::thread;
use std::time::Instant;

fn main() -> std::io::Result<()> {
    let mut args = std::env::args().skip(1);
    let directory = args.next().expect("store directory");
    let bytes: usize = args.next().expect("value bytes").parse().unwrap();
    let comparisons: u64 = args.next().expect("comparison count").parse().unwrap();
    let writes: u64 = args.next().expect("write count").parse().unwrap();
    let readers: usize = args.next().expect("comparison readers").parse().unwrap();
    assert_eq!(comparisons % readers as u64, 0);
    let store = Arc::new(Store::open(Path::new(&directory))?);
    let original = vec![42_u8; bytes];
    store.put(b"compare", &original)?;
    store.put(b"writer", &0_u64.to_le_bytes())?;
    for _ in 0..16 {
        assert!(!store.compare_exchange(b"compare", None, Some(b"unexpected"))?);
    }
    let start_gate = Arc::new(Barrier::new(readers + 1 + usize::from(writes > 0)));
    let writer = (writes > 0).then(|| {
        let store = Arc::clone(&store);
        let start_gate = Arc::clone(&start_gate);
        thread::spawn(move || -> std::io::Result<_> {
            let mut latencies = Vec::with_capacity(writes as usize);
            start_gate.wait();
            let start = Instant::now();
            for sequence in 1..=writes {
                let write_start = Instant::now();
                store.put(b"writer", &sequence.to_le_bytes())?;
                latencies.push(write_start.elapsed().as_nanos());
            }
            Ok((start.elapsed().as_nanos(), latencies))
        })
    });
    let mut comparers = Vec::with_capacity(readers);
    for _ in 0..readers {
        let store = Arc::clone(&store);
        let start_gate = Arc::clone(&start_gate);
        comparers.push(thread::spawn(move || -> std::io::Result<_> {
            start_gate.wait();
            let start = Instant::now();
            for _ in 0..comparisons / readers as u64 {
                assert!(!store.compare_exchange(b"compare", None, Some(b"unexpected"))?);
            }
            Ok(start.elapsed().as_nanos())
        }));
    }
    start_gate.wait();
    let mut compare_ns = 0;
    for thread in comparers {
        compare_ns = compare_ns.max(thread.join().expect("reader panicked")?);
    }
    let (writer_ns, latencies) = match writer {
        Some(writer) => writer.join().expect("writer panicked")?,
        None => (0, Vec::new()),
    };
    assert_eq!(store.get(b"compare")?.unwrap(), original);
    assert_eq!(store.get(b"writer")?.unwrap(), writes.to_le_bytes());
    print!(
        "{{\"readers\":{readers},\"bytes\":{bytes},\"comparisons\":{comparisons},\"writes\":{writes},\"compare_ns\":{compare_ns},\"writer_ns\":{writer_ns},\"write_ns\":["
    );
    for (index, time) in latencies.iter().enumerate() {
        if index != 0 {
            print!(",");
        }
        print!("{time}");
    }
    println!("]}}");
    Ok(())
}
