use database_engine::Store;
use std::{env, error::Error};

fn main() -> Result<(), Box<dyn Error>> {
    let args: Vec<_> = env::args().skip(1).collect();
    let [mode, database, backup] = args.as_slice() else {
        return Err("expected mode, database and backup".into());
    };
    match mode.as_str() {
        "backup" => {
            let db = Store::open(database)?;
            for key in 0_u32..100 {
                db.put(&key.to_be_bytes(), &[key as u8; 256])?;
            }
            db.delete(&0_u32.to_be_bytes())?;
            db.put(&1_u32.to_be_bytes(), &[0xa5; 256])?;
            db.backup(backup)?;
            db.put(b"later", b"after backup")?;
            println!("snapshot_created=true post_backup_write_acknowledged=true");
        }
        "restore" => {
            Store::restore(backup, database)?;
            let db = Store::open(database)?;
            assert_eq!(db.scan(None, None, 1000)?.len(), 99);
            for key in 1_u32..100 {
                let value = if key == 1 { 0xa5 } else { key as u8 };
                assert_eq!(db.get(&key.to_be_bytes())?.as_deref(), Some(&[value; 256][..]));
            }
            assert!(db.get(&0_u32.to_be_bytes())?.is_none());
            assert!(db.get(b"later")?.is_none());
            println!("restored_matches=99 deleted_absent=true post_backup_write_absent=true");
        }
        _ => return Err("unknown mode".into()),
    }
    Ok(())
}
