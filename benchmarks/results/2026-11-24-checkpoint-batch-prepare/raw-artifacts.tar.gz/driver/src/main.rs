use database_engine::{BatchOperation, CheckpointStore, Store};
use std::alloc::{GlobalAlloc, Layout, System};
use std::sync::atomic::{AtomicBool, AtomicUsize, Ordering::Relaxed};

struct CountingAllocator;
static COUNTING: AtomicBool = AtomicBool::new(false);
static CALLS: AtomicUsize = AtomicUsize::new(0);
static BYTES: AtomicUsize = AtomicUsize::new(0);

fn count(size: usize) {
    if COUNTING.load(Relaxed) {
        CALLS.fetch_add(1, Relaxed);
        BYTES.fetch_add(size, Relaxed);
    }
}

unsafe impl GlobalAlloc for CountingAllocator {
    unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
        count(layout.size());
        unsafe { System.alloc(layout) }
    }

    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        count(layout.size());
        unsafe { System.alloc_zeroed(layout) }
    }

    unsafe fn realloc(&self, pointer: *mut u8, layout: Layout, size: usize) -> *mut u8 {
        count(size);
        unsafe { System.realloc(pointer, layout, size) }
    }

    unsafe fn dealloc(&self, pointer: *mut u8, layout: Layout) {
        unsafe { System.dealloc(pointer, layout) }
    }
}

#[global_allocator]
static ALLOCATOR: CountingAllocator = CountingAllocator;

fn main() -> std::io::Result<()> {
    let children: usize = std::env::args().nth(1).unwrap().parse().unwrap();
    assert!(matches!(children, 1 | 1024));
    let root = tempfile::tempdir()?;
    let path = root.path().join("store");
    let checkpoint = root.path().join("checkpoint");
    let source = Store::open(&path)?;
    let digest = source.checkpoint_to(&checkpoint)?;
    drop(source);
    let store = CheckpointStore::open(&path, &checkpoint, &digest)?;
    let value = vec![7; 4 * 1024 * 1024 / children];
    let keys: Vec<_> = (0..children).map(|index| index.to_be_bytes()).collect();
    let operations: Vec<_> = keys
        .iter()
        .map(|key| BatchOperation::Put { key, value: &value })
        .collect();
    let start = std::time::Instant::now();
    COUNTING.store(true, Relaxed);
    let result = store.write_batch(&operations);
    COUNTING.store(false, Relaxed);
    let elapsed_us = start.elapsed().as_micros();
    result?;
    for key in &keys {
        assert_eq!(store.get(key)?.as_deref(), Some(value.as_slice()));
    }
    drop(store);
    let store = CheckpointStore::open(&path, &checkpoint, &digest)?;
    for key in &keys {
        assert_eq!(store.get(key)?.as_deref(), Some(value.as_slice()));
    }
    println!(
        "children={children} calls={} requested_bytes={} elapsed_us={elapsed_us} verified={children}",
        CALLS.load(Relaxed),
        BYTES.load(Relaxed)
    );
    Ok(())
}
