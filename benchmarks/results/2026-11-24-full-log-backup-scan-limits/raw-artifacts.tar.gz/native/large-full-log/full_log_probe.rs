use database_engine::{
    CheckpointStore, FullLogBackupLimits, FullLogRestoreLimits, PublicationFailure, Store,
};
use std::{fs, io, path::Path, time::Instant};

const KEYS: u64 = 32;
const VALUE_BYTES: usize = 4 * 1024 * 1024;

fn verify(store: &Store) {
    for key in 0..KEYS {
        assert_eq!(store.get(&key.to_be_bytes()).unwrap().as_deref(), Some(&key.to_le_bytes()[..]));
    }
    assert_eq!(store.scan(None, None, 1024).unwrap().len(), KEYS as usize);
}

fn assert_short(error: PublicationFailure) {
    assert!(matches!(error, PublicationFailure::NotPublished(error)
        if error.kind() == io::ErrorKind::InvalidInput
            && error.to_string() == "full-log backup or restore exceeds configured scan byte limit"));
}

fn measure_backup(
    destination: &Path,
    log_bytes: u64,
    call: impl Fn(FullLogBackupLimits) -> Result<(), PublicationFailure>,
) {
    let mut limits = FullLogBackupLimits {
        max_file_bytes: Some(log_bytes + 56),
        max_log_scan_bytes: Some(2 * log_bytes - 1),
    };
    assert_short(call(limits).unwrap_err());
    assert!(!destination.exists());
    limits.max_log_scan_bytes = Some(2 * log_bytes);
    let start = Instant::now();
    call(limits).unwrap();
    println!("elapsed_ns={} log_bytes={log_bytes} max_log_scan_bytes={} short_rejected=1",
        start.elapsed().as_nanos(), 2 * log_bytes);
    assert_eq!(fs::metadata(destination).unwrap().len(), log_bytes + 56);
}

fn main() {
    let mut args = std::env::args().skip(1);
    let phase = args.next().unwrap();
    let fixture = args.next().unwrap();
    let root = Path::new(&fixture);
    let source = root.join("source");
    let checkpoint = root.join("checkpoint");
    let trusted = root.join("checkpoint.digest");
    let backup = root.join("ordinary.backup");
    if phase == "setup" {
        fs::create_dir(root).unwrap();
        let store = Store::open(&source).unwrap();
        let history = vec![42_u8; VALUE_BYTES];
        for key in 0..KEYS {
            store.put(&key.to_be_bytes(), &history).unwrap();
            store.put(&key.to_be_bytes(), &key.to_le_bytes()).unwrap();
        }
        verify(&store);
        fs::write(trusted, store.checkpoint_to(checkpoint).unwrap()).unwrap();
        return;
    }
    let bytes = fs::metadata(source.join("records.log")).unwrap().len();
    match phase.as_str() {
        "backup-ordinary" => {
            let store = Store::open(&source).unwrap();
            measure_backup(&backup, bytes, |limits| store.backup_with_limits_detailed(&backup, limits));
        }
        "backup-checkpoint" => {
            let digest = fs::read(trusted).unwrap().try_into().unwrap();
            let store = CheckpointStore::open(&source, checkpoint, &digest).unwrap();
            let output = root.join("checkpoint.backup");
            measure_backup(&output, bytes, |limits| store.backup_with_limits_detailed(&output, limits));
        }
        "restore" => {
            let output = root.join("restored");
            let mut limits = FullLogRestoreLimits {
                max_log_bytes: Some(bytes),
                max_log_scan_bytes: Some(3 * bytes - 1),
            };
            assert_short(Store::restore_with_limits_detailed(&backup, &output, limits).unwrap_err());
            assert!(!output.exists());
            limits.max_log_scan_bytes = Some(3 * bytes);
            let start = Instant::now();
            Store::restore_with_limits_detailed(&backup, &output, limits).unwrap();
            println!("elapsed_ns={} log_bytes={bytes} max_log_scan_bytes={} short_rejected=1",
                start.elapsed().as_nanos(), 3 * bytes);
            verify(&Store::open(output).unwrap());
            println!("verified_entries={KEYS}");
        }
        _ => panic!("unknown phase"),
    }
}
