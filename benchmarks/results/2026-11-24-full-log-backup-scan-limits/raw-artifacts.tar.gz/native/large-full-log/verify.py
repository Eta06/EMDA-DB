from pathlib import Path
import hashlib
import json
import re
import sys

root = Path(__file__).resolve().parent
revision = sys.argv[1]
log_bytes = 134_219_868
for phase, passes in (("backup-ordinary", 2), ("backup-checkpoint", 2), ("restore", 3)):
    meta = json.loads((root / phase / "attempt.json").read_text())
    assert meta["revision"] == revision and meta["case"] == f"large-full-log-{phase}"
    assert meta["status"] == "exited" and meta["returncode"] == meta["wrapper_exit_code"] == 0
    output = (root / phase / meta["output"]).read_text()
    assert f"log_bytes={log_bytes} max_log_scan_bytes={passes * log_bytes} short_rejected=1" in output
    assert re.search(r"elapsed_ns=[1-9][0-9]*", output)
    assert re.search(r"^\s*[1-9][0-9]*\s+maximum resident set size", output, re.M)
    if phase == "restore":
        assert "verified_entries=32" in output
    print(phase, "exact scan and restored output verified")
before = (root / "source-before.sha256").read_text()
assert before == (root / "source-after.sha256").read_text()
hashes = {path: digest for digest, path in
          (line.split() for line in (root / "artifacts.sha256").read_text().splitlines())}
assert hashes["ordinary.backup"] == hashes["checkpoint.backup"]
assert hashes["source/records.log"] == hashes["restored/records.log"] == before.split()[0]
assert hashlib.sha256((root/"full_log_probe.rs").read_bytes()).hexdigest() == \
       (root/"probe-hashes.txt").read_text().splitlines()[1].split()[0]
print("Backup bytes, restored log, source log and witness match")
