"""Run paired fresh-process restores from a common, independently bound fixture."""
import hashlib
import json
from pathlib import Path
import platform
import re
import shutil
import subprocess
import sys
import tempfile

before, after, parent = (Path(arg).resolve() for arg in sys.argv[1:])

def hashes(root):
    return {
        str(path.relative_to(root)): hashlib.sha256(path.read_bytes()).hexdigest()
        for path in sorted(root.rglob("*")) if path.is_file()
    }

with tempfile.TemporaryDirectory(prefix="emda-restore-pairs.", dir=parent) as tmp:
    root = Path(tmp)
    fixture = root / "fixture"
    subprocess.run([str(before), "setup", str(fixture), "unused"], check=True, stdout=sys.stderr)
    source_hashes = hashes(fixture)
    print(json.dumps({"input_sha256": source_hashes}), flush=True)
    for pair in range(5):
        order = [("before", before), ("after", after)]
        if pair % 2:
            order.reverse()
        for version, binary in order:
            output = root / ("restored-" + version)
            if platform.system() == "Darwin":
                time = ["/usr/bin/time", "-l"]
                size_pattern = r"(\d+)\s+maximum resident set size"
                units = 1
            else:
                time = ["/usr/bin/time", "-f", "peak_rss_kib=%M"]
                size_pattern = r"peak_rss_kib=(\d+)"
                units = 1024
            result = subprocess.run(
                [*time, str(binary), "restore", str(fixture), str(output)],
                check=True, text=True, capture_output=True, timeout=120,
            )
            verified = subprocess.check_output(
                [str(after), "verify", str(fixture), str(output)], text=True, timeout=30,
            ).strip()
            assert verified == "verified_bytes=31457280", verified
            assert hashes(fixture) == source_hashes
            print(json.dumps({
                "pair": pair, "version": version,
                "ns": int(re.search(r"restore_ns=(\d+)", result.stdout)[1]),
                "rss_bytes": int(re.search(size_pattern, result.stderr)[1]) * units,
                "verification": verified, "time_output": result.stderr,
            }), flush=True)
            shutil.rmtree(output)
