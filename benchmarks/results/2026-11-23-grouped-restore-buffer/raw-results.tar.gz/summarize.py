"""Summarize complete paired restore samples."""
import json
from statistics import median
import sys

assert len(sys.argv) == 3
print("| Platform | Build | Median peak RSS MiB | Median restore ms |")
print("| --- | --- | ---: | ---: |")
for platform, path in zip(("macOS ARM64 APFS", "Linux ARM64 ext4"), sys.argv[1:]):
    with open(path) as file:
        hashes, *samples = map(json.loads, file)
    assert "input_sha256" in hashes and len(samples) == 10
    for name in ("before", "after"):
        selected = [s for s in samples if s["version"] == name]
        assert sorted(s["pair"] for s in selected) == list(range(5))
        assert all(s["verification"] == "verified_bytes=31457280" for s in selected)
        rss = median(s["rss_bytes"] for s in selected) / 1024**2
        ms = median(s["ns"] for s in selected) / 1e6
        print(f"| {platform} | {name} | {rss:.2f} | {ms:.2f} |")
