use database_engine::retained_base_v2::Limits;
use database_engine::retained_candidate::{
    AuthorizedRetainedStore, FileRetainedAuthority, IndexLimits, OverlayLimits, RetainedAuthority,
    RetainedStoreLimits, SuffixLimits,
};
use database_engine::{RetainedExportLimits, Store};
use std::path::PathBuf;

const LIMITS: RetainedStoreLimits = RetainedStoreLimits {
    base: Limits {
        file_bytes: 8192,
        entries: 32,
        key_bytes: 256,
        work_bytes: 8193,
    },
    index: IndexLimits {
        blocks: 4,
        anchor_bytes: 64,
    },
    suffix: SuffixLimits {
        bytes: 8192,
        operations: 64,
        work: 4096,
    },
    overlay: OverlayLimits {
        entries: 32,
        key_bytes: 256,
    },
};
fn main() {
    let args: Vec<String> = std::env::args().collect();
    let phase = &args[1];
    let catalog = PathBuf::from(&args[2]);
    let authority = PathBuf::from(&args[3]);
    if phase == "seed" {
        let source = catalog.with_extension("source");
        let store = Store::open(&source).unwrap();
        store.put(b"base", b"verified").unwrap();
        let initial = AuthorizedRetainedStore::<FileRetainedAuthority>::prepare_from_store(
            store,
            &source,
            &catalog,
            RetainedExportLimits {
                max_log_bytes: 8192,
                max_live_keys: 32,
                max_live_key_bytes: 256,
                max_output_bytes: 8192,
            },
            LIMITS,
        )
        .unwrap();
        let mut provider = FileRetainedAuthority::create(authority).unwrap();
        assert!(provider.compare_and_swap(None, initial).unwrap());
        let mut db = AuthorizedRetainedStore::open(catalog, LIMITS, provider).unwrap();
        db.put(b"ack", b"acknowledged").unwrap();
        println!("seeded and acknowledged initial append");
        return;
    }
    let mut provider = FileRetainedAuthority::open(&authority).unwrap();
    let before = provider.read().unwrap().unwrap();
    let reopened = AuthorizedRetainedStore::open(catalog, LIMITS, provider);
    if phase == "rollback" {
        assert!(reopened.is_err());
        println!(
            "stale catalog rejected at authority revision {}",
            before.revision
        );
        return;
    }
    let mut db = reopened.unwrap();
    assert_eq!(db.get(b"ack", 12).unwrap().unwrap(), b"acknowledged");
    if phase == "rotate" {
        db.compact().unwrap();
        db.reclaim_inactive().unwrap();
        db.put(b"new", b"confirmed").unwrap();
    } else {
        assert_eq!(db.get(b"new", 9).unwrap().unwrap(), b"confirmed");
    }
    let after = FileRetainedAuthority::open(&authority)
        .unwrap()
        .read()
        .unwrap()
        .unwrap();
    assert_eq!(after.pending, None);
    println!("{phase} verified authority revision {}", after.revision);
}
