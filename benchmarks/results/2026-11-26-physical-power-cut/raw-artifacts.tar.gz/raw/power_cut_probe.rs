use database_engine::{BatchOperation as Op, Store};
use std::{
    env,
    error::Error,
    io::{self, Write},
    thread,
    time::Duration,
};

fn value(id: u64, tag: u8) -> Vec<u8> {
    let mut data = vec![tag; 4096];
    data[..8].copy_from_slice(&id.to_be_bytes());
    data
}

fn keys(id: u64) -> (String, String) {
    (format!("a/{id:08}"), format!("b/{id:08}"))
}

fn main() -> Result<(), Box<dyn Error>> {
    let options: Vec<_> = env::args().skip(1).collect();
    let [mode, path, count] = options.as_slice() else {
        return Err("usage: power_cut_probe write|verify PATH COUNT".into());
    };
    let count = count.parse::<u64>()?;
    if count == 0 || count > 20_000 {
        return Err("COUNT must be between 1 and 20000".into());
    }
    match mode.as_str() {
        "write" => {
            if std::path::Path::new(path).exists() {
                return Err("writer requires a new path".into());
            }
            let store = Store::open(path)?;
            let mut output = io::stdout().lock();
            for id in 1..=count {
                let (left, right) = keys(id);
                store.write_batch(&[
                    Op::Put {
                        key: left.as_bytes(),
                        value: &value(id, b'A'),
                    },
                    Op::Put {
                        key: right.as_bytes(),
                        value: &value(id, b'B'),
                    },
                ])?;
                writeln!(output, "ACK {id}")?;
                output.flush()?;
                thread::sleep(Duration::from_millis(35));
            }
        }
        "verify" => {
            if !std::path::Path::new(path).join("records.log").is_file() {
                return Err("no existing records.log to verify".into());
            }
            let store = Store::open(path)?;
            for id in 1..=count {
                let (left, right) = keys(id);
                if store.get(left.as_bytes())? != Some(value(id, b'A'))
                    || store.get(right.as_bytes())? != Some(value(id, b'B'))
                {
                    return Err(format!("missing or changed acknowledged pair {id}").into());
                }
            }
            println!(
                "verified_acknowledged_batches={count} verified_values={}",
                count * 2
            );
        }
        _ => return Err("unknown mode".into()),
    }
    Ok(())
}
