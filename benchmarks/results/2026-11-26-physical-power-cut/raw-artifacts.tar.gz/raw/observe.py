import argparse
import os
import shlex
import subprocess
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument("host")
parser.add_argument("binary")
parser.add_argument("store")
parser.add_argument("count", type=int)
parser.add_argument("receipts", type=Path)
args = parser.parse_args()

remote_command = shlex.join([args.binary, "write", args.store, str(args.count)])
with args.receipts.open("x") as receipts:
    child = subprocess.Popen(
        ["ssh", "-o", "BatchMode=yes", "-o", "StrictHostKeyChecking=yes",
         "-o", "ServerAliveInterval=3", "-o", "ServerAliveCountMax=2",
         args.host, remote_command],
        stdout=subprocess.PIPE,
        text=True,
    )
    expected = 1
    try:
        for line in child.stdout:
            if line.strip() != f"ACK {expected}":
                raise ValueError(f"Unexpected receipt: {line!r}")
            receipts.write(line)
            receipts.flush()
            os.fsync(receipts.fileno())
            if expected == 1 or expected % 100 == 0:
                print(f"Recorded {expected} acknowledged batches", flush=True)
            expected += 1
    finally:
        child.stdout.close()
        if child.poll() is None:
            code = child.wait()
        else:
            code = child.returncode
    print(f"recorded={expected - 1} ssh_exit={code}", flush=True)
    if code != 0 or expected - 1 != args.count:
        raise SystemExit(1)
