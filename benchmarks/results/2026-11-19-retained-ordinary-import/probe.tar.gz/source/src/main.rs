use database_engine::retained_base_v2::Limits;
use database_engine::retained_candidate::{
    Expected, IndexLimits, ManagedRetainedStore, OverlayLimits, RetainedStoreLimits,
    SuffixExpected, SuffixLimits,
};
use database_engine::{RetainedExportLimits, Store};
use std::fs;
use std::hash::{DefaultHasher, Hash, Hasher};
use std::path::Path;

const LIMITS: RetainedStoreLimits = RetainedStoreLimits {
    base: Limits {
        file_bytes: 64 * 1024 * 1024,
        work_bytes: 64 * 1024 * 1024 + 1,
        entries: 20_000,
        key_bytes: 1024 * 1024,
    },
    index: IndexLimits {
        blocks: 512,
        anchor_bytes: 512 * 1024,
    },
    suffix: SuffixLimits {
        bytes: 2 * 1024 * 1024,
        operations: 20_000,
        work: 100_000_000_000,
    },
    overlay: OverlayLimits {
        entries: 20_000,
        key_bytes: 1024 * 1024,
    },
};

fn read_binding(root: &Path) -> Result<SuffixExpected, Box<dyn std::error::Error>> {
    let candidate = fs::read(root.join("candidate.binding"))?;
    let suffix = fs::read(root.join("suffix.binding"))?;
    assert_eq!(candidate.len(), 176);
    assert_eq!(suffix.len(), 40);
    Ok(SuffixExpected {
        candidate: Expected {
            header: candidate[..112].try_into()?,
            witness: candidate[112..144].try_into()?,
            base_digest: candidate[144..].try_into()?,
        },
        end: u64::from_le_bytes(suffix[..8].try_into()?),
        digest: suffix[8..].try_into()?,
    })
}

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let args: Vec<String> = std::env::args().collect();
    let [_, phase, input, root] = args.as_slice() else {
        return Err("expected phase, input and catalog".into());
    };
    let input = Path::new(input);
    let root = Path::new(root);
    if phase == "create" {
        let expected = read_binding(input)?;
        ManagedRetainedStore::create_from_suffix(
            input.join("candidate"),
            input.join("suffix"),
            root,
            LIMITS,
            &expected,
        )?;
        return Ok(());
    }
    if phase == "direct" || phase == "candidate" {
        let export = RetainedExportLimits {
            max_log_bytes: 4 * 1024 * 1024,
            max_live_keys: 20_000,
            max_live_key_bytes: 1024 * 1024,
            max_output_bytes: 64 * 1024 * 1024,
        };
        let store = Store::open_with_log_limit(input, export.max_log_bytes)?;
        if phase == "direct" {
            ManagedRetainedStore::copy_from_store(store, input, root, export, LIMITS)?;
        } else {
            let candidate = root.with_extension("candidate");
            let binding = store.build_retained_candidate(&candidate, [71; 16], [72; 16], export)?;
            ManagedRetainedStore::create(&candidate, root, LIMITS, &binding)?;
        }
        return Ok(());
    }
    let mut db = ManagedRetainedStore::open(root, LIMITS)?;
    match phase.as_str() {
        "compact" => {
            db.compact()?;
        }
        "reclaim" => {
            assert!(db.reclaim_inactive()?);
        }
        "scan" => {
            let mut after = None;
            let mut hasher = DefaultHasher::new();
            let mut count = 0;
            loop {
                let page = db.scan(after.as_deref(), None, 1024)?;
                let Some((key, _)) = page.last() else { break };
                assert!(after.as_ref().is_none_or(|prior| prior < key));
                after = Some(key.clone());
                count += page.len();
                for entry in page {
                    entry.hash(&mut hasher);
                }
            }
            println!("{count} {:016x}", hasher.finish());
        }
        _ => return Err("unknown phase".into()),
    }
    Ok(())
}
