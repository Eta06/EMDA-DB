"""Count retained inputs that exercise the new integer-run oracle."""
from collections import Counter
import sys
import tarfile

modes = Counter()
grouped = Counter()
endpoints = Counter()
with tarfile.open(sys.argv[1], "r:gz") as archive:
    entries = [member for member in archive.getmembers() if member.isfile()]
    for member in entries:
        data = archive.extractfile(member).read()
        if not 1 <= len(data) <= 96:
            continue
        for position in range(1, len(data) - 3, 4):
            mode = data[position] % 25
            modes[mode] += 1
            if mode in (23, 24):
                flag = data[0] & 3
                grouped[flag] += 1
                bound = data[position + 2] % 4
                endpoints[bound if bound < 2 else 2] += 1
assert all(grouped[flag] for flag in range(4))
assert all(endpoints[endpoint] for endpoint in range(3))
print(f"{len(entries)} corpus inputs with {sum(modes.values())} query operations")
print("Grouped query operations by backend/partial flag:", sorted(grouped.items()))
print("Grouped query operations at minimum, maximum, interior:", sorted(endpoints.items()))
