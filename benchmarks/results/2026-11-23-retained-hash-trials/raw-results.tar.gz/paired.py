import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys

baseline, candidate, harness, root, keys = sys.argv[1:]
keys = int(keys)
module = importlib.util.spec_from_file_location("recovery", harness)
benchmark = importlib.util.module_from_spec(module)
module.loader.exec_module(benchmark)
root = Path(root)
root.mkdir()
binaries = {"baseline": Path(baseline), "candidate": Path(candidate)}
digests = {label: hashlib.sha256(binary.read_bytes()).hexdigest() for label, binary in binaries.items()}
assert digests["baseline"] != digests["candidate"]
(root / "environment.json").write_text(json.dumps({"binary_sha256": digests, "keys": keys, "suffix_work": os.environ["EMDA_BENCH_SUFFIX_WORK"]}, indent=2))
for label, binary in binaries.items():
    directory = root / label
    directory.mkdir()
    benchmark.run(binary, directory, "setup", "both", keys, 0)
    benchmark.run(binary, directory, "cutover", "retained", keys, 0)
for epoch in range(1, 7):
    order = ("baseline", "candidate") if epoch % 2 else ("candidate", "baseline")
    verified = []
    for label in order:
        binary = binaries[label]
        directory = root / label
        writes = benchmark.run(binary, directory, "mutate", "retained", keys, epoch)
        reads = benchmark.run(binary, directory, "reopen", "retained", keys, epoch)
        scans = benchmark.run(binary, directory, "verify", "retained", keys, epoch)
        verified.append((writes["rotations"], reads["suffix_bytes"], scans["verified_entries"]))
    assert verified[0] == verified[1], (epoch, verified)
    print(f"epoch={epoch} rotations={verified[0][0]} verified_entries={verified[0][2]}", flush=True)
