import json
from pathlib import Path
import re
import subprocess
import sys

root = Path(sys.argv[1])
engine = "90e10dc348ff4a9d6efb93943e53bd38e29e5a8e"
public_tests = "c7432a1adb45d6f06ac0dd4f62ac87c1408a6b47"
runs = {
    "45457955134": (engine, "success"),
    "45457954848": (engine, "failure"),
    "45457954943": (engine, "success"),
    "45457955232": (engine, "success"),
    "45457954804": (engine, "success"),
    "45459248570": (public_tests, "success"),
    "45459248078": (public_tests, "success"),
}
for run, (revision, conclusion) in runs.items():
    state = json.loads((root / run / "jobs.json").read_text())
    assert state["headSha"] == revision, (run, state)
    assert state["status"] == "completed" and state["conclusion"] == conclusion, (run, state)
    assert (root / run / "workflow.log").stat().st_size > 0, run
    print(state["workflowName"], run, state["conclusion"])

initial_macos = (root / "45457954848" / "workflow.log").read_text()
assert initial_macos.count("test unsupported_detailed_handoffs_are_rejected_before_publication ... FAILED") == 2

for run, directory, count in [
    ("45457955134", "ci-benchmark-smoke", 45),
    ("45457955134", "writable-recovery-memory-ceiling", 1),
    ("45457954943", "", 5),
    ("45459248570", "ci-benchmark-smoke", 45),
    ("45459248570", "writable-recovery-memory-ceiling", 1),
]:
    entries = list((root / run / directory).rglob("attempt.json"))
    assert len(entries) == count, (run, directory, len(entries))
    for path in entries:
        attempt = json.loads(path.read_text())
        assert attempt["revision"] == runs[run][0] and attempt["tracked_changes"] == "", path
        assert attempt["status"] == "exited" and attempt["returncode"] == attempt["wrapper_exit_code"] == 0, path
        assert (path.parent / attempt["output"]).is_file(), path
    print(run, directory, count, "benchmark attempts")
    if directory == "writable-recovery-memory-ceiling":
        measurements, = (root / run / directory).rglob("measurements.jsonl")
        subprocess.run([sys.executable, str(root / "verify-linux-phases.py"), str(measurements)], check=True)

names = [
    "exchange_holds_both_mapping_locks_through_failed_parent_sync",
    "process_kills_preserve_managed_source_and_both_logs",
    "process_kill_at_each_reclamation_boundary_preserves_acknowledged_data",
    "detailed_handoffs_preserve_rejected_and_successful_copies_in_both_formats",
    "detailed_online_reclamation_preserves_data_after_rejection_and_success",
    "document_indexes_survive_managed_checkpoint_compaction_and_reopen",
]
for run, minimum in [("45459248078", 2), ("45459248570", 3)]:
    log = (root / run / "workflow.log").read_text()
    expected = names + (["macos_exchange_refuses_non_apfs_before_staging"] if minimum == 2 else [])
    for name in expected:
        count = log.count(name + " ... ok")
        assert count >= minimum, (run, name, count)
        print(run, name, count, "passes")

for name, total in [("macos-final.log", 100), ("macos-strict-16.log", 100), ("macos-public-handoff.log", 73)]:
    log = (root / "native" / name).read_text()
    counts = [int(count) for count in re.findall(r"test result: ok\. (\d+) passed", log)]
    assert "test result: FAILED" not in log and sum(counts) == total, counts
    print("native macOS", name, total, "passes")
