import json
from pathlib import Path
from statistics import median
import sys

root = Path(sys.argv[1])
assert "macos_exchange_refuses_non_apfs_before_staging ... ok" in (root / "macos-final.log").read_text()
assert "unresolved import" in (root / "macos-first-build.log").read_text()
assert "test result: FAILED. 98 passed; 1 failed" in (root / "macos-first-suite.log").read_text()
assert (root / "benchmark-binary.sha256").read_text().split()[0] != (root / "benchmark-final-binary.sha256").read_text().split()[0]
for name, expected in [("attempts-stale-binary", 1), ("attempts-verified", 0)]:
    attempts = sorted((root / name).glob("*/attempt.json"))
    assert len(attempts) == 6, (name, len(attempts))
    times = {"retain": [], "reclaim": []}
    for path in attempts:
        attempt = json.loads(path.read_text())
        assert attempt["status"] == "exited", path
        assert attempt["returncode"] == attempt["wrapper_exit_code"] == expected, path
        assert attempt["revision"] == "90e10dc348ff4a9d6efb93943e53bd38e29e5a8e", path
        result = (path.parent / attempt["output"]).read_text()
        if expected:
            assert "online directory exchange currently requires Linux" in result, path
            continue
        result = json.loads(result)
        assert result["keys"] == 16000 and result["live_keys"] == 14000, path
        assert result["log_format"] == "V2" and result["reopen_verified"] and result["staging_clean"], path
        assert result["source_log_bytes"] == 2291380 and result["compacted_log_bytes"] == 1307722, path
        mode = result["mode"]
        previous = 2291380 if mode == "retain" else 0
        assert result["previous_log_bytes"] == previous, path
        assert result["total_log_bytes_after"] == 1307722 + previous, path
        times[mode].append(result["elapsed_us"])
    print(name, len(attempts), "attempts, exit", expected)
    if not expected:
        assert all(len(values) == 3 for values in times.values()), times
        for mode, values in times.items():
            print(mode, "elapsed us", min(values), median(values), max(values))

resources = sorted((root / "attempts-resources").glob("*/attempt.json"))
assert len(resources) == 6, len(resources)
import re

cpu = {"retain": [], "reclaim": []}
rss = {"retain": [], "reclaim": []}
for path in resources:
    attempt = json.loads(path.read_text())
    assert attempt["revision"] == "c7432a1adb45d6f06ac0dd4f62ac87c1408a6b47", path
    assert attempt["status"] == "exited" and attempt["returncode"] == attempt["wrapper_exit_code"] == 0, path
    log = (path.parent / attempt["output"]).read_text()
    result = json.loads(next(line for line in log.splitlines() if line.startswith("{")))
    assert result["keys"] == 16000 and result["live_keys"] == 14000 and result["reopen_verified"], path
    assert result["staging_clean"] and result["compacted_log_bytes"] == 1307722, path
    mode = result["mode"]
    cpu[mode].append(sum(float(re.search(rf"^{part} (\d+\.\d+)$", log, re.M)[1]) for part in ("user", "sys")))
    rss[mode].append(int(re.search(r"^\s*(\d+)  maximum resident set size$", log, re.M)[1]))
for mode in cpu:
    assert len(cpu[mode]) == len(rss[mode]) == 3
    print(mode, "median process CPU seconds", median(cpu[mode]), "median peak RSS bytes", median(rss[mode]))
