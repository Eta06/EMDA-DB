#!/bin/sh
set -eu
root=$(dirname "$0")
python3 "$root/verify-apfs-hosted.py" "$root"
python3 "$root/verify-apfs.py" "$root/native"
