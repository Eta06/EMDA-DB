/READ-PROBE-BEGIN/ { in_probe=1; next }
/READ-PROBE-END/ { in_probe=0; complete=1 }
in_probe && /\/checkpoint>/ && $NF ~ /^[0-9]+$/ { calls++; bytes+=$NF }
END {
    if (!complete || !calls) exit 1
    printf "%s\t%d\t%d\n", label, calls, bytes
}
