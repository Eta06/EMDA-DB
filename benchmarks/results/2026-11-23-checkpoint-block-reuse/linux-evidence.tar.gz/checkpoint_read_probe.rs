use database_engine::{BatchOperation, CheckpointStore, Store};
use std::{env, fs, path::Path};

fn key(number: u32) -> Vec<u8> {
    let mut key = b"a-long-shared-key-prefix-".to_vec();
    key.extend_from_slice(&number.to_be_bytes());
    key.resize(100 + (number as usize % 29), b'x');
    key
}

fn main() {
    let args = env::args().collect::<Vec<_>>();
    let root = Path::new(&args[2]);
    let checkpoint = root.join("checkpoint");
    if args[1] == "setup" {
        fs::create_dir_all(root).unwrap();
        let store = Store::open(root.join("store")).unwrap();
        let count: u32 = args[3].parse().unwrap();
        for start in (0..count).step_by(100) {
            let rows = (start..(start + 100).min(count))
                .map(|n| (key(n), n.to_le_bytes())).collect::<Vec<_>>();
            let batch = rows.iter().map(|(key, value)| BatchOperation::Put { key, value })
                .collect::<Vec<_>>();
            store.write_batch(&batch).unwrap();
        }
        fs::write(root.join("digest"), store.checkpoint_to(&checkpoint).unwrap()).unwrap();
        return;
    }
    let digest: [u8; 32] = fs::read(root.join("digest")).unwrap().try_into().unwrap();
    let store = CheckpointStore::open(root.join("store"), &checkpoint, &digest).unwrap();
    let keys = (40..136).map(key).collect::<Vec<_>>();
    let input = keys.iter().map(Vec::as_slice).collect::<Vec<_>>();
    let snapshot = (args[1] == "snapshot").then(|| store.snapshot().unwrap());
    eprintln!("READ-PROBE-BEGIN");
    match args[1].as_str() {
        "point" => assert_eq!(store.get(&key(48)).unwrap(), Some(48_u32.to_le_bytes().to_vec())),
        "range" => assert_eq!(
            store.scan(Some(&key(47)), None, 8).unwrap(),
            (48_u32..56).map(|n| (key(n), n.to_le_bytes().to_vec())).collect::<Vec<_>>()
        ),
        "bulk" | "snapshot" => {
            let result = match snapshot {
                Some(ref snapshot) => snapshot.get_many(&input),
                None => store.get_many(&input),
            }.unwrap();
            assert_eq!(result, (40_u32..136).map(|n| Some(n.to_le_bytes().to_vec())).collect::<Vec<_>>());
        }
        _ => panic!("unknown operation"),
    }
    eprintln!("READ-PROBE-END");
}
