#!/bin/sh
set -eu
root=$(dirname "$0")
python3 "$root/verify-hosted.py" "$root" 21f251a54e1407bd7337bebcaf3eccd9bfa39145 45453068398 45453068553 45453068473 45453068592 45453069100 macos-final.log 58 automatic_rollover_failures_preserve_or_fail_closed_before_user_writes detailed_write_exposes_automatic_rollover_failure_before_its_append worker_preserves_slot_and_selection_publication_failures automatic_checkpoint_scan_limit_stops_worker_before_rollover
test "$(cat "$root/native/baseline.exit")" -eq 101
grep -Fq 'downcast_ref::<crate::ManagedRolloverFailure>' "$root/native/baseline.log"
grep -Fq 'automatic_checkpoint_scan_limit_preserves_slots_selection_and_log ... FAILED' "$root/native/macos-first.log"
printf '%s\n' 'Previous revision omitted the typed automatic rollover cause' 'Initial local text compatibility regression was retained and fixed before push'
