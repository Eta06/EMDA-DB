#!/bin/sh
./target/debug/deps/database_engine-7b969b1c8fc513b6 --test-threads=16 > test.log 2>&1
echo $? > test.exit
