use database_engine::{
    BatchOperation, RetainedExportLimits, Store,
    retained_base_v2::Limits,
    retained_candidate::{
        IndexLimits, OverlayLimits, RetainedStore, RetainedStoreLimits, SuffixLimits,
    },
};
use rustix::time::{ClockId, clock_gettime};
use std::{error::Error, path::Path, time::Instant};

const BATCH: u64 = 1_024;
const LIMITS: RetainedStoreLimits = RetainedStoreLimits {
    base: Limits {
        file_bytes: 4096,
        entries: 1,
        key_bytes: 16,
        work_bytes: 4097,
    },
    index: IndexLimits {
        blocks: 0,
        anchor_bytes: 0,
    },
    suffix: SuffixLimits {
        bytes: 16 << 20,
        operations: 70_000,
        work: 20_000_000_000,
    },
    overlay: OverlayLimits {
        entries: 70_000,
        key_bytes: 560_000,
    },
};

fn cpu_ns() -> i128 {
    let time = clock_gettime(ClockId::ProcessCPUTime);
    i128::from(time.tv_sec) * 1_000_000_000 + i128::from(time.tv_nsec)
}

fn main() -> Result<(), Box<dyn Error>> {
    let args = std::env::args().collect::<Vec<_>>();
    let [_, root, rows, order] = args.as_slice() else {
        return Err("expected root, rows and front|back|replace".into());
    };
    let root = Path::new(root);
    let rows: u64 = rows.parse()?;
    assert!((BATCH..=65_536).contains(&rows));
    let source = Store::open(root.join("source"))?;
    let candidate = root.join("candidate");
    let expected = source.build_retained_candidate(
        &candidate,
        [5; 16],
        [6; 16],
        RetainedExportLimits {
            max_log_bytes: 4096,
            max_live_keys: 1,
            max_live_key_bytes: 16,
            max_output_bytes: 4096,
        },
    )?;
    let destination = root.join("retained");
    RetainedStore::create(&candidate, &destination, LIMITS, &expected)?;
    let mut store = RetainedStore::open(&destination, LIMITS, &expected)?;
    let seed = b"present";
    for first in (BATCH..BATCH + rows).step_by(BATCH as usize) {
        let keys = (first..(first + BATCH).min(BATCH + rows))
            .map(u64::to_be_bytes)
            .collect::<Vec<_>>();
        let ops = keys
            .iter()
            .map(|key| BatchOperation::Put { key, value: seed })
            .collect::<Vec<_>>();
        store.write_batch(&ops)?;
    }
    let first = match order.as_str() {
        "front" => 0,
        "back" => BATCH + rows,
        "replace" => BATCH,
        _ => return Err("unknown order".into()),
    };
    let keys = (first..first + BATCH)
        .map(u64::to_be_bytes)
        .collect::<Vec<_>>();
    let updates = keys
        .iter()
        .map(|key| BatchOperation::Put {
            key,
            value: b"changed",
        })
        .collect::<Vec<_>>();
    let started = Instant::now();
    let cpu_start = cpu_ns();
    store.write_batch(&updates)?;
    let cpu = cpu_ns() - cpu_start;
    println!(
        "write_ns={} write_cpu_ns={cpu} overlay_before={rows} order={order}",
        started.elapsed().as_nanos()
    );
    drop(store);

    let store = RetainedStore::open(&destination, LIMITS, &expected)?;
    let (start, end) = match order.as_str() {
        "front" => (0, BATCH + rows),
        "back" => (BATCH, BATCH + rows + BATCH),
        _ => (BATCH, BATCH + rows),
    };
    let mut model = start..end;
    let mut cursor = None;
    loop {
        let page = store.scan(cursor.as_deref(), None, 1024)?;
        if page.is_empty() {
            break;
        }
        for (key, value) in &page {
            let number = model.next().ok_or("extra row")?;
            assert_eq!(key, &number.to_be_bytes());
            let expected = if (first..first + BATCH).contains(&number) {
                b"changed".as_slice()
            } else {
                seed
            };
            assert_eq!(value, expected);
        }
        cursor = page.last().map(|(key, _)| key.clone());
    }
    assert!(model.next().is_none());
    println!("verified_entries={}", end - start);
    Ok(())
}
