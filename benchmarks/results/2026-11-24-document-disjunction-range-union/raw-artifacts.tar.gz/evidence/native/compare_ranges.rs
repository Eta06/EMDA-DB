use database_engine::{
    CheckpointStore, CollectionSchema, Comparison, DocumentDatabase, DocumentFilter, DocumentQuery,
    DocumentQueryAccess, IndexDefinition, IndexValue, Store,
};
use std::{io, path::Path};

#[derive(Clone, Copy)]
struct Row {
    tenant: u64,
    tag: i64,
    visible: bool,
}

#[derive(Clone, Copy)]
struct Range {
    tenant: u64,
    low: i64,
    high: i64,
    low_inclusive: bool,
    high_inclusive: bool,
    visible: bool,
}

fn draw(seed: &mut u64, size: u64) -> u64 {
    *seed ^= *seed << 13;
    *seed ^= *seed >> 7;
    *seed ^= *seed << 17;
    *seed % size
}

fn path(field: &str) -> Vec<String> {
    vec![field.to_string()]
}

fn branch(range: &Range) -> DocumentFilter {
    DocumentFilter::And(vec![
        DocumentFilter::Equal {
            path: path("tenant"),
            value: range.tenant.into(),
        },
        DocumentFilter::Compare {
            path: path("tag"),
            comparison: if range.low_inclusive {
                Comparison::GreaterOrEqual
            } else {
                Comparison::Greater
            },
            value: IndexValue::Integer(range.low),
        },
        DocumentFilter::Compare {
            path: path("tag"),
            comparison: if range.high_inclusive {
                Comparison::LessOrEqual
            } else {
                Comparison::Less
            },
            value: IndexValue::Integer(range.high),
        },
        DocumentFilter::Equal {
            path: path("visible"),
            value: range.visible.into(),
        },
    ])
}

fn in_range(row: &Row, range: &Range) -> bool {
    row.tenant == range.tenant
        && (row.tag > range.low || (row.tag == range.low && range.low_inclusive))
        && (row.tag < range.high || (row.tag == range.high && range.high_inclusive))
}

fn compare(db: DocumentDatabase<'_>, backend: &str) -> io::Result<()> {
    const SEED: u64 = 0x3047_bba9_e8d1_c26e;
    let mut rng = SEED;
    db.create_collection("items", CollectionSchema::default())?;
    db.create_index(
        "items",
        IndexDefinition {
            name: "tenant_tag".into(),
            fields: vec![path("tenant"), path("tag")],
            unique: false,
            partial: None,
        },
    )?;
    let rows: Vec<_> = (0..96)
        .map(|_| Row {
            tenant: draw(&mut rng, 3),
            tag: draw(&mut rng, 65) as i64 - 32,
            visible: draw(&mut rng, 2) == 0,
        })
        .collect();
    db.transaction(|tx| {
        for (i, row) in rows.iter().enumerate() {
            let doc = format!(
                r#"{{"tenant":{},"tag":{},"visible":{}}}"#,
                row.tenant, row.tag, row.visible
            )
            .parse()
            .unwrap();
            tx.insert("items", &format!("r{i:03}"), &doc)?;
        }
        Ok(())
    })?;
    let mut reduced = 0;
    let mut candidates = 0;
    for case in 0..512 {
        let ranges: Vec<_> = (0..(2 + draw(&mut rng, 6)))
            .map(|_| {
                let low = draw(&mut rng, 77) as i64 - 38;
                Range {
                    tenant: draw(&mut rng, 3),
                    low,
                    high: low + 3 + draw(&mut rng, 50) as i64,
                    low_inclusive: draw(&mut rng, 2) == 0,
                    high_inclusive: draw(&mut rng, 2) == 0,
                    visible: draw(&mut rng, 2) == 0,
                }
            })
            .collect();
        let candidate_count = rows
            .iter()
            .filter(|row| ranges.iter().any(|range| in_range(row, range)))
            .count();
        let expected = rows
            .iter()
            .enumerate()
            .filter(|(_, row)| {
                ranges
                    .iter()
                    .any(|range| in_range(row, range) && row.visible == range.visible)
            })
            .map(|(i, _)| format!("r{i:03}"))
            .collect::<Vec<_>>();
        let query = DocumentQuery {
            filter: DocumentFilter::Or(ranges.iter().map(branch).collect()),
            max_scanned: candidate_count.max(1),
            limit: 96,
            projection: Some(vec![path("tag")]),
            ..Default::default()
        };
        let planned = db
            .query_planned("items", &query)
            .unwrap_or_else(|err| panic!("{backend} case {case}: {err}"));
        let oracle = db.query(
            "items",
            &DocumentQuery {
                max_scanned: 96,
                ..query
            },
        )?;
        assert_eq!(
            planned.result.documents, oracle.documents,
            "{backend} case {case}"
        );
        assert_eq!(
            planned
                .result
                .documents
                .iter()
                .map(|entry| &entry.id)
                .collect::<Vec<_>>(),
            expected.iter().collect::<Vec<_>>(),
            "{backend} case {case}"
        );
        assert_eq!(
            planned.result.plan.scanned, candidate_count,
            "{backend} case {case}"
        );
        let DocumentQueryAccess::DisjunctionIndex { probes, .. } = planned.access else {
            panic!("{backend} case {case}: expected index union");
        };
        reduced += usize::from(probes < ranges.len());
        candidates += candidate_count;
    }
    println!(
        "{backend} seed={SEED:016x} cases=512 reduced_probes={reduced} candidates={candidates}"
    );
    Ok(())
}

fn main() -> io::Result<()> {
    let args: Vec<_> = std::env::args_os().collect();
    let root = Path::new(&args[1]);
    let store = Store::open(root.join("ordinary"))?;
    compare(DocumentDatabase::new(&store), "ordinary")?;
    let path = root.join("checkpointed");
    let checkpoint = root.join("index");
    let store = Store::open(&path)?;
    let digest = store.checkpoint_to(&checkpoint)?;
    drop(store);
    let store = CheckpointStore::open(&path, &checkpoint, &digest)?;
    compare(
        DocumentDatabase::with_checkpoint_store(&store),
        "checkpoint",
    )
}
