#!/bin/sh
set -eu
root=$(dirname "$0")
python3 "$root/verify-hosted.py" "$root" 42c8c346263522f6be47e1db30145f228461da81 45446141001 45446140960 45446141071 45446140969 45446140953 macos-focused.log 63 overlapping_disjunct_ranges_charge_one_visit_for_the_same_index_entry merged_compound_disjunction_paginates_within_its_equality_prefix
for backend in ordinary checkpoint; do
  grep -Fxq "$backend seed=3047bba9e8d1c26e cases=512 reduced_probes=367 candidates=17599" "$root/native/model.log"
done
test "$(cat "$root/native/baseline.exit")" -eq 101
grep -Fq 'document scan exceeds the operation limit' "$root/native/baseline.log"
printf '%s\n' 'All 1,024 generated comparisons matched the exact model and collection scan' 'Previous revision rejected the exact candidate budget'
