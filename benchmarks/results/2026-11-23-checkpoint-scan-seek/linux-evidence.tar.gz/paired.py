"""Pair warm historical scans over identical checkpoint fixtures."""
import argparse
import json
from pathlib import Path
from statistics import median
import subprocess
import tempfile


def run(args):
    return subprocess.run(args, capture_output=True, check=True, text=True, timeout=60).stdout


def paired(workspace):
    rows = []
    for width, modes in [(4, ("early", "late")), (128, ("wide",))]:
        with tempfile.TemporaryDirectory(prefix=f"key-width-{width}-", dir=workspace) as owned:
            fixture = str(Path(owned) / "fixture")
            run([str(workspace / "baseline"), "prepare", fixture, str(width)])
            for mode in modes:
                for pair in range(7):
                    order = ("baseline", "candidate") if pair % 2 == 0 else ("candidate", "baseline")
                    allocations = {}
                    for build in order:
                        result = run([str(workspace / build), mode, fixture, str(width)])
                        fields = dict(item.split("=") for item in result.split())
                        assert fields["mode"] == mode and int(fields["width"]) == width
                        allocations[build] = int(fields["allocations"])
                        rows.append({
                            "mode": mode, "width": width, "build": build, "pair": pair,
                            "allocations": allocations[build], "per_page_ns": int(fields["per_page_ns"]),
                        })
                    expected_saved = 4 if mode == "wide" else 0
                    assert allocations["baseline"] - allocations["candidate"] == expected_saved, allocations
    for mode in ("early", "late", "wide"):
        for build in ("baseline", "candidate"):
            samples = [row for row in rows if row["mode"] == mode and row["build"] == build]
            print(mode, build, samples[0]["allocations"], median(row["per_page_ns"] for row in samples))
    return rows


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("workspace", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    rows = paired(args.workspace.resolve())
    with args.output.open("x") as file:
        json.dump(rows, file, indent=2)
        file.write("\n")
