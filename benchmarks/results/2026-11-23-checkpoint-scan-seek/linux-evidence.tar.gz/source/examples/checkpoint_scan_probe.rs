use database_engine::{BatchOperation, CheckpointView, Store};
use std::alloc::{GlobalAlloc, Layout, System};
use std::fs;
use std::io;
use std::path::Path;
use std::sync::atomic::{AtomicUsize, Ordering};
use std::time::Instant;

static ALLOCATION_CALLS: AtomicUsize = AtomicUsize::new(0);

struct CountingAllocator;

#[global_allocator]
static GLOBAL: CountingAllocator = CountingAllocator;

// Counting does not change the allocation contract. System performs allocation,
// deallocation and reallocation with the caller's original pointer and layout.
unsafe impl GlobalAlloc for CountingAllocator {
    unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
        ALLOCATION_CALLS.fetch_add(1, Ordering::Relaxed);
        unsafe { System.alloc(layout) }
    }

    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        ALLOCATION_CALLS.fetch_add(1, Ordering::Relaxed);
        unsafe { System.alloc_zeroed(layout) }
    }

    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, size: usize) -> *mut u8 {
        ALLOCATION_CALLS.fetch_add(1, Ordering::Relaxed);
        unsafe { System.realloc(ptr, layout, size) }
    }

    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout) {
        unsafe { System.dealloc(ptr, layout) }
    }
}

const ENTRIES: u64 = 4096;

fn key(id: u64, width: usize) -> Vec<u8> {
    let mut key = (id as u32).to_be_bytes().to_vec();
    key.resize(width, 0x5a);
    key
}

fn prepare(path: &Path, width: usize) -> io::Result<()> {
    fs::create_dir(path)?;
    let store = Store::open(path.join("store"))?;
    for start in (0..ENTRIES).step_by(256) {
        let rows: Vec<_> = (start..(start + 256).min(ENTRIES))
            .map(|id| (key(id, width), id.to_le_bytes()))
            .collect();
        let batch: Vec<_> = rows
            .iter()
            .map(|(key, value)| BatchOperation::Put { key, value })
            .collect();
        store.write_batch(&batch)?;
    }
    let digest = store.checkpoint_to(path.join("index"))?;
    fs::write(path.join("digest"), digest)
}

fn measure(path: &Path, width: usize, mode: &str) -> io::Result<()> {
    let digest = fs::read(path.join("digest"))?
        .try_into()
        .map_err(|_| io::Error::other("invalid fixture digest"))?;
    let view = CheckpointView::open(path.join("store"), path.join("index"), &digest)?;
    let (after, page, loops) = match mode {
        "early" => (7, 1, 2000),
        "late" => (
            (database_engine::MAX_CHECKPOINT_VIEW_BLOCK_BYTES / (18 + width) - 8) as u64,
            1,
            2000,
        ),
        "wide" => (7, 1024, 100),
        _ => return Err(io::Error::other("invalid scan mode")),
    };
    let lower = key(after, width);
    let expected: Vec<_> = (after + 1..=after + page as u64)
        .map(|id| (key(id, width), id.to_le_bytes().to_vec()))
        .collect();
    assert_eq!(view.scan(Some(&lower), None, page)?, expected);
    let before = ALLOCATION_CALLS.load(Ordering::Relaxed);
    let start = Instant::now();
    for _ in 0..loops {
        let result = view.scan(Some(&lower), None, page)?;
        assert_eq!(result, expected);
    }
    let elapsed = start.elapsed();
    let allocations = ALLOCATION_CALLS.load(Ordering::Relaxed) - before;
    assert_eq!(allocations % loops, 0);
    println!(
        "mode={mode} width={width} allocations={} per_page_ns={}",
        allocations / loops,
        elapsed.as_nanos() / loops as u128
    );
    Ok(())
}

fn main() -> io::Result<()> {
    let args: Vec<_> = std::env::args().collect();
    let [_, mode, fixture, width] = args.as_slice() else {
        return Err(io::Error::other(
            "expected mode, fixture path and key width",
        ));
    };
    let width = width.parse::<usize>().map_err(io::Error::other)?;
    if !matches!(width, 4 | 128) {
        return Err(io::Error::other("expected four- or 128-byte keys"));
    }
    let fixture = Path::new(fixture);
    if mode == "prepare" {
        prepare(fixture, width)
    } else {
        measure(fixture, width, mode)
    }
}
