import csv
import json
import math
import statistics
import sys
from pathlib import Path

root = Path(sys.argv[1])
attempt = json.loads((root / "attempt.json").read_text())
assert attempt["status"] == "exited" and attempt["returncode"] == attempt["wrapper_exit_code"] == 0
assert attempt["revision"] == sys.argv[2]
lines = (root / attempt["output"]).read_text().splitlines()
fixture = lines[0]
assert fixture.endswith("source_rows=1024 targets=16 matched_rows=16 missing_targets=1 scan_visits=1024 planned_visits=16"), fixture
plans = [row for row in lines if row.startswith("sqlite_plan=")]
assert any("by_bucket" in row for row in plans) and any("by_code" in row for row in plans), plans
header = lines.index("round,case,sample,elapsed_ns")
rows = list(csv.DictReader(lines[header:]))
print(fixture)
assert len(rows) == 540
for case in ("emda-scan", "emda-planned", "sqlite"):
    selected = [row for row in rows if row["case"] == case]
    assert len(selected) == 180
    assert {(int(row["round"]), int(row["sample"])) for row in selected} == {
        (round_number, sample) for round_number in range(9) for sample in range(20)
    }
    times = sorted(int(row["elapsed_ns"]) for row in selected)
    assert times[0] > 0
    print(f"{case}: samples={len(times)} median_us={statistics.median(times)/1000:.2f} p95_us={times[math.ceil(.95*len(times))-1]/1000:.2f}")
