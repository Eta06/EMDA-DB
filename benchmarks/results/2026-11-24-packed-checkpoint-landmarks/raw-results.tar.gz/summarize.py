from collections import Counter
import csv
from pathlib import Path
import sys

root = Path(sys.argv[1])
cases = {}
rounds = Counter()
for path in sorted(root.glob("*.log")):
    fixture, round_number, build = path.stem.split("-")
    assert round_number in ("1", "2", "3")
    status, *fields = path.read_text().strip().split()
    assert status == "verified"
    values = {key: int(value) for field in fields for key, value in [field.split("=")]}
    case = fixture, build
    assert cases.setdefault(case, values) == values, case
    rounds[case] += 1
assert len(rounds) == 6 and all(count == 3 for count in rounds.values())
writer = csv.writer(sys.stdout)
writer.writerow(("fixture", "keys", "key_bytes", "blocks", "baseline_requests",
                 "candidate_requests", "baseline_requested", "candidate_requested",
                 "baseline_live", "candidate_live"))
for fixture in ("small", "dense", "wide"):
    baseline = cases[fixture, "baseline"]
    candidate = cases[fixture, "candidate"]
    dimensions = ("keys", "key_bytes", "blocks")
    metrics = ("allocation_requests", "requested_bytes", "live_requested_bytes")
    assert all(baseline[key] == candidate[key] for key in dimensions)
    assert all(baseline[key] > candidate[key] for key in metrics)
    writer.writerow([fixture] + [baseline[key] for key in dimensions]
                    + [values[key] for key in metrics for values in (baseline, candidate)])
