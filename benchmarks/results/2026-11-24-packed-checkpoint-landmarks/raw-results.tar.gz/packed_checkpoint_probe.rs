use database_engine::{BatchOperation, CheckpointView, CheckpointViewLimits, Store};
use std::alloc::{GlobalAlloc, Layout, System};
use std::sync::atomic::{AtomicUsize, Ordering::Relaxed};
use std::{env, fs, io, path::Path};

struct Counted;
static REQUESTS: AtomicUsize = AtomicUsize::new(0);
static TOTAL: AtomicUsize = AtomicUsize::new(0);
static LIVE: AtomicUsize = AtomicUsize::new(0);

unsafe impl GlobalAlloc for Counted {
    unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
        let pointer = unsafe { System.alloc(layout) };
        if !pointer.is_null() {
            REQUESTS.fetch_add(1, Relaxed);
            TOTAL.fetch_add(layout.size(), Relaxed);
            LIVE.fetch_add(layout.size(), Relaxed);
        }
        pointer
    }
    unsafe fn dealloc(&self, pointer: *mut u8, layout: Layout) {
        LIVE.fetch_sub(layout.size(), Relaxed);
        unsafe { System.dealloc(pointer, layout) };
    }
    unsafe fn realloc(&self, pointer: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
        let pointer = unsafe { System.realloc(pointer, layout, new_size) };
        if !pointer.is_null() {
            REQUESTS.fetch_add(1, Relaxed);
            TOTAL.fetch_add(new_size, Relaxed);
            LIVE.fetch_sub(layout.size(), Relaxed);
            LIVE.fetch_add(new_size, Relaxed);
        }
        pointer
    }
}

#[global_allocator]
static ALLOCATOR: Counted = Counted;

fn key(n: usize, width: usize) -> Vec<u8> {
    let mut key = vec![7; width];
    key[..8].copy_from_slice(&(n as u64).to_be_bytes());
    key
}

fn main() -> io::Result<()> {
    let args: Vec<_> = env::args().skip(1).collect();
    let path = Path::new(&args[1]);
    let count = args[2].parse::<usize>().unwrap();
    let width = args[3].parse::<usize>().unwrap();
    let live = path.join("live");
    let index = path.join("index");
    let receipt = path.join("digest");
    if args[0] == "setup" {
        fs::create_dir(path)?;
        let store = Store::open(&live)?;
        for start in (0..count).step_by(256) {
            let keys: Vec<_> = (start..count.min(start + 256)).map(|n| key(n, width)).collect();
            let operations: Vec<_> = keys.iter().map(|key| BatchOperation::Put { key, value: b"v" }).collect();
            store.write_batch(&operations)?;
        }
        fs::write(receipt, store.checkpoint_to(&index)?)?;
        return Ok(());
    }
    let digest: [u8; 32] = fs::read(receipt)?.try_into().unwrap();
    let blocks = count.div_ceil(32_768 / (18 + width));
    let limits = CheckpointViewLimits {
        max_file_bytes: index.metadata()?.len(),
        max_blocks: blocks,
    };
    let live_before = LIVE.load(Relaxed);
    REQUESTS.store(0, Relaxed);
    TOTAL.store(0, Relaxed);
    let view = CheckpointView::open_with_limits(&live, &index, &digest, limits)?;
    let requests = REQUESTS.load(Relaxed);
    let requested = TOTAL.load(Relaxed);
    let retained = LIVE.load(Relaxed) - live_before;
    assert_eq!(view.block_count(), blocks);
    assert_eq!(view.len(), count as u64);
    for n in (0..count).step_by((count / 37).max(1)).chain([count - 1]) {
        assert_eq!(view.get(&key(n, width))?.as_deref(), Some(b"v".as_slice()));
    }
    let middle = count / 2;
    let rows = view.scan(Some(&key(middle, width)), None, 17)?;
    assert_eq!(rows.len(), 17);
    for (n, (actual, value)) in rows.iter().enumerate() {
        assert_eq!(actual, &key(middle + n + 1, width));
        assert_eq!(value, b"v");
    }
    println!("verified keys={count} key_bytes={width} blocks={blocks} allocation_requests={requests} requested_bytes={requested} live_requested_bytes={retained}");
    Ok(())
}
