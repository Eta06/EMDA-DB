#!/bin/sh
set -eu
root=$(dirname "$0")
python3 "$root/verify-hosted.py" "$root" 9146b41685d3a1a19e36083dd34778dd31d2e847 45455762649 45455762664 45455762951 45455762603 45455762749 macos-focused.log 24 readonly_combined_scan_ceiling_charges_only_the_viewed_log_range
