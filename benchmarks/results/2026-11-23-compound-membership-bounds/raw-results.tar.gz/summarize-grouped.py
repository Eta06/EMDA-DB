"""Check query paths and summarize per-process median latencies."""
from collections import defaultdict
import json
from pathlib import Path
from statistics import median
import sys


def latency(rows, metric):
    assert all(len(row[metric]) == 100 and min(row[metric]) > 0 for row in rows)
    values = [median(row[metric]) / 1000 for row in rows]
    return f"{median(values):.2f} ({min(values):.2f}–{max(values):.2f})"


for platform, filename in zip(("macOS", "Linux ARM64"), sys.argv[1:]):
    groups = defaultdict(list)
    for line in Path(filename).read_text().splitlines():
        row = json.loads(line)
        assert row["sqlite_version"] == "3.49.1"
        assert any("SEARCH docs USING INDEX docs_tenant_score" in step for step in row["sqlite_plan"])
        groups[row["case"], row["variant"]].append(row)
    assert len(groups) == 6
    for case, matches, expanded_probes, grouped_probes in (
        ("sparse", 8, 16, 16), ("dense", 128, 256, 2), ("range-only", 128, 2, 2),
    ):
        before = groups[case, "candidate"]
        after = groups[case, "optimized"]
        for rows, probes in ((before, expanded_probes), (after, grouped_probes)):
            assert sorted(row["pair"] for row in rows) == list(range(9))
            assert {row["matches"] for row in rows} == {matches}
            assert {row["candidates"] for row in rows} == {matches}
            access = "CompoundMembershipRangeIndex" if probes == 2 else "CompoundMembershipIndex"
            assert all(access in row["emda_access"] and f"probes: {probes}" in row["emda_access"] for row in rows)
        print(
            f"| {platform} | {case} | {expanded_probes} → {grouped_probes} | {matches} | "
            f"{latency(before, 'emda_ns')} | {latency(after, 'emda_ns')} | "
            f"{latency(after, 'sqlite_ns')} |"
        )
