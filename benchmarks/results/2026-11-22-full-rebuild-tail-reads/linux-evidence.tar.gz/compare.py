"""Compare full-log rebuild source reads with identical fixture histories."""
import argparse
import json
import os
from pathlib import Path
import re
import subprocess
import tempfile

SOURCE_READ = re.compile(r"^pread64\(\d+<[^>]+/store/records\.log>,.* = (\d+)$")


def run(args, **kwargs):
    return subprocess.run(args, capture_output=True, check=True, text=True, timeout=30, **kwargs).stdout


def compare(workspace, evidence):
    evidence.mkdir()
    rows = []
    for prefix in ("small", "large"):
        for format_name in ("v2", "v3"):
            for tail in ("acked", "tail"):
                results = {}
                for build in ("baseline", "candidate"):
                    label = f"{prefix}-{format_name}-{tail}-{build}"
                    with tempfile.TemporaryDirectory(prefix=label + "-", dir=workspace) as directory:
                        root = Path(directory)
                        binary = workspace / build
                        args = [str(root), format_name, tail]
                        def program(action):
                            return [str(binary), action, *args]

                        env = os.environ.copy()
                        env.pop("EMDA_REBUILD_LARGE_PREFIX", None)
                        if prefix == "large":
                            env["EMDA_REBUILD_LARGE_PREFIX"] = "1"
                        run(program("prepare"), env=env)
                        log = root / "store/records.log"
                        original = log.read_bytes()
                        trace = evidence / (label + ".strace")
                        assert run([
                            "strace", "-qq", "-yy", "-s", "0", "-o", str(trace),
                            "-e", "trace=pread64", *program("attempt"),
                        ]).strip() == "published"
                        assert run(program("verify")).startswith("reference matches")
                        assert log.read_bytes() == original
                        lengths = [
                            int(match[1]) for line in trace.read_text().splitlines()
                            if (match := SOURCE_READ.search(line))
                        ]
                        results[build] = sum(lengths)
                        rows.append({
                            "build": build, "prefix": prefix, "format": format_name,
                            "tail": tail, "log_bytes": len(original),
                            "read_calls": len(lengths), "source_bytes_read": sum(lengths),
                        })
                expected = len(original) if tail == "tail" else 0
                assert results["baseline"] - results["candidate"] == expected, (
                    prefix, format_name, tail, results, expected
                )
    (evidence / "source-reads.json").write_text(json.dumps(rows, indent=2) + "\n")
    print(f"{len(rows)} reference-checked controls; exact source-read reduction verified.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("workspace", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    compare(args.workspace.resolve(), args.output.resolve())
