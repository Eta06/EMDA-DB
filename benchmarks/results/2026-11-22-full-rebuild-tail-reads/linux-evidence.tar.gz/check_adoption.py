"""Check pre-publication EIO witness results against traced witness writes."""
import argparse
from collections import Counter
import json
from pathlib import Path
import re
import subprocess
import tempfile


def run(args):
    return subprocess.run(args, capture_output=True, check=True, text=True, timeout=30).stdout


def check(workspace):
    summary = Counter()
    for format_name in ("v2", "v3"):
        for tail in ("acked", "tail"):
            label = f"{format_name}-{tail}"
            with tempfile.TemporaryDirectory(prefix=label + "-ordering-", dir=workspace) as name:
                root = Path(name)
                trace = workspace / (label + "-ordering.strace")

                def command(action):
                    return [str(workspace / "candidate"), action, str(root), format_name, tail]

                run(command("prepare"))
                assert run([
                    "strace", "-qq", "-yy", "-o", str(trace),
                    "-e", "trace=pread64,pwrite64,fsetxattr,fdatasync,fsync,rename,renameat,renameat2",
                    *command("attempt"),
                ]).strip() == "published"
                assert run(command("verify")).startswith("reference matches")
                ordinal = 0
                saw_witness_write = False
                source_reads = {}
                for line in trace.read_text().splitlines():
                    if f'"{root / "result"}"' in line and re.match(r"rename(at2?)?\(", line):
                        assert line.endswith("= 0"), line
                        break
                    if line.startswith("pwrite64(") and "/store/commit.state>" in line:
                        assert format_name == "v2" and not saw_witness_write, line
                        saw_witness_write = True
                    elif line.startswith("fsetxattr(") and "/store/records.log>" in line:
                        assert format_name == "v3" and not saw_witness_write, line
                        saw_witness_write = True
                    elif line.startswith("pread64("):
                        ordinal += 1
                        if "/store/records.log>" in line:
                            source_reads[ordinal] = saw_witness_write
                else:
                    raise AssertionError("checkpoint was not published")
                assert saw_witness_write == (tail == "tail")
                for fault in ("EIO", "EINTR"):
                    records = workspace / fault / (label + "-injections.jsonl")
                    cases = [json.loads(line) for line in records.read_text().splitlines()]
                    assert sorted(case["ordinal"] for case in cases) == sorted(source_reads)
                    for case in cases:
                        if fault == "EIO":
                            assert not case["published"], case
                            advanced = source_reads[case["ordinal"]]
                            assert case["witness_advanced"] == advanced, case
                            summary["EIO after witness write" if advanced else "EIO before witness write"] += 1
                        else:
                            assert case["published"], case
                            summary["EINTR resumed"] += 1
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("workspace", type=Path)
    args = parser.parse_args()
    check(args.workspace.resolve())
