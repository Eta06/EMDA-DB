"""Pair historical-view opens over one read-only fixture per key count."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess
import tempfile

INDEX_READ = re.compile(r"^(?:read|pread64)\(\d+<[^>]+/index>,.* = (\d+)$")


def run(args):
    return subprocess.run(args, check=True, capture_output=True, text=True, timeout=60).stdout


def contents(path):
    files = [path / "index", path / "digest", path / "store/records.log", path / "store/commit.state"]
    return {str(file.relative_to(path)): hashlib.sha256(file.read_bytes()).hexdigest() for file in files}


def paired(workspace, evidence):
    evidence.mkdir()
    rows = []
    for keys in (4096, 65536):
        with tempfile.TemporaryDirectory(prefix=f"keys-{keys}-", dir=workspace) as owned:
            fixture = Path(owned) / "fixture"
            args = [str(fixture), str(keys)]
            run([str(workspace / "baseline"), "prepare", *args])
            before = contents(fixture)
            for pair in range(5):
                order = ("baseline", "candidate") if pair % 2 == 0 else ("candidate", "baseline")
                allocations = {}
                for variant in order:
                    output = run([str(workspace / variant), "measure", *args])
                    sample = {key: int(value) for key, value in (part.split("=") for part in output.split())}
                    assert sample["keys"] == keys
                    allocations[variant] = sample["allocations"]
                    rows.append({"build": variant, "pair": pair, **sample})
                assert allocations["baseline"] - allocations["candidate"] == keys, allocations

            reads = {}
            for variant in ("baseline", "candidate"):
                trace = evidence / f"{keys}-{variant}.strace"
                run([
                    "strace", "-qq", "-yy", "-s", "0", "-o", str(trace),
                    "-e", "trace=read,pread64,fcntl,lseek",
                    str(workspace / variant), "measure", *args,
                ])
                lines = trace.read_text().splitlines()
                scoped = [line for line in lines if "/index>" in line]
                reads[variant] = sum(int(match[1]) for line in scoped if (match := INDEX_READ.match(line)))
                duplicates = sum(line.startswith("fcntl(") and "F_DUPFD" in line for line in scoped)
                seeks = sum(line.startswith("lseek(") for line in scoped)
                assert duplicates == seeks == int(variant == "baseline"), scoped[:5]
            assert reads["baseline"] == reads["candidate"] >= (fixture / "index").stat().st_size
            assert contents(fixture) == before
    (evidence / "opens.json").write_text(json.dumps(rows, indent=2) + "\n")
    print(f"Verified {len(rows)} opens, four index traces and two fixture hashes")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("workspace", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    paired(args.workspace.resolve(), args.output.resolve())
