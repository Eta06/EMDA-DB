use database_engine::{CheckpointStore, CheckpointView, RecoveredCheckpointView, Store};
use std::{fs, io, path::PathBuf};

fn rejected<T>(name: &str, result: io::Result<T>) {
    let error = result.err().expect("previous engine opened the fenced store");
    assert!(matches!(error.kind(), io::ErrorKind::InvalidData | io::ErrorKind::Unsupported), "{error}");
    println!("{name} rejected fenced store: {error}");
}

fn main() {
    let root = PathBuf::from(std::env::args_os().nth(1).unwrap());
    let path = root.join("source");
    let checkpoint = root.join("checkpoint");
    let digest: [u8; 32] = fs::read(root.join("digest")).unwrap().try_into().unwrap();
    rejected("Store::open", Store::open(&path));
    rejected("Store::open_with_checkpoint", Store::open_with_checkpoint(&path, &checkpoint, &digest));
    rejected("CheckpointStore::open", CheckpointStore::open(&path, &checkpoint, &digest));
    rejected("CheckpointView::open", CheckpointView::open(&path, &checkpoint, &digest));
    rejected("RecoveredCheckpointView::open", RecoveredCheckpointView::open(&path, &checkpoint, &digest));
}
