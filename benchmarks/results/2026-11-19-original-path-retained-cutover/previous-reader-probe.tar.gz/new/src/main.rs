use database_engine::retained_base_v2::Limits;
use database_engine::retained_candidate::{
    IndexLimits, OverlayLimits, RetainedStoreLimits, SuffixLimits,
};
const LIMITS: RetainedStoreLimits = RetainedStoreLimits {
    base: Limits { file_bytes: 8192, entries: 32, key_bytes: 256, work_bytes: 8193 },
    index: IndexLimits { blocks: 4, anchor_bytes: 64 },
    suffix: SuffixLimits { bytes: 8192, operations: 64, work: 4096 },
    overlay: OverlayLimits { entries: 32, key_bytes: 256 },
};
use database_engine::{RetainedExportLimits, Store};
use database_engine::retained_candidate::{AuthorizedRetainedStore, FileRetainedAuthority, RetainedAuthority};
use std::{fs, path::PathBuf};

fn main() {
    let root = PathBuf::from(std::env::args_os().nth(1).unwrap());
    let source = root.join("source");
    let authority = root.join("authority");
    if std::env::args().nth(2).as_deref() == Some("verify") {
        let provider = FileRetainedAuthority::open(authority).unwrap();
        let mut store = AuthorizedRetainedStore::open(source, LIMITS, provider).unwrap();
        assert_eq!(store.get(b"verified", 32).unwrap().unwrap(), b"value");
        println!("current authorized reader recovered the value at the original path");
        return;
    }
    let store = Store::open(&source).unwrap();
    store.put(b"verified", b"value").unwrap();
    let digest = store.checkpoint_to(root.join("checkpoint")).unwrap();
    fs::write(root.join("digest"), digest).unwrap();
    let prepared = AuthorizedRetainedStore::<FileRetainedAuthority>::cutover_from_store(
        store, &source,
        RetainedExportLimits {
            max_log_bytes: 8192, max_live_keys: 32,
            max_live_key_bytes: 256, max_output_bytes: 8192,
        }, LIMITS,
    ).unwrap();
    let mut provider = FileRetainedAuthority::create(authority).unwrap();
    assert!(provider.compare_and_swap(None, prepared).unwrap());
    assert_eq!(&fs::read(source.join("records.log")).unwrap()[..8], b"EMDALOG4");
    println!("fenced the original source path and registered revision {}", prepared.revision);
}
