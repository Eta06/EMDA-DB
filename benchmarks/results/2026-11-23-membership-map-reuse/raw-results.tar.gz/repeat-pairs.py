"""Use the same synchronized, reopened fixture for both revisions."""
import json
from pathlib import Path
import subprocess
import sys
import tempfile

baseline, candidate, parent = map(Path, sys.argv[1:])
with tempfile.TemporaryDirectory(dir=parent) as fixture:
    subprocess.run([baseline, "seed", fixture], check=True, timeout=180)
    for pair in range(9):
        variants = [("baseline", baseline), ("candidate", candidate)]
        if pair % 2:
            variants.reverse()
        for variant, binary in variants:
            out = subprocess.check_output(
                [binary, "run", fixture, "candidate", str(pair)], text=True, timeout=60
            )
            rows = [json.loads(line) for line in out.splitlines()]
            assert {row["case"] for row in rows} == {"sparse-overlap", "full-overlap", "single-list"}
            for row in rows:
                assert row["variant"] == "candidate"
                assert len(row["sqlite_ns"]) == len(row["emda_ns"]) == 100
                print(json.dumps({**row, "pair": pair, "variant": variant}), flush=True)
