"""Validate coverage and summarize per-process median latencies."""
from collections import defaultdict
import json
from pathlib import Path
from statistics import median
import sys

CASES = {
    "sparse-overlap": (8, 8),
    "full-overlap": (96, 96),
    "single-list": (8, 8),
}


def report(rows, metric):
    assert all(len(row[metric]) == 100 and min(row[metric]) > 0 for row in rows)
    values = [median(row[metric]) / 1000 for row in rows]
    return f"{median(values):.2f} ({min(values):.2f}–{max(values):.2f})"


assert len(sys.argv) == 3, "usage: summarize.py macos.jsonl linux.jsonl"
for platform, filename in zip(("macOS", "Linux ARM64"), sys.argv[1:]):
    groups = defaultdict(list)
    for line in Path(filename).read_text().splitlines():
        row = json.loads(line)
        assert row["sqlite_version"] == "3.49.1"
        assert any("SEARCH docs USING INDEX docs_tenant_score" in step for step in row["sqlite_plan"])
        groups[row["case"], row["variant"]].append(row)
    assert len(groups) == 6
    for case, (initial, overlap) in CASES.items():
        before = groups[case, "baseline"]
        after = groups[case, "candidate"]
        for rows, candidates in ((before, initial), (after, overlap)):
            assert sorted(row["pair"] for row in rows) == list(range(9))
            assert {row["matches"] for row in rows} == {overlap}
            assert {row["candidates"] for row in rows} == {candidates}
        print(
            f"| {platform} | {case} | {initial} → {overlap} | "
            f"{report(before, 'emda_ns')} | {report(after, 'emda_ns')} | "
            f"{report(after, 'sqlite_ns')} |"
        )
