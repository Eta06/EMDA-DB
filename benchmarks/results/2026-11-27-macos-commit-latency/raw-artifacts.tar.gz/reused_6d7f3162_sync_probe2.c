#include <errno.h>
#include <fcntl.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/xattr.h>
#include <time.h>
#include <unistd.h>

static uint64_t now_ns(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (uint64_t)ts.tv_sec * 1000000000ULL + (uint64_t)ts.tv_nsec;
}

static int cmp_u64(const void *a, const void *b) {
    uint64_t x = *(const uint64_t *)a;
    uint64_t y = *(const uint64_t *)b;
    return (x > y) - (x < y);
}

static void report(const char *label, uint64_t *samples, int n) {
    uint64_t *copy = malloc(n * sizeof(uint64_t));
    memcpy(copy, samples, n * sizeof(uint64_t));
    qsort(copy, n, sizeof(uint64_t), cmp_u64);
    double sum = 0;
    for (int i = 0; i < n; i++) sum += (double)copy[i];
    double p10 = (double)copy[(n - 1) * 10 / 100] / 1000.0;
    double p50 = (double)copy[(n - 1) * 50 / 100] / 1000.0;
    double p90 = (double)copy[(n - 1) * 90 / 100] / 1000.0;
    double p99 = (double)copy[(n - 1) * 99 / 100] / 1000.0;
    double avg = (sum / n) / 1000.0;
    double mx = (double)copy[n - 1] / 1000.0;
    printf("%-42s avg=%6.1f p10=%6.1f p50=%6.1f p90=%6.1f p99=%6.1f max=%6.1f us\n",
           label, avg, p10, p50, p90, p99, mx);
    free(copy);
}

static void die(const char *msg) {
    perror(msg);
    exit(1);
}

int main(int argc, char **argv) {
    if (argc < 2) {
        fprintf(stderr, "usage: %s <dir> [rounds]\n", argv[0]);
        return 1;
    }
    const char *dir = argv[1];
    int rounds = argc >= 3 ? atoi(argv[2]) : 100;
    const int CASES = 7;
    uint64_t *s[7];
    for (int c = 0; c < CASES; c++) s[c] = calloc(rounds, sizeof(uint64_t));

    char paths[7][512];
    int fds[7];
    int wit_fds[7];
    uint8_t rec[128], wit[36], wit_rd[36];
    memset(rec, 0xAB, sizeof(rec));
    memset(wit, 0xCD, sizeof(wit));
    const char *xname = "user.db.commit.v3";

    for (int c = 0; c < CASES; c++) {
        snprintf(paths[c], sizeof(paths[c]), "%s/case%d.log", dir, c);
        fds[c] = open(paths[c], O_RDWR | O_CREAT | O_TRUNC | O_APPEND, 0644);
        if (fds[c] < 0) die("open log");
        char wp[512];
        snprintf(wp, sizeof(wp), "%s/case%d.wit", dir, c);
        wit_fds[c] = open(wp, O_RDWR | O_CREAT | O_TRUNC, 0644);
        if (wit_fds[c] < 0) die("open wit");
        if (pwrite(wit_fds[c], wit, sizeof(wit), 0) != sizeof(wit)) die("init wit");
        if (fsetxattr(fds[c], xname, wit, sizeof(wit), 0, XATTR_CREATE) < 0) die("init xattr");
        if (fcntl(fds[c], F_FULLFSYNC) < 0) die("init sync log");
        if (fcntl(wit_fds[c], F_FULLFSYNC) < 0) die("init sync wit");
    }

    // Interleaved rounds: rotate starting case each round
    struct stat st;
    for (int r = 0; r < rounds; r++) {
        for (int k = 0; k < CASES; k++) {
            int c = (r + k) % CASES;
            uint64_t t0 = now_ns();
            switch (c) {
                case 0: // 1-file write + F_FULLFSYNC
                    if (write(fds[c], rec, sizeof(rec)) != sizeof(rec)) die("c0 write");
                    if (fcntl(fds[c], F_FULLFSYNC) < 0) die("c0 full");
                    break;
                case 1: // 1-file write + F_BARRIERFSYNC
                    if (write(fds[c], rec, sizeof(rec)) != sizeof(rec)) die("c1 write");
                    if (fcntl(fds[c], F_BARRIERFSYNC) < 0) die("c1 barrier");
                    break;
                case 2: // V2 current: 2x F_FULLFSYNC
                    if (fstat(fds[c], &st) < 0) die("c2");
                    if (fstat(wit_fds[c], &st) < 0) die("c2");
                    if (pread(wit_fds[c], wit_rd, sizeof(wit_rd), 0) != sizeof(wit_rd)) die("c2");
                    if (write(fds[c], rec, sizeof(rec)) != sizeof(rec)) die("c2");
                    if (fcntl(fds[c], F_FULLFSYNC) < 0) die("c2");
                    if (fstat(fds[c], &st) < 0) die("c2");
                    if (fstat(wit_fds[c], &st) < 0) die("c2");
                    if (pread(wit_fds[c], wit_rd, sizeof(wit_rd), 0) != sizeof(wit_rd)) die("c2");
                    wit[0] = (uint8_t)r;
                    if (pwrite(wit_fds[c], wit, sizeof(wit), 0) != sizeof(wit)) die("c2");
                    if (fcntl(wit_fds[c], F_FULLFSYNC) < 0) die("c2");
                    break;
                case 3: // V2 barrier + full (with current checks)
                    if (fstat(fds[c], &st) < 0) die("c3");
                    if (fstat(wit_fds[c], &st) < 0) die("c3");
                    if (pread(wit_fds[c], wit_rd, sizeof(wit_rd), 0) != sizeof(wit_rd)) die("c3");
                    if (write(fds[c], rec, sizeof(rec)) != sizeof(rec)) die("c3");
                    if (fcntl(fds[c], F_BARRIERFSYNC) < 0) die("c3");
                    if (fstat(fds[c], &st) < 0) die("c3");
                    if (fstat(wit_fds[c], &st) < 0) die("c3");
                    if (pread(wit_fds[c], wit_rd, sizeof(wit_rd), 0) != sizeof(wit_rd)) die("c3");
                    wit[0] = (uint8_t)r;
                    if (pwrite(wit_fds[c], wit, sizeof(wit), 0) != sizeof(wit)) die("c3");
                    if (fcntl(wit_fds[c], F_FULLFSYNC) < 0) die("c3");
                    break;
                case 4: // V2 barrier + full (minimal syscalls)
                    if (write(fds[c], rec, sizeof(rec)) != sizeof(rec)) die("c4");
                    if (fcntl(fds[c], F_BARRIERFSYNC) < 0) die("c4");
                    wit[0] = (uint8_t)r;
                    if (pwrite(wit_fds[c], wit, sizeof(wit), 0) != sizeof(wit)) die("c4");
                    if (fcntl(wit_fds[c], F_FULLFSYNC) < 0) die("c4");
                    break;
                case 5: // V3 xattr + F_FULLFSYNC (with full current checks)
                    if (fstat(fds[c], &st) < 0) die("c5");
                    if (fgetxattr(fds[c], xname, wit_rd, sizeof(wit_rd), 0, 0) != sizeof(wit_rd)) die("c5");
                    if (write(fds[c], rec, sizeof(rec)) != sizeof(rec)) die("c5");
                    if (fstat(fds[c], &st) < 0) die("c5");
                    if (fgetxattr(fds[c], xname, wit_rd, sizeof(wit_rd), 0, 0) != sizeof(wit_rd)) die("c5");
                    wit[0] = (uint8_t)r;
                    if (fsetxattr(fds[c], xname, wit, sizeof(wit), 0, XATTR_REPLACE) < 0) die("c5");
                    if (fcntl(fds[c], F_FULLFSYNC) < 0) die("c5");
                    break;
                case 6: // V3 xattr + F_FULLFSYNC (minimal)
                    if (write(fds[c], rec, sizeof(rec)) != sizeof(rec)) die("c6");
                    wit[0] = (uint8_t)r;
                    if (fsetxattr(fds[c], xname, wit, sizeof(wit), 0, XATTR_REPLACE) < 0) die("c6");
                    if (fcntl(fds[c], F_FULLFSYNC) < 0) die("c6");
                    break;
            }
            s[c][r] = now_ns() - t0;
        }
    }

    const char *labels[7] = {
        "0: 1-file write + F_FULLFSYNC",
        "1: 1-file write + F_BARRIERFSYNC",
        "2: V2 current (2x F_FULLFSYNC)",
        "3: V2 barrier+full (full checks)",
        "4: V2 barrier+full (minimal)",
        "5: V3 xattr+full (full checks)",
        "6: V3 xattr+full (minimal)",
    };
    for (int c = 0; c < CASES; c++) {
        report(labels[c], s[c], rounds);
        close(fds[c]);
        close(wit_fds[c]);
        unlink(paths[c]);
        char wp[512];
        snprintf(wp, sizeof(wp), "%s/case%d.wit", dir, c);
        unlink(wp);
        free(s[c]);
    }
    return 0;
}
