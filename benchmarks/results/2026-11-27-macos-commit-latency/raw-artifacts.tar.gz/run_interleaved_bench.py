#!/usr/bin/env python3
import hashlib
import json
import re
import shutil
import statistics
import subprocess
import tempfile
from pathlib import Path

SCRATCH = Path(
    "/Users/emir/.t3/userdata/providers/antigravity/"
    "ac0a3dfd6dddb20962cecff6ee5fe65e19d3923be20e52c5ab52ff877f7e4c32/"
    "antigravity-acp/brain/1772e7aa-fa7e-4979-b1f4-a15b9a707fab/scratch"
)
BASE_BIN = SCRATCH / "bins/before"
CAND_BIN = SCRATCH / "bins/after"
OUT_DIR = SCRATCH / "bench_raw"
OUT_DIR.mkdir(parents=True, exist_ok=True)

TRIALS = 3


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def run_cmd(cmd, log_file: Path, allow_nonzero: bool = False):
    proc = subprocess.run(cmd, capture_output=True, text=True, check=not allow_nonzero)
    with open(log_file, "a") as f:
        f.write(f"$ {' '.join(map(str, cmd))}\n")
        f.write(proc.stdout)
        if proc.stderr:
            f.write(f"[stderr]\n{proc.stderr}")
        if proc.returncode != 0:
            f.write(f"[exit_code={proc.returncode}]\n")
        f.write("\n")
    return proc.stdout, proc.stderr, proc.returncode


def nearest_rank(sorted_vals, pct):
    n = len(sorted_vals)
    idx = max(0, min(n - 1, (n * pct + 99) // 100 - 1))
    return sorted_vals[idx]


def parse_tx_line(line: str) -> dict:
    kv = dict(item.split("=", 1) for item in line.strip().split())
    clients = int(kv["clients"])
    ops = int(kv["operations"])
    elapsed_ns = int(kv["elapsed_ns"])
    reopen_ns = int(kv["reopen_ns"])
    conflicts = [int(x) for x in kv["conflicts"].split(",")]
    samples_ns = sorted(int(x) for x in kv["samples_ns"].split(","))
    tx_per_sec = (clients * ops) / (elapsed_ns / 1e9)
    return {
        "backend": kv["backend"],
        "version": kv["version"],
        "clients": clients,
        "ops": ops,
        "workload": kv["workload"],
        "elapsed_ns": elapsed_ns,
        "reopen_ns": reopen_ns,
        "conflicts_total": sum(conflicts),
        "tx_per_sec": tx_per_sec,
        "p50_us": nearest_rank(samples_ns, 50) / 1000.0,
        "p99_us": nearest_rank(samples_ns, 99) / 1000.0,
        "max_us": samples_ns[-1] / 1000.0,
    }


def parse_kv_output(text: str) -> dict:
    summary = {}
    for line in text.strip().splitlines():
        if line.startswith("backend="):
            for tok in line.split():
                k, v = tok.split("=", 1)
                summary[k] = v
        elif line.startswith("verified_reopen="):
            summary["verified_reopen"] = line.split("=", 1)[1]
    m_write = re.search(
        r"write:\s*count=(\d+)\s+p50_us=([0-9.]+)\s+p95_us=([0-9.]+)\s+p99_us=([0-9.]+)\s+p99_9_us=([0-9.]+)\s+max_us=([0-9.]+)",
        text,
    )
    if m_write:
        summary["write_count"] = int(m_write.group(1))
        summary["write_p50_us"] = float(m_write.group(2))
        summary["write_p95_us"] = float(m_write.group(3))
        summary["write_p99_us"] = float(m_write.group(4))
        summary["write_p999_us"] = float(m_write.group(5))
        summary["write_max_us"] = float(m_write.group(6))
    if "ops_per_sec" in summary:
        summary["ops_per_sec"] = float(summary["ops_per_sec"])
    return summary


def main():
    for f in OUT_DIR.glob("*.log"):
        f.unlink()

    meta = {
        "trials": TRIALS,
        "baseline_commit": "63adbb78",
        "binaries_sha256": {
            f"{side}/{name}": sha256_file((BASE_BIN if side == "before" else CAND_BIN) / name)
            for side in ("before", "after")
            for name in ("sql_bench", "transaction_bench", "kv_bench")
        },
    }

    sql_10k_records = []
    sql_10k_notes = []
    sql_2k_records = []
    tx_records = []
    kv_records = []

    with tempfile.TemporaryDirectory(prefix="emda-bench-") as tmp_root:
        tmp_root = Path(tmp_root)

        print("=== 1a. Running sql_bench <dir> 10000 100 (3 interleaved trials) ===", flush=True)
        for trial in range(1, TRIALS + 1):
            order = ["baseline", "candidate"] if trial % 2 == 1 else ["candidate", "baseline"]
            for label in order:
                bin_dir = BASE_BIN if label == "baseline" else CAND_BIN
                run_dir = tmp_root / f"sql10k-{label}-t{trial}"
                run_dir.mkdir()
                out, err, rc = run_cmd(
                    [bin_dir / "sql_bench", run_dir, "10000", "100"],
                    OUT_DIR / "sql_bench_10000.log",
                    allow_nonzero=True,
                )
                shutil.rmtree(run_dir)
                sql_10k_notes.append({"trial": trial, "build": label, "rc": rc, "stderr": err.strip()})
                for line in out.strip().splitlines():
                    rec = json.loads(line)
                    rec["build"] = label
                    rec["trial"] = trial
                    sql_10k_records.append(rec)
                    load = f"{rec['load_ms']:6.1f}ms" if "load_ms" in rec else "    n/a "
                    upd = f"{rec['pk_update']['p50_us']:6.1f}us" if "pk_update" in rec else "    n/a "
                    dele = rec.get("pk_delete") or rec.get("delete")
                    del_s = f"{dele['p50_us']:6.1f}us" if dele else "    n/a "
                    ins = rec.get("insert")
                    ins_s = f"ins_p50={ins['p50_us']:6.1f}us ins_p99={ins['p99_us']:6.1f}us" if ins else ""
                    print(
                        f"  t{trial} {label:9s} {rec['backend']:23s} load={load} {ins_s} upd_p50={upd} del_p50={del_s}",
                        flush=True,
                    )
                if rc != 0:
                    print(f"  t{trial} {label:9s} rc={rc} stderr={err.strip()}", flush=True)

        print("=== 1b. Running sql_bench <dir> 2000 100 (all 7 backends, 3 interleaved trials) ===", flush=True)
        for trial in range(1, TRIALS + 1):
            order = ["baseline", "candidate"] if trial % 2 == 1 else ["candidate", "baseline"]
            for label in order:
                bin_dir = BASE_BIN if label == "baseline" else CAND_BIN
                run_dir = tmp_root / f"sql2k-{label}-t{trial}"
                run_dir.mkdir()
                out, _, _ = run_cmd(
                    [bin_dir / "sql_bench", run_dir, "2000", "100"],
                    OUT_DIR / "sql_bench_2000.log",
                )
                shutil.rmtree(run_dir)
                for line in out.strip().splitlines():
                    rec = json.loads(line)
                    rec["build"] = label
                    rec["trial"] = trial
                    sql_2k_records.append(rec)
                    if "insert" in rec:
                        load = f"{rec['load_ms']:6.1f}ms" if "load_ms" in rec else "    n/a "
                        print(
                            f"  t{trial} {label:9s} {rec['backend']:23s} load={load} ins_p50={rec['insert']['p50_us']:6.1f}us",
                            flush=True,
                        )
                    else:
                        print(
                            f"  t{trial} {label:9s} {rec['backend']:23s} ins1_p50={rec['insert_1idx']['p50_us']:6.1f}us ins3_p50={rec['insert_3idx']['p50_us']:6.1f}us",
                            flush=True,
                        )

        print("=== 2. Running transaction_bench (1c x 200, 8c x 100, disjoint, 3 interleaved trials) ===", flush=True)
        for clients, ops in [(1, 200), (8, 100)]:
            for trial in range(1, TRIALS + 1):
                if trial % 2 == 1:
                    runs = [
                        ("baseline", "readset"),
                        ("candidate", "readset"),
                        ("baseline", "checkpoint-readset"),
                        ("candidate", "checkpoint-readset"),
                        ("sqlite", "sqlite"),
                    ]
                else:
                    runs = [
                        ("sqlite", "sqlite"),
                        ("candidate", "checkpoint-readset"),
                        ("baseline", "checkpoint-readset"),
                        ("candidate", "readset"),
                        ("baseline", "readset"),
                    ]
                for label, mode in runs:
                    bin_dir = BASE_BIN if label == "baseline" else CAND_BIN
                    run_dir = tmp_root / f"tx-{label}-{mode}-c{clients}-t{trial}"
                    run_dir.mkdir()
                    out, _, _ = run_cmd(
                        [bin_dir / "transaction_bench", mode, str(clients), str(ops), "disjoint", run_dir],
                        OUT_DIR / "transaction_bench.log",
                    )
                    shutil.rmtree(run_dir)
                    line = out.strip().splitlines()[-1]
                    parsed = parse_tx_line(line)
                    parsed["build"] = label
                    parsed["mode"] = mode
                    parsed["trial"] = trial
                    tx_records.append(parsed)
                    print(
                        f"  c{clients} t{trial} {label:9s} {mode:18s} "
                        f"tx/s={parsed['tx_per_sec']:7.1f} p50={parsed['p50_us']:7.1f}us "
                        f"p99={parsed['p99_us']:7.1f}us conflicts={parsed['conflicts_total']}",
                        flush=True,
                    )

        print("=== 3. Running kv_bench (prototype, 1c x 200 and 8c x 100, 64 keys, 100% writes, 3 interleaved trials) ===", flush=True)
        for clients, ops in [(1, 200), (8, 100)]:
            for trial in range(1, TRIALS + 1):
                order = ["baseline", "candidate"] if trial % 2 == 1 else ["candidate", "baseline"]
                for label in order:
                    bin_dir = BASE_BIN if label == "baseline" else CAND_BIN
                    run_dir = tmp_root / f"kv-{label}-c{clients}-t{trial}"
                    run_dir.mkdir()
                    out, _, _ = run_cmd(
                        [bin_dir / "kv_bench", "prototype", str(clients), str(ops), "64", "100", run_dir],
                        OUT_DIR / "kv_bench.log",
                    )
                    shutil.rmtree(run_dir)
                    parsed = parse_kv_output(out)
                    parsed["clients"] = clients
                    parsed["ops"] = ops
                    parsed["trial"] = trial
                    parsed["build"] = label
                    parsed["raw"] = " | ".join(l.strip() for l in out.strip().splitlines())
                    kv_records.append(parsed)
                    print(
                        f"  c{clients} t{trial} {label:9s} ops/s={parsed.get('ops_per_sec', 0):7.1f} "
                        f"p50={parsed.get('write_p50_us', 0):7.1f}us p99={parsed.get('write_p99_us', 0):7.1f}us "
                        f"reopen={parsed.get('verified_reopen')}",
                        flush=True,
                    )

    with open(OUT_DIR / "summary.json", "w") as f:
        json.dump(
            {
                "meta": meta,
                "sql_10000": sql_10k_records,
                "sql_10000_notes": sql_10k_notes,
                "sql_2000": sql_2k_records,
                "tx": tx_records,
                "kv": kv_records,
            },
            f,
            indent=2,
        )

    def fmt_range(vals):
        return f"{min(vals):.1f}..{max(vals):.1f} ({statistics.median(vals):.1f})"

    print("\n=== AGGREGATE SUMMARY (min..max (median)) ===", flush=True)
    print("\n[sql_bench 10000 100]")
    for build in ("baseline", "candidate"):
        for backend in ("emda-store", "emda-checkpoint", "documents", "sqlite"):
            rows = [r for r in sql_10k_records if r["build"] == build and r["backend"] == backend]
            if not rows:
                continue
            load_s = fmt_range([r["load_ms"] for r in rows]) if "load_ms" in rows[0] else "-"
            ins_p50 = fmt_range([r["insert"]["p50_us"] for r in rows])
            ins_p99 = fmt_range([r["insert"]["p99_us"] for r in rows])
            upd_p50 = fmt_range([r["pk_update"]["p50_us"] for r in rows]) if "pk_update" in rows[0] else "-"
            del_key = "pk_delete" if "pk_delete" in rows[0] else "delete"
            del_p50 = fmt_range([r[del_key]["p50_us"] for r in rows])
            print(f"  {build:9s} {backend:15s} | load={load_s} | ins_p50={ins_p50} | ins_p99={ins_p99} | upd_p50={upd_p50} | del_p50={del_p50}")

    print("\n[sql_bench 2000 100 indexed backends]")
    for build in ("baseline", "candidate"):
        for backend in ("emda-store-indexed", "emda-checkpoint-indexed", "sqlite-indexed"):
            rows = [r for r in sql_2k_records if r["build"] == build and r["backend"] == backend]
            if not rows:
                continue
            i1_p50 = fmt_range([r["insert_1idx"]["p50_us"] for r in rows])
            i1_p99 = fmt_range([r["insert_1idx"]["p99_us"] for r in rows])
            i3_p50 = fmt_range([r["insert_3idx"]["p50_us"] for r in rows])
            i3_p99 = fmt_range([r["insert_3idx"]["p99_us"] for r in rows])
            print(f"  {build:9s} {backend:23s} | ins1_p50={i1_p50} | ins1_p99={i1_p99} | ins3_p50={i3_p50} | ins3_p99={i3_p99}")

    print("\n[transaction_bench]")
    for clients in (1, 8):
        for build, mode in [
            ("baseline", "readset"),
            ("candidate", "readset"),
            ("baseline", "checkpoint-readset"),
            ("candidate", "checkpoint-readset"),
            ("sqlite", "sqlite"),
        ]:
            rows = [r for r in tx_records if r["clients"] == clients and r["build"] == build and r["mode"] == mode]
            print(
                f"  c{clients} {build:9s} {mode:18s} | "
                f"tx/s={fmt_range([r['tx_per_sec'] for r in rows])} | "
                f"p50={fmt_range([r['p50_us'] for r in rows])} | "
                f"p99={fmt_range([r['p99_us'] for r in rows])} | "
                f"conflicts={sum(r['conflicts_total'] for r in rows)}"
            )

    print("\n[kv_bench]")
    for clients in (1, 8):
        for build in ("baseline", "candidate"):
            rows = [r for r in kv_records if r["clients"] == clients and r["build"] == build]
            print(
                f"  c{clients} {build:9s} | "
                f"ops/s={fmt_range([r['ops_per_sec'] for r in rows])} | "
                f"p50={fmt_range([r['write_p50_us'] for r in rows])} | "
                f"p99={fmt_range([r['write_p99_us'] for r in rows])}"
            )


if __name__ == "__main__":
    main()
