#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/attr.h>
#include <sys/mount.h>
#include <sys/param.h>
#include <sys/xattr.h>
#include <unistd.h>

struct cap_buf {
    uint32_t length;
    vol_capabilities_attr_t caps;
};

int main(int argc, char **argv) {
    const char *path = argc > 1 ? argv[1] : ".";
    int fd = open(path, O_RDONLY);
    if (fd < 0) { perror("open"); return 1; }
    struct statfs sfs;
    if (fstatfs(fd, &sfs) < 0) { perror("fstatfs"); return 1; }
    printf("fstype=%s mntonname=%s mntfromname=%s flags=0x%x MNT_LOCAL=%d\n",
           sfs.f_fstypename, sfs.f_mntonname, sfs.f_mntfromname,
           sfs.f_flags, (sfs.f_flags & MNT_LOCAL) != 0);

    struct attrlist al;
    memset(&al, 0, sizeof(al));
    al.bitmapcount = ATTR_BIT_MAP_COUNT;
    al.volattr = ATTR_VOL_INFO | ATTR_VOL_CAPABILITIES;
    struct cap_buf buf;
    memset(&buf, 0, sizeof(buf));
    if (getattrlist(sfs.f_mntonname, &al, &buf, sizeof(buf), 0) < 0) {
        perror("getattrlist");
        return 1;
    }
    uint32_t iface_cap = buf.caps.capabilities[VOL_CAPABILITIES_INTERFACES];
    uint32_t iface_val = buf.caps.valid[VOL_CAPABILITIES_INTERFACES];
    printf("VOL_CAP_INT_EXTENDED_ATTR: valid=%d cap=%d\n",
           (iface_val & VOL_CAP_INT_EXTENDED_ATTR) != 0,
           (iface_cap & VOL_CAP_INT_EXTENDED_ATTR) != 0);
    printf("VOL_CAP_INT_BARRIERFSYNC:  valid=%d cap=%d\n",
           (iface_val & VOL_CAP_INT_BARRIERFSYNC) != 0,
           (iface_cap & VOL_CAP_INT_BARRIERFSYNC) != 0);
    close(fd);
    return 0;
}
