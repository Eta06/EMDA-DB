use database_engine::{BatchOperation, CheckpointStore, Store};
use rustix::time::{ClockId, clock_gettime};
use std::error::Error;
use std::fs::{self, File};
use std::io::{BufReader, Read};
use std::path::Path;
use std::time::Instant;

type Result<T> = std::result::Result<T, Box<dyn Error>>;
const BATCH: usize = 1024;

fn key(id: usize, width: usize) -> Vec<u8> {
    let mut key = (id as u64).to_be_bytes().to_vec();
    key.resize(width, b'k');
    key
}

fn put_batch(store: &Store, first: usize, width: usize, value: &[u8]) -> Result<()> {
    let keys = (first..first + BATCH).map(|i| key(i, width)).collect::<Vec<_>>();
    let ops = keys.iter().map(|key| BatchOperation::Put { key, value }).collect::<Vec<_>>();
    store.write_batch(&ops)?;
    Ok(())
}

fn seed(root: &Path, keys: usize, width: usize) -> Result<()> {
    assert_eq!(keys % BATCH, 0);
    let store = Store::open(root.join("store"))?;
    for start in (0..keys).step_by(BATCH) {
        put_batch(&store, start, width, b"initial!")?;
    }
    fs::write(root.join("base.digest"), store.checkpoint_to(root.join("base"))?)?;
    put_batch(&store, 0, width, b"updated!")?;
    put_batch(&store, keys, width, b"inserted")?;
    fs::write(root.join("reference.digest"), store.checkpoint_to(root.join("reference"))?)?;
    Ok(())
}

fn cpu_ns() -> i128 {
    let time = clock_gettime(ClockId::ProcessCPUTime);
    i128::from(time.tv_sec) * 1_000_000_000 + i128::from(time.tv_nsec)
}

fn assert_same_file(reference: &Path, candidate: &Path) -> Result<u64> {
    const CHUNK: usize = 64 * 1024;
    let reference = File::open(reference)?;
    let candidate = File::open(candidate)?;
    let bytes = reference.metadata()?.len();
    assert_eq!(bytes, candidate.metadata()?.len());
    let mut reference = BufReader::new(reference);
    let mut candidate = BufReader::new(candidate);
    let mut left = [0_u8; CHUNK];
    let mut right = [0_u8; CHUNK];
    let mut remaining = bytes;
    while remaining > 0 {
        let count = remaining.min(CHUNK as u64) as usize;
        reference.read_exact(&mut left[..count])?;
        candidate.read_exact(&mut right[..count])?;
        assert_eq!(&left[..count], &right[..count]);
        remaining -= count as u64;
    }
    Ok(bytes)
}

fn run(root: &Path) -> Result<()> {
    let base: [u8; 32] = fs::read(root.join("base.digest"))?.try_into().map_err(|_| "base digest")?;
    let expected: [u8; 32] = fs::read(root.join("reference.digest"))?.try_into().map_err(|_| "reference digest")?;
    let store = CheckpointStore::open(root.join("store"), root.join("base"), &base)?;
    let output = root.join("trial");
    let start = Instant::now();
    let cpu_start = cpu_ns();
    let digest = store.checkpoint_to(&output)?;
    let cpu = cpu_ns() - cpu_start;
    let elapsed = start.elapsed().as_nanos();
    assert_eq!(digest, expected);
    let bytes = assert_same_file(&root.join("reference"), &output)?;
    fs::remove_file(output)?;
    println!("elapsed_ns={elapsed} cpu_ns={cpu} output_bytes={bytes}");
    Ok(())
}

fn main() -> Result<()> {
    let args = std::env::args().collect::<Vec<_>>();
    match args.as_slice() {
        [_, phase, root, keys, width] if phase == "seed" => seed(Path::new(root), keys.parse()?, width.parse()?)?,
        [_, phase, root] if phase == "run" => run(Path::new(root))?,
        _ => return Err("usage: checkpoint_digest_probe seed ROOT KEYS WIDTH | run ROOT".into()),
    }
    Ok(())
}
