set -eu
baseline=$1
candidate=$2
fixture=$3
"$candidate" setup "$fixture"
printf 'round,case,sample,elapsed_ns\n'
round=0
for cases in 'baseline optimized sqlite' 'optimized sqlite baseline' 'sqlite baseline optimized' 'baseline sqlite optimized' 'sqlite optimized baseline' 'optimized baseline sqlite'; do
    for case in $cases; do
        binary=$candidate
        if [ "$case" = baseline ]; then binary=$baseline; fi
        "$binary" "$case" "$fixture" "$round"
    done
    round=$((round + 1))
done
