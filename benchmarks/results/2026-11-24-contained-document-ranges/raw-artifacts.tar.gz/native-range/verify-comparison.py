import collections
import csv
import json
import math
import re
import statistics
import sys
from pathlib import Path

root = Path(sys.argv[1])
attempt = json.loads((root / "attempt.json").read_text())
assert attempt["status"] == "exited" and attempt["returncode"] == attempt["wrapper_exit_code"] == 0
assert attempt["revision"] == sys.argv[2]
lines = (root / attempt["output"]).read_text().splitlines()
assert lines[0].endswith("source_rows=256 branches=16"), lines[0]
assert [line for line in lines if line.startswith("sqlite_plan=")] == ["sqlite_plan=SCAN items"]
observed = collections.defaultdict(dict)
for line in lines:
    work = re.fullmatch(r"(baseline|optimized): round=(\d+) probes=(\d+) visits=(\d+) matched=(\d+)", line)
    if work:
        case, round_number, probes, visits, matched = work.groups()
        assert int(round_number) not in observed[case]
        observed[case][int(round_number)] = (int(probes), int(visits), int(matched))
for case, work in (("baseline", (16, 528, 47)), ("optimized", (1, 48, 47))):
    assert observed[case] == {round_number: work for round_number in range(6)}
    print(case, "probes", work[0], "visits", work[1], "matched", work[2])

header = lines.index("round,case,sample,elapsed_ns")
rows = list(csv.DictReader([lines[header], *(row for row in lines[header + 1:] if re.match(r"^\d+,", row))]))
assert len(rows) == 360
for case in ("baseline", "optimized", "sqlite"):
    selected = [row for row in rows if row["case"] == case]
    assert len(selected) == 120
    assert {(int(row["round"]), int(row["sample"])) for row in selected} == {
        (round_number, sample) for round_number in range(6) for sample in range(20)
    }
    times = sorted(int(row["elapsed_ns"]) for row in selected)
    assert times[0] > 0
    print(f"{case}: samples={len(times)} median_us={statistics.median(times)/1000:.2f} p95_us={times[math.ceil(.95*len(times))-1]/1000:.2f}")
